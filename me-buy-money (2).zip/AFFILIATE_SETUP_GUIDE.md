# Me BUY MONEY — Production Affiliate Integration & Deployment Guide

This document explains the real affiliate network integration setup, webhook listeners, tracking sub-ID reconciliation, and deployment configuration for **Me BUY MONEY**.

---

## 1. Architecture Overview

```
User App (Mobile/Web)
      │
      ▼  (1) User clicks "Shop Now"
Firestore /clicks & /transactions
      │
      ▼  (2) Generates Sub-ID: MBM_<UID>_<TIMESTAMP>_<RANDOM>
Retailer Store (Amazon, Flipkart, Myntra, etc.)
      │
      ▼  (3) User completes purchase on merchant website
Affiliate Network Tracking Server
      │
      ▼  (4) Network Postback / API Feed / Report CSV
Me BUY MONEY Reconciliation Engine (Admin / Webhook)
      │
      ▼  (5) Confirms order & credits 40% of commission to User Wallet
User Withdraws to UPI / Bank Account
```

---

## 2. Supported Affiliate Networks & Tracking Parameter Mapping

| Affiliate Network | Supported Stores | Sub-ID Parameter Name | Sample Tracking Link Format |
|---|---|---|---|
| **Amazon Associates India** | Amazon.in | `tag` (Associate Tag) + `subid` | `https://www.amazon.in/dp/B0CS5XW9G9?tag=YOUR_TAG-21&subid=MBM_...` |
| **Flipkart Affiliate Program** | Flipkart.com | `affid` + `subid` | `https://www.flipkart.com/item?affid=YOUR_AFFID&subid=MBM_...` |
| **Cuelinks** | Myntra, Ajio, Tata CliQ, Samsung | `subid` | `https://linksredirect.com/?cid=1234&subid=MBM_...&url=https://www.myntra.com/...` |
| **Impact Radius** | Nykaa, Mamaearth, WOW | `subId1` | `https://brand.sjv.io/c/12345/67890/1234?subId1=MBM_...` |
| **EarnKaro** | Multi-store aggregator | `sub_id1` | `https://earnkaro.com/refer?sub_id1=MBM_...&url=...` |

---

## 3. Real Affiliate API Credentials Required for Production

To connect live automatic transaction feeds, configure the following credentials in your backend environment:

### Amazon Associates Product Advertising API (PA-API v5)
- **Access Key ID**: Provided in Amazon Associates portal (`Tools > Product Advertising API`).
- **Secret Access Key**: Private signing secret.
- **Associate Tag**: Your approved Amazon tag (e.g., `mebuymoney-21`).
- **Region**: `webservices.amazon.in`.

### Flipkart Affiliate API
- **Affiliate ID**: Your approved tracking ID (e.g., `mebuymoney`).
- **API Token**: Generated under `Reports > API Credentials`.
- **Feed Endpoint**: `https://affiliate-api.flipkart.net/affiliate/report/orders/detail/json?startDate=...`.

### Cuelinks API
- **API Key**: Found under `Cuelinks Dashboard > Tools > API`.
- **Campaign Callback Webhook URL**: Configure your backend endpoint: `https://<YOUR_APP_URL>/api/webhooks/cuelinks`.
- **Postback Param**: Cuelinks delivers: `subid`, `order_id`, `sale_amount`, `commission`, and `status`.

---

## 4. Automatic Webhook Reconciliation Specification

When a network delivers a conversion postback or webhook payload:
1. Extract `subid` (e.g. `MBM_USR01_L8X9...`).
2. Query `/clicks` or `/transactions` where `trackingSubId == subid`.
3. If order status is `Order Pending`:
   - Compute **User Share**: `commission * 0.40`.
   - Compute **Platform Share**: `commission * 0.60`.
4. Update transaction status to `Cashback Confirmed`.
5. Perform an atomic update on `/wallets/{userId}`:
   ```typescript
   pendingCashback -= userCashback;
   confirmedCashback += userCashback;
   availableBalance += userCashback;
   totalEarned += userCashback;
   ```
6. Dispatch in-app notification to the shopper.

---

## 5. Security & Compliance Rules

1. **Never fabricate commissions**: Only credit cashback after merchant reports confirm order validity and the return window has elapsed.
2. **Double-Spend Prevention**: When a user submits a withdrawal request, the amount is immediately reserved from `availableBalance`.
3. **Audit Trail**: Every administrative status update or manual payout reference is logged in `/audit_logs`.
4. **Disclosures**: Display compliant affiliate disclosures stating that Me BUY MONEY earns affiliate commissions and passes 40% back to users.
