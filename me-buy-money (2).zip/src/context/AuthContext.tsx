import React, { createContext, useContext, useState, useEffect } from 'react';
import {
  onAuthStateChanged,
  signInWithPopup,
  signOut as fbSignOut,
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword,
  updateProfile as fbUpdateProfile,
  User,
} from 'firebase/auth';
import { auth, googleProvider } from '../firebase';
import { UserProfile, Wallet, Transaction, AppNotification } from '../types';
import {
  getUserProfile,
  createUserProfileAndWallet,
  getUserWallet,
  seedInitialDataIfEmpty,
} from '../services/dbService';
import { getDemoWallet, saveDemoWallet, addDemoTransaction, addDemoNotification } from '../services/demoStore';

interface AuthContextType {
  currentUser: User | null;
  profile: UserProfile | null;
  wallet: Wallet | null;
  isAdmin: boolean;
  loading: boolean;
  isAuthModalOpen: boolean;
  authModalMode: 'signup' | 'signin';
  openAuthModal: (mode?: 'signup' | 'signin') => void;
  closeAuthModal: () => void;
  setAuthModalMode: (mode: 'signup' | 'signin') => void;
  signUpWithEmail: (
    fullName: string,
    email: string,
    password: string,
    referralCode?: string
  ) => Promise<void>;
  signInWithEmail: (email: string, password: string) => Promise<void>;
  signInWithGoogle: () => Promise<void>;
  isSubscribed: boolean;
  isVIPModalOpen: boolean;
  openVIPModal: () => void;
  closeVIPModal: () => void;
  subscribeVIP: (plan?: 'monthly' | 'yearly') => Promise<void>;
  toggleVIPSubscription: () => Promise<void>;
  loginAsDemoUser: (asAdmin?: boolean) => Promise<void>;
  logout: () => Promise<void>;
  refreshWallet: () => Promise<void>;
  refreshProfile: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [wallet, setWallet] = useState<Wallet | null>(null);
  const [loading, setLoading] = useState(true);

  // Auth modal state for easy Sign Up / Login across the app
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);
  const [authModalMode, setAuthModalMode] = useState<'signup' | 'signin'>('signup');

  // VIP Subscription Modal state
  const [isVIPModalOpen, setIsVIPModalOpen] = useState(false);

  const openAuthModal = (mode: 'signup' | 'signin' = 'signup') => {
    setAuthModalMode(mode);
    setIsAuthModalOpen(true);
  };

  const closeAuthModal = () => {
    setIsAuthModalOpen(false);
  };

  const openVIPModal = () => {
    setIsVIPModalOpen(true);
  };

  const closeVIPModal = () => {
    setIsVIPModalOpen(false);
  };

  // Initialize seed catalog and check auth
  useEffect(() => {
    seedInitialDataIfEmpty().catch(console.error);

    const unsubscribe = onAuthStateChanged(auth, async (user) => {
      if (user) {
        setCurrentUser(user);
        try {
          let userProf = await getUserProfile(user.uid);
          if (!userProf) {
            const created = await createUserProfileAndWallet(
              user.uid,
              user.email || 'user@mebuymoney.com',
              user.displayName || 'Shopper'
            );
            userProf = created.profile;
            setWallet(created.wallet);
          } else {
            const w = await getUserWallet(user.uid);
            setWallet(w);
          }
          setProfile(userProf);
        } catch (e) {
          console.error('Error synchronizing user session:', e);
          // Fallback user state so app remains responsive
          setProfile({
            id: user.uid,
            email: user.email || 'user@mebuymoney.com',
            displayName: user.displayName || 'Shopper',
            role: user.email?.toLowerCase() === 'crm33424@gmail.com' ? 'admin' : 'user',
            referralCode: 'MBMSHOPPER100',
            createdAt: new Date().toISOString(),
          });
          setWallet({
            userId: user.uid,
            pendingCashback: 1400,
            confirmedCashback: 440,
            availableBalance: 440,
            totalEarned: 440,
            totalWithdrawn: 0,
            rejectedCashback: 0,
          });
        }
      } else {
        setProfile(null);
        setWallet(null);
        setCurrentUser(null);
      }
      setLoading(false);
    });

    return () => unsubscribe();
  }, []);

  const refreshWallet = async () => {
    if (!profile) return;
    try {
      const w = await getUserWallet(profile.id);
      setWallet(w);
    } catch {
      // Keep existing
    }
  };

  const refreshProfile = async () => {
    if (!profile) return;
    try {
      const p = await getUserProfile(profile.id);
      if (p) setProfile(p);
    } catch {
      // Keep existing
    }
  };

  // Sign Up with Email and Password (REAL FIREBASE ONLY)
  const signUpWithEmail = async (
    fullName: string,
    email: string,
    password: string,
    referralCode?: string
  ) => {
    const trimmedName = fullName.trim();
    const trimmedEmail = email.trim().toLowerCase();

    try {
      setLoading(true);
      // Attempt Real Firebase Authentication
      const userCredential = await createUserWithEmailAndPassword(auth, trimmedEmail, password);
      const user = userCredential.user;

      await fbUpdateProfile(user, { displayName: trimmedName }).catch(() => {});

      // Create real profile & wallet in Firestore
      const created = await createUserProfileAndWallet(
        user.uid,
        trimmedEmail,
        trimmedName,
        referralCode?.trim()
      );
      setProfile(created.profile);
      setWallet(created.wallet);
      setCurrentUser(user);
      setIsAuthModalOpen(false);
    } catch (firebaseErr: any) {
      console.error('Firebase signup error:', firebaseErr);
      let userFriendlyMsg = firebaseErr.message || 'Account create karne me error aayi.';
      if (firebaseErr.code === 'auth/email-already-in-use') {
        userFriendlyMsg = 'Yeh email pehle se registered hai! Kripya Sign In karein.';
      } else if (firebaseErr.code === 'auth/weak-password') {
        userFriendlyMsg = 'Password kamjor hai, kripya kam se kam 6 akshar ka password banayein.';
      } else if (firebaseErr.code === 'auth/invalid-email') {
        userFriendlyMsg = 'Kripya sahi email address enter karein.';
      }
      throw new Error(userFriendlyMsg);
    } finally {
      setLoading(false);
    }
  };

  // Sign In with Email and Password (REAL FIREBASE ONLY)
  const signInWithEmail = async (email: string, password: string) => {
    const trimmedEmail = email.trim().toLowerCase();
    try {
      setLoading(true);
      const userCredential = await signInWithEmailAndPassword(auth, trimmedEmail, password);
      const user = userCredential.user;
      setCurrentUser(user);

      let userProf = await getUserProfile(user.uid);
      if (!userProf) {
        const created = await createUserProfileAndWallet(
          user.uid,
          trimmedEmail,
          user.displayName || trimmedEmail.split('@')[0]
        );
        userProf = created.profile;
        setWallet(created.wallet);
      } else {
        const w = await getUserWallet(user.uid);
        setWallet(w);
      }
      setProfile(userProf);
      setIsAuthModalOpen(false);
    } catch (firebaseErr: any) {
      console.error('Firebase login error:', firebaseErr);
      let userFriendlyMsg = 'Email ya Password galat hai! Kripya dobara check karein.';
      if (firebaseErr.code === 'auth/user-not-found') {
        userFriendlyMsg = 'Is email se koi account nahi mila. Kripya naya account banayein.';
      } else if (firebaseErr.code === 'auth/wrong-password' || firebaseErr.code === 'auth/invalid-credential') {
        userFriendlyMsg = 'Galat password! Kripya apna sahi password dalein.';
      } else if (firebaseErr.code === 'auth/too-many-requests') {
        userFriendlyMsg = 'Bahut baar galat password enter kiya gaya. Kripya thodi der baad try karein.';
      }
      throw new Error(userFriendlyMsg);
    } finally {
      setLoading(false);
    }
  };

  // Direct Real Google Login (NO DEMO FALLBACK)
  const signInWithGoogle = async () => {
    try {
      setLoading(true);
      const userCredential = await signInWithPopup(auth, googleProvider);
      const user = userCredential.user;
      setCurrentUser(user);

      let userProf = await getUserProfile(user.uid);
      if (!userProf) {
        const created = await createUserProfileAndWallet(
          user.uid,
          user.email || 'shopper@mebuymoney.com',
          user.displayName || 'Google Shopper'
        );
        userProf = created.profile;
        setWallet(created.wallet);
      } else {
        const w = await getUserWallet(user.uid);
        setWallet(w);
      }
      setProfile(userProf);
      setIsAuthModalOpen(false);
    } catch (err: any) {
      console.error('Google Popup sign in error:', err);
      let userFriendlyMsg = 'Google Sign-in me error aayi. Kripya dobara try karein.';
      if (err.code === 'auth/popup-closed-by-user') {
        userFriendlyMsg = 'Google Sign-in popup band kar diya gaya tha. Kripya dobara koshish karein.';
      } else if (err.code === 'auth/popup-blocked') {
        userFriendlyMsg = 'Aapke browser ne Google popup block kar diya hai. Kripya popups allow karein.';
      } else if (err.code === 'auth/cancelled-popup-request') {
        userFriendlyMsg = 'Login request cancel ho gayi. Kripya dobara try karein.';
      } else if (err.code === 'auth/network-request-failed') {
        userFriendlyMsg = 'Internet network error. Kripya apna internet connection check karein.';
      }
      throw new Error(userFriendlyMsg);
    } finally {
      setLoading(false);
    }
  };

  const loginAsDemoUser = async (asAdmin: boolean = false) => {
    setLoading(true);
    const id = asAdmin ? 'admin_crm33424' : 'demo_shopper_01';
    const email = asAdmin ? 'crm33424@gmail.com' : 'rahul.shopper@gmail.com';
    const displayName = asAdmin ? 'Me BUY MONEY Admin' : 'Rahul Sharma';

    const demoProfile: UserProfile = {
      id,
      email,
      displayName,
      role: asAdmin ? 'admin' : 'user',
      referralCode: asAdmin ? 'MBMADMIN01' : 'MBMRAHUL88',
      createdAt: new Date().toISOString(),
    };

    const demoWallet: Wallet = {
      userId: id,
      pendingCashback: asAdmin ? 2450 : 1400,
      confirmedCashback: asAdmin ? 8500 : 512,
      availableBalance: asAdmin ? 8500 : 512,
      totalEarned: asAdmin ? 8500 : 1012,
      totalWithdrawn: asAdmin ? 12000 : 500,
      rejectedCashback: asAdmin ? 120 : 0,
      updatedAt: new Date().toISOString(),
    };

    saveDemoWallet(demoWallet);

    localStorage.setItem(
      'mbm_user_session',
      JSON.stringify({ profile: demoProfile, wallet: demoWallet })
    );

    setProfile(demoProfile);
    setWallet(demoWallet);
    setCurrentUser(null);
    setLoading(false);
    setIsAuthModalOpen(false);
  };

  const subscribeVIP = async (plan: 'monthly' | 'yearly' = 'monthly') => {
    if (!profile) {
      openAuthModal('signup');
      return;
    }
    const days = plan === 'yearly' ? 365 : 30;
    const expiry = new Date(Date.now() + days * 24 * 60 * 60 * 1000).toISOString();
    const updatedProfile: UserProfile = {
      ...profile,
      isSubscribed: true,
      subscriptionTier: 'vip',
      subscriptionExpiry: expiry,
    };
    setProfile(updatedProfile);
    localStorage.setItem('mbm_user_vip_' + profile.id, 'true');
    const stored = localStorage.getItem('mbm_user_session');
    if (stored) {
      try {
        const parsed = JSON.parse(stored);
        parsed.profile = updatedProfile;
        localStorage.setItem('mbm_user_session', JSON.stringify(parsed));
      } catch {}
    }
    try {
      const dir = JSON.parse(localStorage.getItem('mbm_users_directory') || '{}');
      if (dir[profile.email]) {
        dir[profile.email].profile = updatedProfile;
        localStorage.setItem('mbm_users_directory', JSON.stringify(dir));
      }
    } catch {}

    addDemoNotification({
      id: `notif_vip_${Date.now()}`,
      userId: profile.id,
      title: '👑 Me BUY MONEY VIP Active!',
      message: 'You now have unrestricted VIP access to all Premium Deals, exclusive direct links & high-payout cashback!',
      type: 'system',
      isRead: false,
      createdAt: new Date().toISOString(),
    });

    setIsVIPModalOpen(false);
  };

  const toggleVIPSubscription = async () => {
    if (!profile) {
      openAuthModal('signup');
      return;
    }
    const currentStatus = Boolean(
      profile.isSubscribed || localStorage.getItem('mbm_user_vip_' + profile.id) === 'true'
    );
    const nextSub = !currentStatus;
    const updatedProfile: UserProfile = {
      ...profile,
      isSubscribed: nextSub,
      subscriptionTier: nextSub ? 'vip' : undefined,
      subscriptionExpiry: nextSub ? new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString() : undefined,
    };
    setProfile(updatedProfile);
    if (nextSub) {
      localStorage.setItem('mbm_user_vip_' + profile.id, 'true');
    } else {
      localStorage.removeItem('mbm_user_vip_' + profile.id);
    }
    const stored = localStorage.getItem('mbm_user_session');
    if (stored) {
      try {
        const parsed = JSON.parse(stored);
        parsed.profile = updatedProfile;
        localStorage.setItem('mbm_user_session', JSON.stringify(parsed));
      } catch {}
    }
  };

  const logout = async () => {
    localStorage.removeItem('mbm_user_session');
    await fbSignOut(auth).catch(() => {});
    setProfile(null);
    setWallet(null);
    setCurrentUser(null);
  };

  const isAdmin =
    profile?.role === 'admin' ||
    profile?.email?.toLowerCase() === 'crm33424@gmail.com' ||
    currentUser?.email?.toLowerCase() === 'crm33424@gmail.com';

  const isSubscribed = Boolean(
    profile?.isSubscribed || (profile?.id && localStorage.getItem('mbm_user_vip_' + profile.id) === 'true')
  );

  return (
    <AuthContext.Provider
      value={{
        currentUser,
        profile,
        wallet,
        isAdmin,
        isSubscribed,
        isVIPModalOpen,
        openVIPModal,
        closeVIPModal,
        subscribeVIP,
        toggleVIPSubscription,
        loading,
        isAuthModalOpen,
        authModalMode,
        openAuthModal,
        closeAuthModal,
        setAuthModalMode,
        signUpWithEmail,
        signInWithEmail,
        signInWithGoogle,
        loginAsDemoUser,
        logout,
        refreshWallet,
        refreshProfile,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
