import React, { useState, useEffect } from 'react';
import { AuthProvider, useAuth } from './context/AuthContext';
import { Navbar } from './components/Navbar';
import { BottomNav } from './components/BottomNav';
import { RedirectModal } from './components/RedirectModal';
import { AuthModal } from './components/AuthModal';
import { VIPSubscriptionModal } from './components/VIPSubscriptionModal';
import { HomeScreen } from './screens/HomeScreen';
import { RewardLinkScreen } from './screens/RewardLinkScreen';
import { PremiumDealsScreen } from './screens/PremiumDealsScreen';
import { InboxScreen } from './screens/InboxScreen';
import { CategoriesScreen } from './screens/CategoriesScreen';
import { SearchScreen } from './screens/SearchScreen';
import { DealsScreen } from './screens/DealsScreen';
import { StoreOffersScreen } from './screens/StoreOffersScreen';
import { OrdersScreen } from './screens/OrdersScreen';
import { WalletScreen } from './screens/WalletScreen';
import { WithdrawScreen } from './screens/WithdrawScreen';
import { NotificationsScreen } from './screens/NotificationsScreen';
import { TransactionHistoryScreen } from './screens/TransactionHistoryScreen';
import { ProfileScreen } from './screens/ProfileScreen';
import { HelpScreen } from './screens/HelpScreen';
import { AdminScreen } from './screens/AdminScreen';
import { UnifiedHistoryScreen } from './screens/UnifiedHistoryScreen';

import {
  getCategories,
  getAffiliateNetworks,
  getProducts,
  getBanners,
  getUserTransactions,
  getUserWithdrawals,
  getUserNotifications,
  getUserInbox,
  getUserRewardLinkRequests,
  recordAffiliateClick,
} from './services/dbService';

import {
  ScreenTab,
  Product,
  Category,
  AffiliateNetwork,
  Banner,
  Transaction,
  WithdrawalRequest,
  AppNotification,
  UserInboxItem,
  RewardLinkRequest,
} from './types';

function AppContent() {
  const { profile, wallet, refreshWallet } = useAuth();
  const [currentTab, setCurrentTab] = useState<ScreenTab>('home');

  // Catalog
  const [categories, setCategories] = useState<Category[]>([]);
  const [networks, setNetworks] = useState<AffiliateNetwork[]>([]);
  const [products, setProducts] = useState<Product[]>([]);
  const [banners, setBanners] = useState<Banner[]>([]);
  const [selectedCategoryId, setSelectedCategoryId] = useState<string>('cat_electronics');

  // User Data
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [withdrawals, setWithdrawals] = useState<WithdrawalRequest[]>([]);
  const [notifications, setNotifications] = useState<AppNotification[]>([]);
  const [inboxItems, setInboxItems] = useState<UserInboxItem[]>([]);
  const [rewardRequests, setRewardRequests] = useState<RewardLinkRequest[]>([]);

  // Outbound Affiliate Tracking Modal
  const [redirectProduct, setRedirectProduct] = useState<Product | null>(null);
  const [trackingSubId, setTrackingSubId] = useState<string>('');
  const [trackedUrl, setTrackedUrl] = useState<string>('');

  // Initial catalog load
  useEffect(() => {
    loadCatalog();
  }, []);

  // User data sync
  useEffect(() => {
    if (profile?.id) {
      loadUserData();
    }
  }, [profile?.id]);

  const loadCatalog = async () => {
    try {
      const [cats, nets, prods, bans] = await Promise.all([
        getCategories(),
        getAffiliateNetworks(),
        getProducts(),
        getBanners(),
      ]);
      setCategories(cats);
      setNetworks(nets);
      setProducts(prods);
      setBanners(bans);
      if (cats.length > 0 && !selectedCategoryId) {
        setSelectedCategoryId(cats[0].id);
      }
    } catch (e) {
      console.error('Failed to load catalog:', e);
    }
  };

  const loadUserData = async () => {
    if (!profile?.id) return;
    try {
      const [txns, wths, notifs, inbox, reqs] = await Promise.all([
        getUserTransactions(profile.id),
        getUserWithdrawals(profile.id),
        getUserNotifications(profile.id),
        getUserInbox(profile.id),
        getUserRewardLinkRequests(profile.id),
      ]);
      setTransactions(txns);
      setWithdrawals(wths);
      setNotifications(notifs);
      setInboxItems(inbox);
      setRewardRequests(reqs);
    } catch (e) {
      console.error('Error loading user data:', e);
    }
  };

  // Trigger outbound affiliate link with Sub-ID
  const handleSelectProduct = async (product: Product) => {
    const userId = profile?.id || 'guest_user';
    const network =
      networks.find((n) => n.id === product.networkId) || networks[0] || {
        id: 'net_custom',
        name: 'Affiliate Network',
        slug: 'custom',
        logoUrl: '',
        status: 'active' as const,
        defaultCommissionRate: 8.0,
        userCashbackPercentage: 40,
        platformSharePercentage: 60,
        trackingParamName: 'subid',
        baseUrl: '',
        cookieWindowDays: 1,
        terms: '',
        createdAt: '',
      };

    try {
      const { trackingSubId: subId, trackedUrl: url } = await recordAffiliateClick(
        userId,
        product,
        network
      );
      setTrackingSubId(subId);
      setTrackedUrl(url);
      setRedirectProduct(product);
      // Refresh transactions and notifications so the "Clicked" state shows up in My Orders
      if (profile?.id) {
        loadUserData();
      }
    } catch (err) {
      console.error('Error generating tracking link:', err);
      // Fallback
      window.open(product.affiliateUrl, '_blank');
    }
  };

  const unreadNotifsCount = notifications.filter((n) => !n.isRead).length;
  const unreadInboxCount = inboxItems.filter((i) => !i.isRead).length;
  const pendingRewardCount = rewardRequests.filter((r) => r.status === 'Pending').length;

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col font-sans selection:bg-emerald-500 selection:text-white">
      {/* Top Navbar */}
      <Navbar
        currentTab={currentTab}
        onSelectTab={(tab) => {
          setCurrentTab(tab);
          window.scrollTo({ top: 0, behavior: 'smooth' });
        }}
        unreadNotificationsCount={unreadNotifsCount}
        unreadInboxCount={unreadInboxCount}
      />

      {/* Main Content Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 pt-5">
        {/* Tab 1: Home Screen */}
        {currentTab === 'home' && (
          <HomeScreen
            banners={banners}
            categories={categories}
            products={products}
            networks={networks}
            onSelectProduct={handleSelectProduct}
            onSelectCategory={(catId) => setSelectedCategoryId(catId)}
            onNavigate={(tab) => {
              setCurrentTab(tab);
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
          />
        )}

        {/* Tab 2: Reward Link Screen (Main prominent feature) */}
        {currentTab === 'reward-link' && (
          <RewardLinkScreen
            onNavigate={(tab) => {
              setCurrentTab(tab);
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
          />
        )}

        {/* Tab 3: Premium Deals Screen */}
        {currentTab === 'premium-deals' && (
          <PremiumDealsScreen
            onNavigate={(tab) => {
              setCurrentTab(tab);
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
          />
        )}

        {/* User Inbox: Delivered Reward Links */}
        {currentTab === 'inbox' && (
          <InboxScreen
            onNavigate={(tab) => {
              setCurrentTab(tab);
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
          />
        )}

        {/* Additional Screens */}
        {currentTab === 'categories' && (
          <CategoriesScreen
            categories={categories}
            products={products}
            selectedCategoryId={selectedCategoryId}
            onSelectCategory={(catId) => setSelectedCategoryId(catId)}
            onSelectProduct={handleSelectProduct}
          />
        )}

        {currentTab === 'search' && (
          <SearchScreen
            products={products}
            onSelectProduct={handleSelectProduct}
          />
        )}

        {currentTab === 'deals' && (
          <DealsScreen
            products={products}
            onSelectProduct={handleSelectProduct}
          />
        )}

        {currentTab === 'store-offers' && (
          <StoreOffersScreen
            networks={networks}
            products={products}
            onSelectProduct={handleSelectProduct}
          />
        )}

        {currentTab === 'history' && (
          <UnifiedHistoryScreen
            transactions={transactions}
            withdrawals={withdrawals}
            rewardRequests={rewardRequests}
            inboxItems={inboxItems}
            onNavigate={(tab) => {
              setCurrentTab(tab);
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
            onRefresh={loadUserData}
          />
        )}

        {currentTab === 'orders' && (
          <OrdersScreen
            transactions={transactions}
            onRefresh={loadUserData}
          />
        )}

        {currentTab === 'wallet' && (
          <WalletScreen
            onNavigate={(tab) => {
              setCurrentTab(tab);
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
          />
        )}

        {currentTab === 'withdraw' && <WithdrawScreen />}

        {currentTab === 'notifications' && (
          <NotificationsScreen
            onNavigate={(tab) => {
              setCurrentTab(tab);
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
            onRefreshCount={loadUserData}
          />
        )}

        {currentTab === 'transactions' && (
          <TransactionHistoryScreen
            transactions={transactions}
            withdrawals={withdrawals}
          />
        )}

        {currentTab === 'profile' && (
          <ProfileScreen
            onNavigate={(tab) => {
              setCurrentTab(tab);
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
          />
        )}

        {currentTab === 'help' && (
          <HelpScreen
            onNavigate={(tab) => {
              setCurrentTab(tab);
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
          />
        )}

        {currentTab === 'admin' && (
          <AdminScreen
            products={products}
            networks={networks}
            onRefreshCatalog={loadCatalog}
          />
        )}
      </main>

      {/* Outbound Tracking Modal */}
      <RedirectModal
        product={redirectProduct}
        trackingSubId={trackingSubId}
        trackedUrl={trackedUrl}
        onClose={() => setRedirectProduct(null)}
      />

      {/* User Signup & Signin Modal */}
      <AuthModal />

      {/* VIP Subscription Modal */}
      <VIPSubscriptionModal />

      {/* Mobile Bottom Navigation (5 tabs: Home, Inbox, Reward Link, History, Refer) */}
      <BottomNav
        currentTab={currentTab}
        onSelectTab={(tab) => {
          setCurrentTab(tab);
          window.scrollTo({ top: 0, behavior: 'smooth' });
        }}
        pendingRewardRequestsCount={pendingRewardCount}
        unreadInboxCount={unreadInboxCount}
      />
    </div>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <AppContent />
    </AuthProvider>
  );
}
