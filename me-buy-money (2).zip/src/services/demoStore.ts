import {
  Transaction,
  WithdrawalRequest,
  AppNotification,
  Wallet,
  RewardLinkRequest,
  UserInboxItem,
  PremiumDeal,
} from '../types';
import { INITIAL_PREMIUM_DEALS } from './seedData';

const INITIAL_DEMO_REWARD_REQUESTS: RewardLinkRequest[] = [
  {
    id: 'ANS_REQ_10283',
    userId: 'demo_shopper_01',
    userEmail: 'rahul.shopper@gmail.com',
    productUrl: 'https://www.amazon.in/dp/B0CS5XW9G9',
    storeName: 'Amazon India',
    productTitle: 'OnePlus 12R (16GB RAM, 256GB Storage)',
    affiliateUrl: 'https://www.amazon.in/dp/B0CS5XW9G9?tag=ansora-21&subid=MBM_RAHUL_L9X2',
    status: 'Completed',
    submittedAt: new Date(Date.now() - 2 * 60 * 60 * 1000).toISOString(),
    completedAt: new Date(Date.now() - 118 * 60 * 1000).toISOString(),
    clickCount: 1,
    lastClickedAt: new Date(Date.now() - 110 * 60 * 1000).toISOString(),
    notes: 'Verified eligible product link from Amazon Associates program.',
  },
];

const INITIAL_DEMO_INBOX: UserInboxItem[] = [
  {
    id: 'inbox_item_01',
    userId: 'demo_shopper_01',
    requestId: 'ANS_REQ_10283',
    productUrl: 'https://www.amazon.in/dp/B0CS5XW9G9',
    affiliateUrl: 'https://www.amazon.in/dp/B0CS5XW9G9?tag=ansora-21&subid=MBM_RAHUL_L9X2',
    storeName: 'Amazon India',
    productTitle: 'OnePlus 12R (16GB RAM, 256GB Storage)',
    status: 'Completed',
    receivedAt: new Date(Date.now() - 118 * 60 * 1000).toISOString(),
    isRead: false,
    clickCount: 1,
    lastClickedAt: new Date(Date.now() - 110 * 60 * 1000).toISOString(),
  },
];

const INITIAL_DEMO_TRANSACTIONS: Transaction[] = [
  {
    id: 'txn_ans_01',
    userId: 'demo_shopper_01',
    userEmail: 'rahul.shopper@gmail.com',
    requestId: 'ANS_REQ_10283',
    clickId: 'clk_demo_01',
    trackingSubId: 'MBM_RAHUL_L9X2',
    networkId: 'net_amazon',
    storeName: 'Amazon India',
    productId: 'prod_oneplus_12r',
    productTitle: 'OnePlus 12R (16GB RAM, 256GB Storage)',
    orderAmount: 39999,
    affiliateCommission: 3500,
    userCashbackAmount: 1400,
    platformShareAmount: 2100,
    currency: 'INR',
    status: 'Purchase Tracking Pending',
    networkOrderId: '402-8921829-1928371',
    orderDate: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000).toISOString(),
    createdAt: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000).toISOString(),
  },
  {
    id: 'txn_ans_02',
    userId: 'demo_shopper_01',
    userEmail: 'rahul.shopper@gmail.com',
    clickId: 'clk_demo_02',
    trackingSubId: 'MBM_RAHUL_M4B1',
    networkId: 'net_cuelinks',
    storeName: 'Myntra',
    productId: 'prod_nike_air_jordan',
    productTitle: 'Nike Air Jordan 1 Low Retro Sneakers',
    orderAmount: 7995,
    affiliateCommission: 1100,
    userCashbackAmount: 440,
    platformShareAmount: 660,
    currency: 'INR',
    status: 'Cashback Confirmed',
    networkOrderId: 'MYNTRA-908123',
    orderDate: new Date(Date.now() - 65 * 24 * 60 * 60 * 1000).toISOString(),
    confirmationDate: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000).toISOString(),
    createdAt: new Date(Date.now() - 65 * 24 * 60 * 60 * 1000).toISOString(),
  },
  {
    id: 'txn_ans_03',
    userId: 'demo_shopper_01',
    userEmail: 'rahul.shopper@gmail.com',
    clickId: 'clk_demo_03',
    trackingSubId: 'MBM_RAHUL_K1T8',
    networkId: 'net_impact',
    storeName: 'Mamaearth',
    productId: 'prod_mamaearth_ubtan',
    productTitle: 'Mamaearth Ubtan Face Care Combo',
    orderAmount: 899,
    affiliateCommission: 180,
    userCashbackAmount: 72,
    platformShareAmount: 108,
    currency: 'INR',
    status: 'Cashback Confirmed',
    networkOrderId: 'MAMA-491029',
    orderDate: new Date(Date.now() - 48 * 24 * 60 * 60 * 1000).toISOString(),
    confirmationDate: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000).toISOString(),
    createdAt: new Date(Date.now() - 48 * 24 * 60 * 60 * 1000).toISOString(),
  },
];

const INITIAL_DEMO_WITHDRAWALS: WithdrawalRequest[] = [
  {
    id: 'demo_wth_01',
    userId: 'demo_shopper_01',
    userEmail: 'rahul.shopper@gmail.com',
    amount: 500,
    method: 'UPI',
    payoutDetails: {
      upiId: 'rahul.sharma@okaxis',
    },
    status: 'Paid',
    transactionReference: 'UTR291039581902',
    adminNotes: 'Processed via ICICI UPI Corporate Portal',
    requestedAt: new Date(Date.now() - 15 * 24 * 60 * 60 * 1000).toISOString(),
    processedAt: new Date(Date.now() - 14 * 24 * 60 * 60 * 1000).toISOString(),
  },
];

const INITIAL_DEMO_NOTIFICATIONS: AppNotification[] = [
  {
    id: 'demo_notif_01',
    userId: 'demo_shopper_01',
    title: 'Reward Link Ready! 🔗',
    message: 'Your tracked affiliate link for OnePlus 12R is ready in your Inbox. Tap to shop and earn cashback.',
    type: 'reward_link',
    isRead: false,
    createdAt: new Date(Date.now() - 118 * 60 * 1000).toISOString(),
  },
  {
    id: 'demo_notif_02',
    userId: 'demo_shopper_01',
    title: 'Cashback Confirmed! 🎉',
    message: '₹440 Cashback from Myntra is verified & credited to your Available Balance.',
    type: 'cashback',
    isRead: false,
    createdAt: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000).toISOString(),
  },
];

// ---------------- REWARD LINK REQUESTS ---------------- //

export function getDemoRewardRequests(): RewardLinkRequest[] {
  const stored = localStorage.getItem('ansora_demo_reward_requests');
  if (stored) {
    try {
      return JSON.parse(stored);
    } catch {}
  }
  localStorage.setItem('ansora_demo_reward_requests', JSON.stringify(INITIAL_DEMO_REWARD_REQUESTS));
  return INITIAL_DEMO_REWARD_REQUESTS;
}

export function saveDemoRewardRequests(list: RewardLinkRequest[]) {
  localStorage.setItem('ansora_demo_reward_requests', JSON.stringify(list));
}

export function addDemoRewardRequest(req: RewardLinkRequest) {
  const current = getDemoRewardRequests();
  const updated = [req, ...current];
  saveDemoRewardRequests(updated);
}

export function updateDemoRewardRequest(reqId: string, updates: Partial<RewardLinkRequest>) {
  const current = getDemoRewardRequests();
  const updated = current.map((r) => (r.id === reqId ? { ...r, ...updates } : r));
  saveDemoRewardRequests(updated);
}

// ---------------- USER INBOX ---------------- //

export function getDemoInbox(userId?: string): UserInboxItem[] {
  const stored = localStorage.getItem('ansora_demo_inbox');
  let list = INITIAL_DEMO_INBOX;
  if (stored) {
    try {
      list = JSON.parse(stored);
    } catch {}
  } else {
    localStorage.setItem('ansora_demo_inbox', JSON.stringify(INITIAL_DEMO_INBOX));
  }
  if (userId) {
    return list.filter((i) => i.userId === userId);
  }
  return list;
}

export function saveDemoInbox(list: UserInboxItem[]) {
  localStorage.setItem('ansora_demo_inbox', JSON.stringify(list));
}

export function addDemoInboxItem(item: UserInboxItem) {
  const current = getDemoInbox();
  const updated = [item, ...current];
  saveDemoInbox(updated);
}

export function updateDemoInboxItem(inboxId: string, updates: Partial<UserInboxItem>) {
  const current = getDemoInbox();
  const updated = current.map((i) => (i.id === inboxId ? { ...i, ...updates } : i));
  saveDemoInbox(updated);
}

// ---------------- PREMIUM DEALS ---------------- //

export function getDemoPremiumDeals(): PremiumDeal[] {
  const stored = localStorage.getItem('mbm_demo_premium_deals_v2');
  if (stored) {
    try {
      return JSON.parse(stored);
    } catch {}
  }
  localStorage.setItem('mbm_demo_premium_deals_v2', JSON.stringify(INITIAL_PREMIUM_DEALS));
  return INITIAL_PREMIUM_DEALS;
}

export function saveDemoPremiumDeals(list: PremiumDeal[]) {
  localStorage.setItem('mbm_demo_premium_deals_v2', JSON.stringify(list));
}

// ---------------- TRANSACTIONS ---------------- //

export function getDemoTransactions(): Transaction[] {
  const stored = localStorage.getItem('ansora_demo_transactions');
  if (stored) {
    try {
      return JSON.parse(stored);
    } catch {}
  }
  localStorage.setItem('ansora_demo_transactions', JSON.stringify(INITIAL_DEMO_TRANSACTIONS));
  return INITIAL_DEMO_TRANSACTIONS;
}

export function saveDemoTransactions(list: Transaction[]) {
  localStorage.setItem('ansora_demo_transactions', JSON.stringify(list));
}

export function addDemoTransaction(txn: Transaction) {
  const current = getDemoTransactions();
  const updated = [txn, ...current];
  saveDemoTransactions(updated);
}

export function updateDemoTransaction(txnId: string, updates: Partial<Transaction>) {
  const current = getDemoTransactions();
  const updated = current.map((t) => (t.id === txnId ? { ...t, ...updates } : t));
  saveDemoTransactions(updated);
}

// ---------------- WITHDRAWALS ---------------- //

export function getDemoWithdrawals(): WithdrawalRequest[] {
  const stored = localStorage.getItem('ansora_demo_withdrawals');
  if (stored) {
    try {
      return JSON.parse(stored);
    } catch {}
  }
  localStorage.setItem('ansora_demo_withdrawals', JSON.stringify(INITIAL_DEMO_WITHDRAWALS));
  return INITIAL_DEMO_WITHDRAWALS;
}

export function saveDemoWithdrawals(list: WithdrawalRequest[]) {
  localStorage.setItem('ansora_demo_withdrawals', JSON.stringify(list));
}

export function addDemoWithdrawal(wth: WithdrawalRequest) {
  const current = getDemoWithdrawals();
  const updated = [wth, ...current];
  saveDemoWithdrawals(updated);
}

export function updateDemoWithdrawal(wthId: string, updates: Partial<WithdrawalRequest>) {
  const current = getDemoWithdrawals();
  const updated = current.map((w) => (w.id === wthId ? { ...w, ...updates } : w));
  saveDemoWithdrawals(updated);
}

// ---------------- NOTIFICATIONS ---------------- //

export function getDemoNotifications(): AppNotification[] {
  const stored = localStorage.getItem('ansora_demo_notifications');
  if (stored) {
    try {
      return JSON.parse(stored);
    } catch {}
  }
  localStorage.setItem('ansora_demo_notifications', JSON.stringify(INITIAL_DEMO_NOTIFICATIONS));
  return INITIAL_DEMO_NOTIFICATIONS;
}

export function saveDemoNotifications(list: AppNotification[]) {
  localStorage.setItem('ansora_demo_notifications', JSON.stringify(list));
}

export function addDemoNotification(notif: AppNotification) {
  const current = getDemoNotifications();
  const updated = [notif, ...current];
  saveDemoNotifications(updated);
}

export function markDemoNotificationRead(notifId: string) {
  const current = getDemoNotifications();
  const updated = current.map((n) => (n.id === notifId ? { ...n, isRead: true } : n));
  saveDemoNotifications(updated);
}

// ---------------- WALLET ---------------- //

export function getDemoWallet(userId: string): Wallet {
  const stored = localStorage.getItem('ansora_demo_wallet_' + userId);
  if (stored) {
    try {
      return JSON.parse(stored);
    } catch {}
  }
  const defaultWallet: Wallet = {
    userId,
    pendingCashback: 1400,
    confirmedCashback: 512,
    availableBalance: 512,
    totalEarned: 1012,
    totalWithdrawn: 500,
    rejectedCashback: 0,
    updatedAt: new Date().toISOString(),
  };
  localStorage.setItem('ansora_demo_wallet_' + userId, JSON.stringify(defaultWallet));
  return defaultWallet;
}

export function saveDemoWallet(wallet: Wallet) {
  localStorage.setItem('ansora_demo_wallet_' + wallet.userId, JSON.stringify(wallet));
}
