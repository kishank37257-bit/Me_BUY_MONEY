import {
  collection,
  doc,
  getDoc,
  getDocs,
  setDoc,
  updateDoc,
  deleteDoc,
  query,
  where,
  orderBy,
  limit,
} from 'firebase/firestore';
import { db, auth, handleFirestoreError, OperationType } from '../firebase';
import {
  UserProfile,
  Wallet,
  Product,
  Category,
  AffiliateNetwork,
  ClickRecord,
  Transaction,
  WithdrawalRequest,
  Referral,
  AppNotification,
  Banner,
  AuditLog,
  PlatformSettings,
  OrderStatus,
  WithdrawalStatus,
  RewardLinkRequest,
  UserInboxItem,
  PremiumDeal,
} from '../types';
import {
  INITIAL_CATEGORIES,
  INITIAL_NETWORKS,
  INITIAL_PRODUCTS,
  INITIAL_BANNERS,
  DEFAULT_PLATFORM_SETTINGS,
  INITIAL_PREMIUM_DEALS,
} from './seedData';
import {
  getDemoTransactions,
  addDemoTransaction,
  updateDemoTransaction,
  getDemoWithdrawals,
  addDemoWithdrawal,
  updateDemoWithdrawal,
  getDemoNotifications,
  addDemoNotification,
  markDemoNotificationRead,
  getDemoWallet,
  saveDemoWallet,
  getDemoRewardRequests,
  addDemoRewardRequest,
  updateDemoRewardRequest,
  getDemoInbox,
  addDemoInboxItem,
  updateDemoInboxItem,
  getDemoPremiumDeals,
  saveDemoPremiumDeals,
} from './demoStore';

function isDemoOrUnauthenticated(userId?: string): boolean {
  if (!auth.currentUser) return true;
  if (!userId) return true;
  return userId.startsWith('demo_') || userId.startsWith('admin_') || auth.currentUser.uid !== userId;
}

export function detectStoreName(url: string): string {
  try {
    const lower = url.toLowerCase();
    if (lower.includes('amazon')) return 'Amazon India';
    if (lower.includes('flipkart')) return 'Flipkart';
    if (lower.includes('myntra')) return 'Myntra';
    if (lower.includes('ajio')) return 'Ajio';
    if (lower.includes('nykaa')) return 'Nykaa';
    if (lower.includes('mamaearth')) return 'Mamaearth';
    if (lower.includes('makemytrip')) return 'MakeMyTrip';
    if (lower.includes('samsung')) return 'Samsung';
    if (lower.includes('croma')) return 'Croma';
    const parsed = new URL(url);
    const host = parsed.hostname.replace('www.', '').split('.')[0];
    return host.charAt(0).toUpperCase() + host.slice(1);
  } catch {
    return 'Online Retailer';
  }
}

export function generateTrackingSubId(userId: string): string {
  const shortUid = userId.slice(0, 6);
  const timeHex = Date.now().toString(36);
  const randomStr = Math.random().toString(36).substring(2, 6);
  return `MBM_${shortUid}_${timeHex}_${randomStr}`.toUpperCase();
}

export function generateReferralCode(displayName: string): string {
  const cleanName = displayName.replace(/[^a-zA-Z]/g, '').slice(0, 4).toUpperCase() || 'MBM';
  const num = Math.floor(1000 + Math.random() * 9000);
  return `MBM${cleanName}${num}`;
}

export function buildStoreAffiliateUrl(originalUrl: string, storeName: string, subId: string = ''): string {
  let url = originalUrl.trim();
  const lowerStore = storeName.toLowerCase();

  // Amazon India URL handling:
  // Android phones intercept amazon.in and launch the Amazon App.
  // Amazon App crashes with error CS11 ("UH-OH Something went wrong") if invalid subid parameters are appended.
  // Standard affiliate parameter for Amazon India is tag=...
  if (lowerStore.includes('amazon') || url.includes('amazon.in')) {
    try {
      const parsed = new URL(url);
      parsed.searchParams.set('tag', 'mebuymoney-21');
      parsed.searchParams.delete('subid');
      parsed.searchParams.delete('subId');
      parsed.searchParams.delete('sub_id');
      return parsed.toString();
    } catch {
      return url.includes('?') ? `${url}&tag=mebuymoney-21` : `${url}?tag=mebuymoney-21`;
    }
  }

  if (subId) {
    if (url.includes('{SUB_ID}')) {
      return url.replace('{SUB_ID}', subId);
    }
    const separator = url.includes('?') ? '&' : '?';
    return `${url}${separator}subid=${subId}`;
  }

  return url;
}

// ---------------- REWARD LINK REQUEST SYSTEM ---------------- //

export async function submitRewardLinkRequest(
  userId: string,
  userEmail: string,
  productUrl: string
): Promise<RewardLinkRequest> {
  const trimmedUrl = productUrl.trim();
  if (!trimmedUrl || (!trimmedUrl.startsWith('http://') && !trimmedUrl.startsWith('https://'))) {
    throw new Error('Please enter a valid product URL starting with http:// or https://');
  }

  const trimmedEmail = userEmail.trim();
  if (!trimmedEmail || !trimmedEmail.includes('@')) {
    throw new Error('Please enter a valid email address');
  }

  const existingRequests = await getUserRewardLinkRequests(userId);
  const hasActivePending = existingRequests.some((r) => r.status === 'Pending');
  if (hasActivePending) {
    throw new Error(
      'You already have an active Reward Link request being prepared. Please wait for admin processing.'
    );
  }

  const storeName = detectStoreName(trimmedUrl);
  const requestId = `MBM_REQ_${Math.floor(10000 + Math.random() * 90000)}`;
  const now = new Date().toISOString();

  const request: RewardLinkRequest = {
    id: requestId,
    userId,
    userEmail: trimmedEmail,
    productUrl: trimmedUrl,
    storeName,
    productTitle: `${storeName} Product`,
    status: 'Pending',
    submittedAt: now,
    clickCount: 0,
  };

  const initialTxn: Transaction = {
    id: `txn_${requestId}`,
    userId,
    userEmail: trimmedEmail,
    requestId,
    clickId: `clk_${requestId}`,
    trackingSubId: generateTrackingSubId(userId),
    networkId: 'net_auto',
    storeName,
    productId: requestId,
    productTitle: `${storeName} Product Link`,
    orderAmount: 0,
    affiliateCommission: 0,
    userCashbackAmount: 0,
    platformShareAmount: 0,
    currency: 'INR',
    status: 'Link Requested',
    orderDate: now,
    notes: `Product URL submitted: ${trimmedUrl}`,
    createdAt: now,
  };

  // 1. Save to local demo cache immediately so UI feels instantaneous
  addDemoRewardRequest(request);
  addDemoTransaction(initialTxn);
  addDemoNotification({
    id: `notif_${Date.now()}`,
    userId,
    title: `Reward Link Requested: ${storeName} 🔗`,
    message: `Your request for ${storeName} is being prepared. Your tracked affiliate link will appear in your Inbox.`,
    type: 'reward_link',
    isRead: false,
    createdAt: now,
  });

  // 2. Persist to live Firebase Firestore so Admin Panel receives it in real time
  try {
    await setDoc(doc(db, 'reward_link_requests', requestId), request);
    await setDoc(doc(db, 'transactions', `txn_${requestId}`), initialTxn);
  } catch (error) {
    console.warn('Firestore sync note (persisted to local queue):', error);
  }

  return request;
}

export async function getUserRewardLinkRequests(userId: string): Promise<RewardLinkRequest[]> {
  const localList = getDemoRewardRequests().filter((r) => r.userId === userId || userId === 'demo_shopper_01');
  try {
    const q = query(collection(db, 'reward_link_requests'), where('userId', '==', userId));
    const snap = await getDocs(q);
    const remoteList = snap.docs.map((d) => ({ ...d.data(), id: d.id } as RewardLinkRequest));
    
    // Merge remote & local deduplicated by id
    const map = new Map<string, RewardLinkRequest>();
    for (const r of localList) map.set(r.id, r);
    for (const r of remoteList) map.set(r.id, r);
    return Array.from(map.values()).sort(
      (a, b) => new Date(b.submittedAt).getTime() - new Date(a.submittedAt).getTime()
    );
  } catch (error) {
    return localList;
  }
}

export async function getAllRewardLinkRequests(): Promise<RewardLinkRequest[]> {
  const localList = getDemoRewardRequests();
  try {
    const snap = await getDocs(collection(db, 'reward_link_requests'));
    const remoteList = snap.docs.map((d) => ({ ...d.data(), id: d.id } as RewardLinkRequest));
    
    // Merge remote & local deduplicated by id
    const map = new Map<string, RewardLinkRequest>();
    for (const r of localList) map.set(r.id, r);
    for (const r of remoteList) map.set(r.id, r);
    return Array.from(map.values()).sort(
      (a, b) => new Date(b.submittedAt).getTime() - new Date(a.submittedAt).getTime()
    );
  } catch (error) {
    return localList;
  }
}

export async function adminSendRewardLink(
  requestId: string,
  affiliateUrl: string,
  adminEmail: string,
  notes?: string
): Promise<void> {
  const trimmedAff = affiliateUrl.trim();
  if (!trimmedAff.startsWith('http://') && !trimmedAff.startsWith('https://')) {
    throw new Error('Please enter a valid affiliate URL starting with http:// or https://');
  }

  const now = new Date().toISOString();
  const all = await getAllRewardLinkRequests();
  const req = all.find((r) => r.id === requestId);
  if (!req) throw new Error('Request not found');

  const inboxItem: UserInboxItem = {
    id: `inbox_${requestId}`,
    userId: req.userId,
    requestId,
    productUrl: req.productUrl,
    affiliateUrl: trimmedAff,
    storeName: req.storeName,
    productTitle: req.productTitle || `${req.storeName} Deal`,
    status: 'Completed',
    receivedAt: now,
    isRead: false,
    clickCount: 0,
  };

  // Update in local cache
  updateDemoRewardRequest(requestId, {
    status: 'Completed',
    affiliateUrl: trimmedAff,
    completedAt: now,
    notes: notes || req.notes,
  });
  addDemoInboxItem(inboxItem);
  updateDemoTransaction(`txn_${requestId}`, {
    status: 'Link Sent',
    updatedAt: now,
    notes: `Affiliate link sent by admin: ${trimmedAff}`,
  });
  addDemoNotification({
    id: `notif_${Date.now()}`,
    userId: req.userId,
    title: `Your Reward Link is Ready! 🎉`,
    message: `Admin has generated your affiliate link for ${req.storeName}. Check My Inbox to shop with cashback!`,
    type: 'reward_link',
    isRead: false,
    createdAt: now,
  });

  // Also persist to live Firestore
  try {
    await updateDoc(doc(db, 'reward_link_requests', requestId), {
      status: 'Completed',
      affiliateUrl: trimmedAff,
      completedAt: now,
      notes: notes || req.notes || '',
    });
    await setDoc(doc(db, 'user_inbox', `inbox_${requestId}`), inboxItem);
    await updateDoc(doc(db, 'transactions', `txn_${requestId}`), {
      status: 'Link Sent',
      updatedAt: now,
      notes: `Affiliate link sent by admin: ${trimmedAff}`,
    });
  } catch (e) {
    console.warn('Firestore update notice (persisted locally):', e);
  }
  await logAuditEvent(
    'admin',
    adminEmail,
    'SEND_REWARD_LINK',
    `reward_link_requests/${requestId}`,
    `Sent affiliate link for ${req.storeName} to user ${req.userEmail}`
  );
}

export async function adminRejectRewardLink(
  requestId: string,
  rejectionReason: string,
  adminEmail: string
): Promise<void> {
  const now = new Date().toISOString();

  if (!auth.currentUser) {
    const all = getDemoRewardRequests();
    const req = all.find((r) => r.id === requestId);
    if (!req) throw new Error('Request not found');

    updateDemoRewardRequest(requestId, {
      status: 'Rejected',
      rejectionReason,
      completedAt: now,
    });

    updateDemoTransaction(`txn_${requestId}`, {
      status: 'Cashback Rejected',
      rejectionReason,
      updatedAt: now,
    });

    addDemoNotification({
      id: `notif_${Date.now()}`,
      userId: req.userId,
      title: `Reward Link Request Update`,
      message: `Your request for ${req.storeName} could not be fulfilled: ${rejectionReason}`,
      type: 'reward_link',
      isRead: false,
      createdAt: now,
    });

    return;
  }

  const reqRef = doc(db, 'reward_link_requests', requestId);
  const reqSnap = await getDoc(reqRef);
  if (!reqSnap.exists()) throw new Error('Request not found');
  const req = reqSnap.data() as RewardLinkRequest;

  await updateDoc(reqRef, {
    status: 'Rejected',
    rejectionReason,
    completedAt: now,
  });

  try {
    await updateDoc(doc(db, 'transactions', `txn_${requestId}`), {
      status: 'Cashback Rejected',
      rejectionReason,
      updatedAt: now,
    });
  } catch {}

  await addNotification(
    req.userId,
    `Reward Link Request Update`,
    `Your request for ${req.storeName} could not be fulfilled: ${rejectionReason}`,
    'reward_link'
  );

  await logAuditEvent(
    'admin',
    adminEmail,
    'REJECT_REWARD_LINK',
    `reward_link_requests/${requestId}`,
    `Rejected request: ${rejectionReason}`
  );
}

// ---------------- USER INBOX ---------------- //

export async function getUserInbox(userId: string): Promise<UserInboxItem[]> {
  const localList = getDemoInbox(userId);
  try {
    const q = query(collection(db, 'user_inbox'), where('userId', '==', userId));
    const snap = await getDocs(q);
    const remoteList = snap.docs.map((d) => ({ ...d.data(), id: d.id } as UserInboxItem));
    const map = new Map<string, UserInboxItem>();
    for (const item of localList) map.set(item.id, item);
    for (const item of remoteList) map.set(item.id, item);
    return Array.from(map.values()).sort(
      (a, b) => new Date(b.receivedAt).getTime() - new Date(a.receivedAt).getTime()
    );
  } catch (error) {
    return localList;
  }
}

export async function markInboxItemRead(inboxId: string): Promise<void> {
  updateDemoInboxItem(inboxId, { isRead: true });
  if (auth.currentUser) {
    try {
      await updateDoc(doc(db, 'user_inbox', inboxId), { isRead: true });
    } catch {}
  }
}

export async function openUserRewardLink(
  requestId: string,
  inboxId: string,
  userId: string,
  affiliateUrl: string
): Promise<void> {
  const storeName = detectStoreName(affiliateUrl);
  const cleanUrl = buildStoreAffiliateUrl(affiliateUrl, storeName);
  const now = new Date().toISOString();
  const sevenDaysLater = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString();

  // 1. Record click event
  const clickId = `clk_${Date.now()}`;
  const clickRecord: ClickRecord = {
    id: clickId,
    userId,
    requestId,
    productTitle: `Reward Link #${requestId}`,
    storeName,
    trackingSubId: generateTrackingSubId(userId),
    destinationUrl: cleanUrl,
    userAgent: navigator.userAgent || 'Browser',
    timestamp: now,
    status: 'tracked',
  };

  // 2. Open link in external window safely
  window.open(cleanUrl, '_blank', 'noopener,noreferrer');

  // 3. Prepare or update the 7-day pending order transaction record
  const txnId = `txn_${requestId}`;
  const orderTrackingRecord: Transaction = {
    id: txnId,
    userId,
    userEmail: 'shopper@mebuymoney.com',
    requestId,
    clickId,
    trackingSubId: generateTrackingSubId(userId),
    networkId: storeName.toLowerCase().includes('amazon') ? 'net_amazon' : 'net_flipkart',
    storeName,
    productId: requestId,
    productTitle: `${storeName} Order Tracking`,
    orderAmount: 0,
    affiliateCommission: 0,
    userCashbackAmount: 0,
    platformShareAmount: 0,
    currency: 'INR',
    status: 'Purchase Tracking Pending',
    orderDate: now,
    clickedAt: now,
    verificationDays: 7,
    verificationDeadline: sevenDaysLater,
    affiliateUrl: cleanUrl,
    notes: 'Order link clicked by user. 7-day verification pending.',
    createdAt: now,
    updatedAt: now,
  };

  // 4. Update local demo state
  updateDemoRewardRequest(requestId, {
    clickCount: 1,
    lastClickedAt: now,
  });
  updateDemoInboxItem(inboxId, {
    isRead: true,
    clickCount: 1,
    lastClickedAt: now,
  });

  const existingDemoTxns = getDemoTransactions();
  const existingIdx = existingDemoTxns.findIndex((t) => t.id === txnId || t.requestId === requestId);
  if (existingIdx >= 0) {
    updateDemoTransaction(existingDemoTxns[existingIdx].id, {
      status: 'Purchase Tracking Pending',
      clickedAt: now,
      verificationDays: 7,
      verificationDeadline: sevenDaysLater,
      affiliateUrl: cleanUrl,
      notes: 'Order link clicked by user. 7-day verification pending.',
      updatedAt: now,
    });
  } else {
    addDemoTransaction(orderTrackingRecord);
  }

  addDemoNotification({
    id: `notif_${Date.now()}`,
    userId,
    title: `Order Clicked — 7 Days Tracking Active 🛒`,
    message: `Aapka ${storeName} link click track ho gaya hai! 7 din ka verification window shuru ho gaya hai. Admin verification ke baad cashback aapke wallet me credit ho jayega.`,
    type: 'cashback',
    isRead: false,
    createdAt: now,
  });

  // 5. Persist to live Firebase Firestore
  try {
    await setDoc(doc(db, 'clicks', clickId), clickRecord);
    await setDoc(doc(db, 'transactions', txnId), orderTrackingRecord, { merge: true });
    await updateDoc(doc(db, 'reward_link_requests', requestId), {
      lastClickedAt: now,
    });
    await updateDoc(doc(db, 'user_inbox', inboxId), {
      isRead: true,
      lastClickedAt: now,
    });
  } catch (e) {
    console.warn('Recorded click in local state fallback:', e);
  }
}

// ---------------- PREMIUM DEALS ---------------- //

export async function getPremiumDeals(): Promise<PremiumDeal[]> {
  try {
    const snap = await getDocs(collection(db, 'premium_deals'));
    if (!snap.empty) {
      const list = snap.docs.map((d) => ({ ...d.data(), id: d.id } as PremiumDeal));
      return list.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
    }
  } catch (error) {
    console.warn('Failed to load premium deals from Firestore, using seed:', error);
  }
  return getDemoPremiumDeals();
}

export async function savePremiumDeal(deal: PremiumDeal, adminEmail: string): Promise<void> {
  const path = `premium_deals/${deal.id}`;
  if (auth.currentUser) {
    try {
      await setDoc(doc(db, 'premium_deals', deal.id), deal, { merge: true });
    } catch {}
  }
  const current = getDemoPremiumDeals();
  const existingIdx = current.findIndex((d) => d.id === deal.id);
  if (existingIdx >= 0) {
    current[existingIdx] = deal;
  } else {
    current.unshift(deal);
  }
  saveDemoPremiumDeals(current);

  await logAuditEvent('admin', adminEmail, 'SAVE_PREMIUM_DEAL', path, `Saved deal: ${deal.title}`);
}

export async function deletePremiumDeal(dealId: string, adminEmail: string): Promise<void> {
  if (auth.currentUser) {
    try {
      await deleteDoc(doc(db, 'premium_deals', dealId));
    } catch {}
  }
  const current = getDemoPremiumDeals().filter((d) => d.id !== dealId);
  saveDemoPremiumDeals(current);
  await logAuditEvent('admin', adminEmail, 'DELETE_PREMIUM_DEAL', `premium_deals/${dealId}`, `Deleted deal ID ${dealId}`);
}

// ---------------- PLATFORM & CATALOG (PUBLIC READABLE) ---------------- //

export async function getPlatformSettings(): Promise<PlatformSettings> {
  try {
    const docRef = doc(db, 'settings', 'platform');
    const snap = await getDoc(docRef);
    if (snap.exists()) {
      return snap.data() as PlatformSettings;
    }
    return DEFAULT_PLATFORM_SETTINGS;
  } catch (error) {
    return DEFAULT_PLATFORM_SETTINGS;
  }
}

export async function updatePlatformSettings(settings: PlatformSettings, adminEmail: string): Promise<void> {
  const path = 'settings/platform';
  try {
    if (auth.currentUser) {
      await setDoc(doc(db, 'settings', 'platform'), settings, { merge: true });
    }
    await logAuditEvent(
      'admin',
      adminEmail,
      'UPDATE_SETTINGS',
      'settings/platform',
      `Updated platform settings: Min withdrawal ₹${settings.minWithdrawalAmount}, User Share ${settings.defaultUserCashbackShare}%`
    );
  } catch (error) {}
}

export async function getCategories(): Promise<Category[]> {
  try {
    const snap = await getDocs(collection(db, 'categories'));
    if (!snap.empty) {
      const list = snap.docs.map((d) => ({ ...d.data(), id: d.id } as Category));
      return list.sort((a, b) => (a.sortOrder || 0) - (b.sortOrder || 0));
    }
  } catch (error) {}
  return INITIAL_CATEGORIES;
}

export async function getAffiliateNetworks(): Promise<AffiliateNetwork[]> {
  try {
    const snap = await getDocs(collection(db, 'affiliate_networks'));
    if (!snap.empty) {
      return snap.docs.map((d) => ({ ...d.data(), id: d.id } as AffiliateNetwork));
    }
  } catch (error) {}
  return INITIAL_NETWORKS;
}

export async function getProducts(): Promise<Product[]> {
  try {
    const snap = await getDocs(collection(db, 'products'));
    if (!snap.empty) {
      return snap.docs.map((d) => ({ ...d.data(), id: d.id } as Product));
    }
  } catch (error) {}
  return INITIAL_PRODUCTS;
}

export async function getBanners(): Promise<Banner[]> {
  try {
    const snap = await getDocs(collection(db, 'banners'));
    if (!snap.empty) {
      const list = snap.docs.map((d) => ({ ...d.data(), id: d.id } as Banner));
      return list.sort((a, b) => (a.sortOrder || 0) - (b.sortOrder || 0));
    }
  } catch (error) {}
  return INITIAL_BANNERS;
}

export async function seedInitialDataIfEmpty(): Promise<boolean> {
  try {
    const prodSnap = await getDocs(collection(db, 'products'));
    if (prodSnap.empty && auth.currentUser) {
      for (const cat of INITIAL_CATEGORIES) {
        await setDoc(doc(db, 'categories', cat.id), cat);
      }
      for (const net of INITIAL_NETWORKS) {
        await setDoc(doc(db, 'affiliate_networks', net.id), net);
      }
      for (const prod of INITIAL_PRODUCTS) {
        await setDoc(doc(db, 'products', prod.id), prod);
      }
      for (const prem of INITIAL_PREMIUM_DEALS) {
        await setDoc(doc(db, 'premium_deals', prem.id), prem);
      }
      for (const ban of INITIAL_BANNERS) {
        await setDoc(doc(db, 'banners', ban.id), ban);
      }
      await setDoc(doc(db, 'settings', 'platform'), DEFAULT_PLATFORM_SETTINGS);
      return true;
    }
  } catch (e) {}
  return false;
}

// ---------------- USER & WALLET ---------------- //

export async function getUserProfile(userId: string): Promise<UserProfile | null> {
  if (isDemoOrUnauthenticated(userId)) {
    return null;
  }
  const path = `users/${userId}`;
  try {
    const snap = await getDoc(doc(db, 'users', userId));
    if (snap.exists()) {
      return snap.data() as UserProfile;
    }
    return null;
  } catch (error) {
    return null;
  }
}

export async function createUserProfileAndWallet(
  userId: string,
  email: string,
  displayName: string,
  referredBy?: string
): Promise<{ profile: UserProfile; wallet: Wallet }> {
  const isAdminEmail = email.toLowerCase() === 'crm33424@gmail.com';
  const referralCode = generateReferralCode(displayName);
  const now = new Date().toISOString();

  const newProfile: UserProfile = {
    id: userId,
    email,
    displayName: displayName || email.split('@')[0],
    role: isAdminEmail ? 'admin' : 'user',
    referralCode,
    referredBy: referredBy || '',
    createdAt: now,
  };

  const newWallet: Wallet = {
    userId,
    pendingCashback: 0,
    confirmedCashback: 50,
    availableBalance: 50,
    totalEarned: 50,
    totalWithdrawn: 0,
    rejectedCashback: 0,
    updatedAt: now,
  };

  const welcomeTxn: Transaction = {
    id: `txn_welcome_${Date.now()}`,
    userId,
    userEmail: email,
    clickId: `clk_bonus_${userId}`,
    trackingSubId: referralCode,
    networkId: 'direct',
    storeName: 'Me BUY MONEY Welcome Bonus',
    productId: 'bonus_50',
    productTitle: 'Welcome Signup Bonus Credited',
    orderAmount: 0,
    affiliateCommission: 50,
    userCashbackAmount: 50,
    platformShareAmount: 0,
    currency: 'INR',
    status: 'Cashback Confirmed',
    orderDate: now,
    createdAt: now,
    updatedAt: now,
  };

  if (isDemoOrUnauthenticated(userId)) {
    saveDemoWallet(newWallet);
    addDemoTransaction(welcomeTxn);
    return { profile: newProfile, wallet: newWallet };
  }

  const userPath = `users/${userId}`;
  try {
    await setDoc(doc(db, 'users', userId), newProfile);
    await setDoc(doc(db, 'wallets', userId), newWallet);
    await setDoc(doc(db, 'transactions', welcomeTxn.id), welcomeTxn).catch(() => {});

    if (isAdminEmail) {
      await setDoc(doc(db, 'admins', userId), {
        email,
        addedAt: now,
      });
    }

    await addNotification(
      userId,
      'Welcome to Me BUY MONEY! 💰',
      'Congratulations! ₹50 Signup Bonus has been credited to your available balance. Paste any product URL into Reward Link to start earning real cash on every shopping order!',
      'system'
    );

    return { profile: newProfile, wallet: newWallet };
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, userPath);
  }
}

export async function getUserWallet(userId: string): Promise<Wallet> {
  if (isDemoOrUnauthenticated(userId)) {
    return getDemoWallet(userId);
  }

  const path = `wallets/${userId}`;
  try {
    const snap = await getDoc(doc(db, 'wallets', userId));
    if (snap.exists()) {
      return snap.data() as Wallet;
    }
    return getDemoWallet(userId);
  } catch (error) {
    return getDemoWallet(userId);
  }
}

export async function updateUserPaymentPreferences(
  userId: string,
  upiId?: string,
  phone?: string
): Promise<void> {
  if (isDemoOrUnauthenticated(userId)) {
    return;
  }
  const path = `users/${userId}`;
  try {
    const updates: Partial<UserProfile> = {
      updatedAt: new Date().toISOString(),
    };
    if (upiId !== undefined) updates.upiId = upiId;
    if (phone !== undefined) updates.phone = phone;

    await updateDoc(doc(db, 'users', userId), updates);
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, path);
  }
}

// ---------------- AFFILIATE TRACKING & CLICKS ---------------- //

export async function recordAffiliateClick(
  userId: string,
  product: Product,
  network: AffiliateNetwork
): Promise<{ trackingSubId: string; trackedUrl: string }> {
  const trackingSubId = generateTrackingSubId(userId);
  const clickId = `clk_${Date.now()}_${Math.random().toString(36).substr(2, 6)}`;
  const now = new Date().toISOString();

  let trackedUrl = product.affiliateUrl;
  if (trackedUrl.includes('{SUB_ID}')) {
    trackedUrl = trackedUrl.replace('{SUB_ID}', trackingSubId);
  } else {
    const separator = trackedUrl.includes('?') ? '&' : '?';
    const param = network.trackingParamName || 'subid';
    trackedUrl = `${trackedUrl}${separator}${param}=${trackingSubId}`;
  }

  const clickRecord: ClickRecord = {
    id: clickId,
    userId,
    productId: product.id,
    productTitle: product.title,
    storeName: product.storeName,
    networkId: product.networkId,
    trackingSubId,
    destinationUrl: trackedUrl,
    userAgent: navigator.userAgent || 'Web Browser',
    timestamp: now,
    status: 'tracked',
  };

  const transactionId = `txn_${clickId}`;
  const initialTxn: Transaction = {
    id: transactionId,
    userId,
    userEmail: '',
    clickId,
    trackingSubId,
    networkId: product.networkId,
    storeName: product.storeName,
    productId: product.id,
    productTitle: product.title,
    orderAmount: product.dealPrice,
    affiliateCommission: 0,
    userCashbackAmount: 0,
    platformShareAmount: 0,
    currency: 'INR',
    status: 'Link Clicked',
    orderDate: now,
    createdAt: now,
  };

  if (isDemoOrUnauthenticated(userId)) {
    addDemoTransaction(initialTxn);
    addDemoNotification({
      id: `notif_${Date.now()}`,
      userId,
      title: `Cashback Activated for ${product.storeName}! 🛍️`,
      message: `Tracking Sub-ID: ${trackingSubId}. Complete your order to ensure cashback tracks within 48 hours.`,
      type: 'click',
      isRead: false,
      createdAt: now,
    });
    return { trackingSubId, trackedUrl };
  }

  const path = `clicks/${clickId}`;
  try {
    await setDoc(doc(db, 'clicks', clickId), clickRecord);
    await setDoc(doc(db, 'transactions', transactionId), initialTxn);
    await addNotification(
      userId,
      `Cashback Activated for ${product.storeName}! 🛍️`,
      `Tracking Sub-ID: ${trackingSubId}. Complete your order to ensure cashback tracks within 48 hours.`,
      'click'
    );
  } catch (error) {
    addDemoTransaction(initialTxn);
  }

  return { trackingSubId, trackedUrl };
}

export async function getUserTransactions(userId: string): Promise<Transaction[]> {
  const localList = getDemoTransactions().filter(
    (t) => t.userId === userId || userId === 'demo_shopper_01' || !t.userId
  );
  try {
    const snap = await getDocs(collection(db, 'transactions'));
    const remoteList = snap.docs
      .map((d) => ({ ...d.data(), id: d.id } as Transaction))
      .filter((t) => t.userId === userId || userId === 'demo_shopper_01' || !t.userId);
    const map = new Map<string, Transaction>();
    for (const t of localList) map.set(t.id, t);
    for (const t of remoteList) map.set(t.id, t);
    return Array.from(map.values()).sort(
      (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
    );
  } catch (error) {
    return localList;
  }
}

// ---------------- MISSING CASHBACK / ORDER CLAIM ---------------- //

export async function submitMissingOrderClaim(
  userId: string,
  userEmail: string,
  storeName: string,
  networkId: string,
  orderId: string,
  orderAmount: number,
  orderDate: string,
  clickSubId: string,
  notes: string
): Promise<Transaction> {
  const txnId = `claim_${Date.now()}_${Math.random().toString(36).substr(2, 6)}`;
  const now = new Date().toISOString();

  const estAffiliateCommission = Math.round(orderAmount * 0.08 * 100) / 100;
  const estUserCashback = Math.round(estAffiliateCommission * 0.4 * 100) / 100;
  const estPlatformShare = Math.round((estAffiliateCommission - estUserCashback) * 100) / 100;

  const newTxn: Transaction = {
    id: txnId,
    userId,
    userEmail,
    clickId: clickSubId || 'manual_claim',
    trackingSubId: clickSubId || `CLAIM_${orderId}`,
    networkId,
    storeName,
    productId: 'custom_order',
    productTitle: `Order #${orderId} from ${storeName}`,
    orderAmount,
    affiliateCommission: estAffiliateCommission,
    userCashbackAmount: estUserCashback,
    platformShareAmount: estPlatformShare,
    currency: 'INR',
    status: 'Purchase Tracking Pending',
    networkOrderId: orderId,
    orderDate,
    notes: `User submitted missing order claim. Note: ${notes}`,
    createdAt: now,
    updatedAt: now,
  };

  if (isDemoOrUnauthenticated(userId)) {
    addDemoTransaction(newTxn);
    const currentWallet = getDemoWallet(userId);
    currentWallet.pendingCashback = Math.round((currentWallet.pendingCashback + estUserCashback) * 100) / 100;
    saveDemoWallet(currentWallet);
    addDemoNotification({
      id: `notif_${Date.now()}`,
      userId,
      title: `Missing Cashback Claim Received for ${storeName}`,
      message: `Your claim for Order #${orderId} (₹${orderAmount}) is marked 'Purchase Tracking Pending'. We will reconcile this with the network report.`,
      type: 'order',
      isRead: false,
      createdAt: now,
    });
    return newTxn;
  }

  const path = `transactions/${txnId}`;
  try {
    await setDoc(doc(db, 'transactions', txnId), newTxn);

    const walletSnap = await getDoc(doc(db, 'wallets', userId));
    if (walletSnap.exists()) {
      const currentWallet = walletSnap.data() as Wallet;
      await updateDoc(doc(db, 'wallets', userId), {
        pendingCashback: Math.round((currentWallet.pendingCashback + estUserCashback) * 100) / 100,
        updatedAt: now,
      });
    }

    await addNotification(
      userId,
      `Missing Cashback Claim Received for ${storeName}`,
      `Your claim for Order #${orderId} (₹${orderAmount}) is marked 'Purchase Tracking Pending'.`,
      'order'
    );

    return newTxn;
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, path);
  }
}

// ---------------- WITHDRAWALS ---------------- //

export async function requestWithdrawal(
  userId: string,
  userEmail: string,
  amount: number,
  method: 'UPI' | 'BANK',
  payoutDetails: {
    upiId?: string;
    accountHolder?: string;
    accountNumber?: string;
    ifscCode?: string;
    bankName?: string;
  }
): Promise<WithdrawalRequest> {
  const wallet = await getUserWallet(userId);
  const settings = await getPlatformSettings();

  if (amount < settings.minWithdrawalAmount) {
    throw new Error(`Minimum withdrawal amount is ₹${settings.minWithdrawalAmount}.`);
  }

  if (amount > wallet.availableBalance) {
    throw new Error(`Insufficient available balance. Your balance is ₹${wallet.availableBalance.toFixed(2)}.`);
  }

  const withdrawalId = `wth_${Date.now()}_${Math.random().toString(36).substr(2, 6)}`;
  const now = new Date().toISOString();

  const request: WithdrawalRequest = {
    id: withdrawalId,
    userId,
    userEmail,
    amount,
    method,
    payoutDetails,
    status: 'Pending',
    requestedAt: now,
  };

  if (isDemoOrUnauthenticated(userId)) {
    addDemoWithdrawal(request);
    const newAvailable = Math.round((wallet.availableBalance - amount) * 100) / 100;
    wallet.availableBalance = newAvailable;
    wallet.updatedAt = now;
    saveDemoWallet(wallet);

    addDemoNotification({
      id: `notif_${Date.now()}`,
      userId,
      title: `Withdrawal Requested: ₹${amount}`,
      message: `Your request to withdraw ₹${amount} via ${method} has been received. Payout is processed within 1-3 business days.`,
      type: 'withdrawal',
      isRead: false,
      createdAt: now,
    });
    return request;
  }

  const path = `withdrawals/${withdrawalId}`;
  try {
    await setDoc(doc(db, 'withdrawals', withdrawalId), request);

    const newAvailable = Math.round((wallet.availableBalance - amount) * 100) / 100;
    await updateDoc(doc(db, 'wallets', userId), {
      availableBalance: newAvailable,
      updatedAt: now,
    });

    await addNotification(
      userId,
      `Withdrawal Requested: ₹${amount}`,
      `Your request to withdraw ₹${amount} via ${method} has been received.`,
      'withdrawal'
    );

    return request;
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, path);
  }
}

export async function getUserWithdrawals(userId: string): Promise<WithdrawalRequest[]> {
  if (isDemoOrUnauthenticated(userId)) {
    return getDemoWithdrawals();
  }

  const path = 'withdrawals';
  try {
    const q = query(collection(db, 'withdrawals'), where('userId', '==', userId));
    const snap = await getDocs(q);
    const list = snap.docs.map((d) => ({ ...d.data(), id: d.id } as WithdrawalRequest));
    return list.sort((a, b) => new Date(b.requestedAt).getTime() - new Date(a.requestedAt).getTime());
  } catch (error) {
    return getDemoWithdrawals();
  }
}

// ---------------- REFERRALS ---------------- //

export async function getUserReferrals(userId: string): Promise<Referral[]> {
  if (isDemoOrUnauthenticated(userId)) {
    return [
      {
        id: 'ref_sample_01',
        referrerId: userId,
        referredUserId: 'user_priya_88',
        referredEmail: 'priya.k@gmail.com',
        status: 'rewarded',
        rewardAmount: 50,
        isPaid: true,
        createdAt: new Date(Date.now() - 10 * 24 * 60 * 60 * 1000).toISOString(),
      },
      {
        id: 'ref_sample_02',
        referrerId: userId,
        referredUserId: 'user_amit_12',
        referredEmail: 'amit.verma@yahoo.com',
        status: 'registered',
        rewardAmount: 50,
        isPaid: false,
        createdAt: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000).toISOString(),
      },
    ];
  }

  const path = 'referrals';
  try {
    const q = query(collection(db, 'referrals'), where('referrerId', '==', userId));
    const snap = await getDocs(q);
    return snap.docs.map((d) => ({ ...d.data(), id: d.id } as Referral));
  } catch (error) {
    return [];
  }
}

// ---------------- NOTIFICATIONS ---------------- //

export async function addNotification(
  userId: string,
  title: string,
  message: string,
  type: AppNotification['type'],
  link?: string
): Promise<void> {
  const id = `notif_${Date.now()}_${Math.random().toString(36).substr(2, 6)}`;
  const notif: AppNotification = {
    id,
    userId,
    title,
    message,
    type,
    isRead: false,
    link,
    createdAt: new Date().toISOString(),
  };

  if (isDemoOrUnauthenticated(userId)) {
    addDemoNotification(notif);
    return;
  }

  try {
    await setDoc(doc(db, 'notifications', id), notif);
  } catch (error) {
    addDemoNotification(notif);
  }
}

export async function getUserNotifications(userId: string): Promise<AppNotification[]> {
  if (isDemoOrUnauthenticated(userId)) {
    return getDemoNotifications();
  }

  const path = 'notifications';
  try {
    const q = query(collection(db, 'notifications'), where('userId', '==', userId));
    const snap = await getDocs(q);
    const list = snap.docs.map((d) => ({ ...d.data(), id: d.id } as AppNotification));
    return list.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  } catch (error) {
    return getDemoNotifications();
  }
}

export async function markNotificationAsRead(notificationId: string): Promise<void> {
  markDemoNotificationRead(notificationId);
  if (auth.currentUser) {
    try {
      await updateDoc(doc(db, 'notifications', notificationId), { isRead: true });
    } catch (e) {}
  }
}

// ---------------- AUDIT LOGS ---------------- //

export async function logAuditEvent(
  actorId: string,
  actorEmail: string,
  action: string,
  targetResource: string,
  details: string
): Promise<void> {
  const id = `audit_${Date.now()}_${Math.random().toString(36).substr(2, 6)}`;
  const log: AuditLog = {
    id,
    actorId,
    actorEmail,
    action,
    targetResource,
    details,
    timestamp: new Date().toISOString(),
  };

  if (auth.currentUser) {
    try {
      await setDoc(doc(db, 'audit_logs', id), log);
    } catch (e) {}
  }
}

// ---------------- ADMIN PANEL OPERATIONS ---------------- //

export async function getAdminDashboardStats(): Promise<{
  totalUsers: number;
  totalRewardRequests: number;
  pendingRewardRequests: number;
  completedRewardRequests: number;
  totalClicks: number;
  totalTransactions: number;
  pendingCashback: number;
  confirmedCashback: number;
  totalWithdrawn: number;
  grossCommission: number;
  platformRevenue: number;
}> {
  if (!auth.currentUser) {
    const reqs = getDemoRewardRequests();
    const txns = getDemoTransactions();
    const wths = getDemoWithdrawals();
    let pending = 0;
    let confirmed = 0;
    let gross = 0;
    let rev = 0;
    txns.forEach((t) => {
      gross += t.affiliateCommission || 0;
      rev += t.platformShareAmount || 0;
      if (t.status === 'Cashback Pending' || t.status === 'Purchase Tracking Pending' || t.status === 'Link Requested') {
        pending += t.userCashbackAmount || 0;
      } else if (t.status === 'Cashback Confirmed' || t.status === 'Cashback Paid') {
        confirmed += t.userCashbackAmount || 0;
      }
    });
    let withdrawn = 0;
    wths.forEach((w) => {
      if (w.status === 'Paid') withdrawn += w.amount;
    });

    return {
      totalUsers: 148,
      totalRewardRequests: reqs.length,
      pendingRewardRequests: reqs.filter((r) => r.status === 'Pending').length,
      completedRewardRequests: reqs.filter((r) => r.status === 'Completed').length,
      totalClicks: 342,
      totalTransactions: txns.length,
      pendingCashback: Math.round(pending * 100) / 100,
      confirmedCashback: Math.round(confirmed * 100) / 100,
      totalWithdrawn: Math.round(withdrawn * 100) / 100,
      grossCommission: Math.round(gross * 100) / 100,
      platformRevenue: Math.round(rev * 100) / 100,
    };
  }

  try {
    const [usersSnap, reqsSnap, clicksSnap, txnSnap, wthSnap] = await Promise.all([
      getDocs(collection(db, 'users')),
      getDocs(collection(db, 'reward_link_requests')),
      getDocs(collection(db, 'clicks')),
      getDocs(collection(db, 'transactions')),
      getDocs(collection(db, 'withdrawals')),
    ]);

    let pendingCashback = 0;
    let confirmedCashback = 0;
    let grossCommission = 0;
    let platformRevenue = 0;

    txnSnap.docs.forEach((docSnap) => {
      const data = docSnap.data() as Transaction;
      grossCommission += data.affiliateCommission || 0;
      platformRevenue += data.platformShareAmount || 0;
      if (data.status === 'Cashback Pending' || data.status === 'Purchase Tracking Pending') {
        pendingCashback += data.userCashbackAmount || 0;
      } else if (data.status === 'Cashback Confirmed' || data.status === 'Cashback Paid') {
        confirmedCashback += data.userCashbackAmount || 0;
      }
    });

    let totalWithdrawn = 0;
    wthSnap.docs.forEach((docSnap) => {
      const data = docSnap.data() as WithdrawalRequest;
      if (data.status === 'Paid') {
        totalWithdrawn += data.amount || 0;
      }
    });

    const reqs = reqsSnap.docs.map((d) => d.data() as RewardLinkRequest);

    return {
      totalUsers: Math.max(usersSnap.size, 1),
      totalRewardRequests: reqs.length,
      pendingRewardRequests: reqs.filter((r) => r.status === 'Pending').length,
      completedRewardRequests: reqs.filter((r) => r.status === 'Completed').length,
      totalClicks: clicksSnap.size,
      totalTransactions: txnSnap.size,
      pendingCashback: Math.round(pendingCashback * 100) / 100,
      confirmedCashback: Math.round(confirmedCashback * 100) / 100,
      totalWithdrawn: Math.round(totalWithdrawn * 100) / 100,
      grossCommission: Math.round(grossCommission * 100) / 100,
      platformRevenue: Math.round(platformRevenue * 100) / 100,
    };
  } catch (error) {
    return {
      totalUsers: 1,
      totalRewardRequests: 0,
      pendingRewardRequests: 0,
      completedRewardRequests: 0,
      totalClicks: 0,
      totalTransactions: 0,
      pendingCashback: 0,
      confirmedCashback: 0,
      totalWithdrawn: 0,
      grossCommission: 0,
      platformRevenue: 0,
    };
  }
}

export async function getAllTransactions(): Promise<Transaction[]> {
  const localList = getDemoTransactions();
  try {
    const snap = await getDocs(collection(db, 'transactions'));
    const remoteList = snap.docs.map((d) => ({ ...d.data(), id: d.id } as Transaction));
    const map = new Map<string, Transaction>();
    for (const t of localList) map.set(t.id, t);
    for (const t of remoteList) map.set(t.id, t);
    return Array.from(map.values()).sort(
      (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
    );
  } catch (error) {
    return localList;
  }
}

export async function getAllWithdrawals(): Promise<WithdrawalRequest[]> {
  if (!auth.currentUser) {
    return getDemoWithdrawals();
  }
  try {
    const snap = await getDocs(collection(db, 'withdrawals'));
    const list = snap.docs.map((d) => ({ ...d.data(), id: d.id } as WithdrawalRequest));
    return list.sort((a, b) => new Date(b.requestedAt).getTime() - new Date(a.requestedAt).getTime());
  } catch (error) {
    return getDemoWithdrawals();
  }
}

export async function getAllAuditLogs(): Promise<AuditLog[]> {
  if (!auth.currentUser) {
    return [
      {
        id: 'audit_init',
        actorId: 'admin_sys',
        actorEmail: 'system@mebuymoney.com',
        action: 'PLATFORM_BOOTSTRAP',
        targetResource: 'system',
        details: 'Me BUY MONEY core reward link engine operational.',
        timestamp: new Date().toISOString(),
      },
    ];
  }
  try {
    const snap = await getDocs(collection(db, 'audit_logs'));
    const list = snap.docs.map((d) => ({ ...d.data(), id: d.id } as AuditLog));
    return list.sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
  } catch (error) {
    return [];
  }
}

// Reconcile and update transaction status (Admin)
export async function reconcileTransactionStatus(
  transactionId: string,
  newStatus: OrderStatus,
  adminEmail: string,
  options?: {
    orderAmount?: number;
    affiliateCommission?: number;
    rejectionReason?: string;
    notes?: string;
  }
): Promise<void> {
  const now = new Date().toISOString();

  if (!auth.currentUser) {
    const all = getDemoTransactions();
    const txn = all.find((t) => t.id === transactionId);
    if (!txn) throw new Error('Transaction not found.');

    const oldStatus = txn.status;
    const commission = options?.affiliateCommission ?? txn.affiliateCommission;
    const userCashback = Math.round(commission * 0.4 * 100) / 100;
    const platformShare = Math.round((commission - userCashback) * 100) / 100;

    updateDemoTransaction(transactionId, {
      status: newStatus,
      updatedAt: now,
      reconciledBy: adminEmail,
      affiliateCommission: commission,
      userCashbackAmount: userCashback,
      platformShareAmount: platformShare,
      confirmationDate: newStatus === 'Cashback Confirmed' ? now : undefined,
      rejectionReason: options?.rejectionReason,
      notes: options?.notes,
    });

    const wallet = getDemoWallet(txn.userId);
    if (newStatus === 'Cashback Confirmed') {
      if (oldStatus === 'Cashback Pending' || oldStatus === 'Purchase Tracking Pending') {
        wallet.pendingCashback = Math.max(0, wallet.pendingCashback - (txn.userCashbackAmount || userCashback));
      }
      wallet.confirmedCashback += userCashback;
      wallet.availableBalance += userCashback;
      wallet.totalEarned += userCashback;
    } else if (newStatus === 'Cashback Rejected') {
      if (oldStatus === 'Cashback Pending' || oldStatus === 'Purchase Tracking Pending') {
        wallet.pendingCashback = Math.max(0, wallet.pendingCashback - (txn.userCashbackAmount || userCashback));
      }
      wallet.rejectedCashback += userCashback;
    }
    saveDemoWallet(wallet);

    addDemoNotification({
      id: `notif_${Date.now()}`,
      userId: txn.userId,
      title: `Order Status: ${newStatus}`,
      message:
        newStatus === 'Cashback Confirmed'
          ? `Hurray! ₹${userCashback} Cashback from ${txn.storeName} is CONFIRMED and added to your available withdrawal balance! 🎉`
          : `Your order with ${txn.storeName} status changed to ${newStatus}.`,
      type: 'cashback',
      isRead: false,
      createdAt: now,
    });

    return;
  }

  const txnRef = doc(db, 'transactions', transactionId);
  const txnSnap = await getDoc(txnRef);
  if (!txnSnap.exists()) {
    throw new Error('Transaction not found.');
  }

  const txn = txnSnap.data() as Transaction;
  const oldStatus = txn.status;

  let commission = options?.affiliateCommission ?? txn.affiliateCommission;
  let orderAmount = options?.orderAmount ?? txn.orderAmount;

  const userCashback = Math.round(commission * 0.4 * 100) / 100;
  const platformShare = Math.round((commission - userCashback) * 100) / 100;

  const updates: Partial<Transaction> = {
    status: newStatus,
    updatedAt: now,
    reconciledBy: adminEmail,
    orderAmount,
    affiliateCommission: commission,
    userCashbackAmount: userCashback,
    platformShareAmount: platformShare,
  };

  if (newStatus === 'Cashback Confirmed') {
    updates.confirmationDate = now;
  }
  if (options?.rejectionReason) {
    updates.rejectionReason = options.rejectionReason;
  }
  if (options?.notes) {
    updates.notes = options.notes;
  }

  await updateDoc(txnRef, updates);

  const walletRef = doc(db, 'wallets', txn.userId);
  const walletSnap = await getDoc(walletRef);

  if (walletSnap.exists()) {
    const wallet = walletSnap.data() as Wallet;
    let newPending = wallet.pendingCashback;
    let newConfirmed = wallet.confirmedCashback;
    let newAvailable = wallet.availableBalance;
    let newTotalEarned = wallet.totalEarned;
    let newRejected = wallet.rejectedCashback;

    if (newStatus === 'Cashback Pending' || newStatus === 'Purchase Tracking Pending') {
      if (oldStatus !== 'Cashback Pending' && oldStatus !== 'Purchase Tracking Pending') {
        newPending += userCashback;
      }
    } else if (newStatus === 'Cashback Confirmed') {
      if (oldStatus === 'Cashback Pending' || oldStatus === 'Purchase Tracking Pending') {
        newPending = Math.max(0, newPending - (txn.userCashbackAmount || userCashback));
      }
      newConfirmed += userCashback;
      newAvailable += userCashback;
      newTotalEarned += userCashback;
    } else if (newStatus === 'Cashback Rejected') {
      if (oldStatus === 'Cashback Pending' || oldStatus === 'Purchase Tracking Pending') {
        newPending = Math.max(0, newPending - (txn.userCashbackAmount || userCashback));
      }
      newRejected += userCashback;
    }

    await updateDoc(walletRef, {
      pendingCashback: Math.round(newPending * 100) / 100,
      confirmedCashback: Math.round(newConfirmed * 100) / 100,
      availableBalance: Math.round(newAvailable * 100) / 100,
      totalEarned: Math.round(newTotalEarned * 100) / 100,
      rejectedCashback: Math.round(newRejected * 100) / 100,
      updatedAt: now,
    });
  }

  let notifMsg = `Your order with ${txn.storeName} status changed to ${newStatus}.`;
  if (newStatus === 'Cashback Confirmed') {
    notifMsg = `Hurray! ₹${userCashback} Cashback from ${txn.storeName} is CONFIRMED and added to your available withdrawal balance! 🎉`;
  }
  await addNotification(txn.userId, `Order Status: ${newStatus}`, notifMsg, 'cashback');
}

// Process withdrawal request (Admin)
export async function processWithdrawalRequest(
  withdrawalId: string,
  newStatus: WithdrawalStatus,
  adminEmail: string,
  transactionReference?: string,
  adminNotes?: string
): Promise<void> {
  const now = new Date().toISOString();

  if (!auth.currentUser) {
    const all = getDemoWithdrawals();
    const wth = all.find((w) => w.id === withdrawalId);
    if (!wth) throw new Error('Withdrawal request not found.');

    updateDemoWithdrawal(withdrawalId, {
      status: newStatus,
      transactionReference: transactionReference || wth.transactionReference || '',
      adminNotes: adminNotes || wth.adminNotes || '',
      processedAt: now,
    });

    const wallet = getDemoWallet(wth.userId);
    if (newStatus === 'Rejected') {
      wallet.availableBalance = Math.round((wallet.availableBalance + wth.amount) * 100) / 100;
      saveDemoWallet(wallet);
    } else if (newStatus === 'Paid') {
      wallet.totalWithdrawn = Math.round((wallet.totalWithdrawn + wth.amount) * 100) / 100;
      saveDemoWallet(wallet);
    }

    addDemoNotification({
      id: `notif_${Date.now()}`,
      userId: wth.userId,
      title: `Withdrawal ${newStatus}: ₹${wth.amount}`,
      message:
        newStatus === 'Paid'
          ? `Your withdrawal of ₹${wth.amount} via ${wth.method} has been successfully sent! Bank UTR: ${transactionReference || 'PROCESSED'}.`
          : `Your withdrawal request of ₹${wth.amount} was rejected. Your balance has been restored.`,
      type: 'withdrawal',
      isRead: false,
      createdAt: now,
    });

    return;
  }

  const wthRef = doc(db, 'withdrawals', withdrawalId);
  const wthSnap = await getDoc(wthRef);
  if (!wthSnap.exists()) {
    throw new Error('Withdrawal request not found.');
  }

  const wth = wthSnap.data() as WithdrawalRequest;

  await updateDoc(wthRef, {
    status: newStatus,
    transactionReference: transactionReference || wth.transactionReference || '',
    adminNotes: adminNotes || wth.adminNotes || '',
    processedAt: now,
  });

  const walletRef = doc(db, 'wallets', wth.userId);
  const walletSnap = await getDoc(walletRef);

  if (walletSnap.exists()) {
    const wallet = walletSnap.data() as Wallet;
    if (newStatus === 'Rejected') {
      const restoredBalance = Math.round((wallet.availableBalance + wth.amount) * 100) / 100;
      await updateDoc(walletRef, {
        availableBalance: restoredBalance,
        updatedAt: now,
      });
    } else if (newStatus === 'Paid') {
      const updatedTotalWithdrawn = Math.round((wallet.totalWithdrawn + wth.amount) * 100) / 100;
      await updateDoc(walletRef, {
        totalWithdrawn: updatedTotalWithdrawn,
        updatedAt: now,
      });
    }
  }

  let notifTitle = `Withdrawal ${newStatus}: ₹${wth.amount}`;
  let notifBody =
    newStatus === 'Paid'
      ? `Your withdrawal of ₹${wth.amount} via ${wth.method} has been successfully sent! Bank UTR: ${transactionReference || 'PROCESSED'}.`
      : `Your withdrawal request of ₹${wth.amount} status is ${newStatus}.`;

  await addNotification(wth.userId, notifTitle, notifBody, 'withdrawal');
}

// Add or edit product (Admin)
export async function saveProduct(product: Product, adminEmail: string): Promise<void> {
  const path = `products/${product.id}`;
  try {
    if (auth.currentUser) {
      await setDoc(doc(db, 'products', product.id), product, { merge: true });
    }
    await logAuditEvent(
      'admin',
      adminEmail,
      'SAVE_PRODUCT',
      path,
      `Saved product: ${product.title} (Deal Price: ₹${product.dealPrice}, Cashback: ${product.cashbackLabel})`
    );
  } catch (error) {}
}

// Add or edit affiliate network (Admin)
export async function saveAffiliateNetwork(network: AffiliateNetwork, adminEmail: string): Promise<void> {
  const path = `affiliate_networks/${network.id}`;
  try {
    if (auth.currentUser) {
      await setDoc(doc(db, 'affiliate_networks', network.id), network, { merge: true });
    }
    await logAuditEvent('admin', adminEmail, 'SAVE_NETWORK', path, `Updated affiliate network: ${network.name}`);
  } catch (error) {}
}
