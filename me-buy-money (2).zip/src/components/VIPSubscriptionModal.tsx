import React, { useState } from 'react';
import {
  X,
  Crown,
  Sparkles,
  CheckCircle2,
  Lock,
  Zap,
  Tag,
  ShieldCheck,
  ArrowRight,
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';

export const VIPSubscriptionModal: React.FC = () => {
  const {
    isVIPModalOpen,
    closeVIPModal,
    isSubscribed,
    subscribeVIP,
    toggleVIPSubscription,
    wallet,
  } = useAuth();

  const [selectedPlan, setSelectedPlan] = useState<'monthly' | 'yearly'>('monthly');
  const [activating, setActivating] = useState(false);
  const [successMsg, setSuccessMsg] = useState(false);

  if (!isVIPModalOpen) return null;

  const handleSubscribe = async () => {
    setActivating(true);
    try {
      await subscribeVIP(selectedPlan);
      setSuccessMsg(true);
      setTimeout(() => {
        setSuccessMsg(false);
        closeVIPModal();
      }, 1500);
    } finally {
      setActivating(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/75 backdrop-blur-xs animate-in fade-in">
      <div className="bg-white w-full max-w-md rounded-3xl shadow-2xl border border-amber-200/60 overflow-hidden relative animate-in zoom-in-95 max-h-[92vh] overflow-y-auto">
        {/* Close Button */}
        <button
          onClick={closeVIPModal}
          className="absolute top-4 right-4 z-20 w-8 h-8 rounded-full bg-black/20 hover:bg-black/30 text-white flex items-center justify-center transition-colors"
        >
          <X className="w-4 h-4" />
        </button>

        {/* Modal Top Banner */}
        <div className="bg-gradient-to-br from-amber-600 via-amber-500 to-yellow-600 text-white p-6 sm:p-7 text-center relative overflow-hidden">
          <div className="w-14 h-14 rounded-2xl bg-white/20 backdrop-blur-md border border-white/30 text-white flex items-center justify-center mx-auto shadow-xl shadow-amber-900/30 mb-2">
            <Crown className="w-8 h-8 text-yellow-100 fill-yellow-200" />
          </div>

          <div className="inline-flex items-center gap-1.5 px-3 py-0.5 rounded-full bg-black/25 text-amber-200 text-[10px] font-black uppercase tracking-wider mb-1">
            <Sparkles className="w-3.5 h-3.5 text-yellow-300" />
            <span>VIP Club Membership</span>
          </div>

          <h2 className="text-xl sm:text-2xl font-black tracking-tight text-white">
            Unlock All Premium Deals
          </h2>
          <p className="text-xs text-amber-100/95 max-w-xs mx-auto leading-relaxed mt-1">
            Get instant unblurred access to secret deals, verified affiliate links, and guaranteed cashback!
          </p>

          {/* Decorative glows */}
          <div className="absolute -top-12 -right-12 w-32 h-32 bg-white/10 rounded-full blur-xl pointer-events-none" />
          <div className="absolute -bottom-10 -left-10 w-32 h-32 bg-yellow-300/20 rounded-full blur-xl pointer-events-none" />
        </div>

        {/* Content Body */}
        <div className="p-5 sm:p-6 space-y-4">
          {successMsg ? (
            <div className="bg-emerald-50 border border-emerald-200 text-emerald-900 p-4 rounded-2xl text-center space-y-2">
              <CheckCircle2 className="w-8 h-8 text-emerald-600 mx-auto" />
              <h3 className="text-sm font-black">🎉 VIP Membership Activated!</h3>
              <p className="text-xs text-emerald-700">
                All premium deals are now unblurred and ready for shopping with full cashback!
              </p>
            </div>
          ) : (
            <>
              {/* VIP Benefits List */}
              <div className="bg-amber-50/60 border border-amber-200/80 rounded-2xl p-3.5 space-y-2 text-xs">
                <span className="text-[10px] font-bold text-amber-900 uppercase tracking-wider block">
                  VIP Member Exclusives:
                </span>
                <div className="space-y-1.5 text-slate-700">
                  <div className="flex items-center gap-2">
                    <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                    <span><strong>Unblur All Deals</strong> — Direct links on Apple, Dyson & Sony</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                    <span><strong>Live Expiry Timers</strong> — Lock in prices before timers expire</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                    <span><strong>Highest Commission Tier</strong> — Maximum cashback rate on all premium items</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                    <span><strong>Fast-Track Payouts</strong> — Priority UPI transfer in 24 hours</span>
                  </div>
                </div>
              </div>

              {/* Plan Selector */}
              <div className="space-y-2">
                <span className="text-xs font-bold text-slate-700 block">Choose Your VIP Plan:</span>
                <div className="grid grid-cols-2 gap-2">
                  <div
                    onClick={() => setSelectedPlan('monthly')}
                    className={`p-3 rounded-2xl border cursor-pointer transition-all relative ${
                      selectedPlan === 'monthly'
                        ? 'border-amber-500 bg-amber-50/80 ring-2 ring-amber-500/30'
                        : 'border-slate-200 bg-white hover:bg-slate-50'
                    }`}
                  >
                    <span className="text-[10px] font-bold text-slate-500 block">Monthly Pass</span>
                    <div className="flex items-baseline gap-1 mt-0.5">
                      <span className="text-lg font-black text-slate-900">₹49</span>
                      <span className="text-[10px] text-slate-400">/mo</span>
                    </div>
                    <span className="text-[9px] text-emerald-700 font-bold block mt-1">
                      Cancel anytime
                    </span>
                  </div>

                  <div
                    onClick={() => setSelectedPlan('yearly')}
                    className={`p-3 rounded-2xl border cursor-pointer transition-all relative overflow-hidden ${
                      selectedPlan === 'yearly'
                        ? 'border-amber-500 bg-amber-50/80 ring-2 ring-amber-500/30'
                        : 'border-slate-200 bg-white hover:bg-slate-50'
                    }`}
                  >
                    <div className="absolute top-0 right-0 bg-gradient-to-l from-amber-600 to-orange-500 text-white text-[8px] font-black uppercase px-2 py-0.5 rounded-bl-lg">
                      Save 50%
                    </div>
                    <span className="text-[10px] font-bold text-slate-500 block">Annual Pass</span>
                    <div className="flex items-baseline gap-1 mt-0.5">
                      <span className="text-lg font-black text-slate-900">₹299</span>
                      <span className="text-[10px] text-slate-400">/yr</span>
                    </div>
                    <span className="text-[9px] text-amber-700 font-bold block mt-1">
                      Just ₹25/month
                    </span>
                  </div>
                </div>
              </div>

              {/* Current Wallet Balance info */}
              <div className="flex items-center justify-between px-3 py-2 rounded-xl bg-slate-50 border border-slate-200 text-xs">
                <span className="text-slate-500">Your Cashback Balance:</span>
                <span className="font-bold text-slate-800 font-mono">
                  ₹{(wallet?.availableBalance ?? 0).toLocaleString('en-IN', { minimumFractionDigits: 2 })}
                </span>
              </div>

              {/* Action Buttons */}
              <div className="space-y-2 pt-1">
                <button
                  type="button"
                  onClick={handleSubscribe}
                  disabled={activating}
                  className="w-full py-3.5 px-4 rounded-2xl bg-gradient-to-r from-amber-500 via-amber-600 to-yellow-600 hover:from-amber-600 hover:to-yellow-700 text-white font-black text-xs shadow-lg shadow-amber-600/25 flex items-center justify-center gap-2 transition-all hover:scale-[1.01] active:scale-95 disabled:opacity-50"
                >
                  <Crown className="w-4 h-4 fill-white" />
                  <span>
                    {activating
                      ? 'Activating VIP Pass...'
                      : `Activate VIP Pass (${selectedPlan === 'yearly' ? '₹299/yr' : '₹49/mo'})`}
                  </span>
                  <ArrowRight className="w-4 h-4" />
                </button>

                {/* Instant toggle for testing */}
                <div className="text-center pt-1">
                  <button
                    type="button"
                    onClick={async () => {
                      await toggleVIPSubscription();
                      closeVIPModal();
                    }}
                    className="text-[11px] font-bold text-slate-500 hover:text-slate-800 underline transition-colors"
                  >
                    {isSubscribed ? 'Temporarily deactivate VIP (Test blurred view)' : '⚡ Quick Demo 1-Click Free VIP Unlock'}
                  </button>
                </div>
              </div>

              <div className="flex items-center justify-center gap-1.5 text-[10px] text-slate-400 pt-1">
                <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
                <span>100% Secure Checkout • Auto-unlock instantly</span>
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  );
};
