import React from 'react';
import {
  Wallet,
  Bell,
  Inbox,
  ShoppingBag,
  Shield,
  LogIn,
  Link2,
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { ScreenTab } from '../types';

interface NavbarProps {
  currentTab: ScreenTab;
  onSelectTab: (tab: ScreenTab) => void;
  unreadNotificationsCount?: number;
  unreadInboxCount?: number;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentTab,
  onSelectTab,
  unreadNotificationsCount = 0,
  unreadInboxCount = 0,
}) => {
  const { profile, wallet, isAdmin, openAuthModal } = useAuth();

  return (
    <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-slate-200/80 shadow-xs">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <div
            onClick={() => onSelectTab('home')}
            className="flex items-center gap-2.5 cursor-pointer group"
          >
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-emerald-600 via-teal-600 to-emerald-500 flex items-center justify-center text-white shadow-md shadow-emerald-500/25 group-hover:scale-105 transition-transform">
              <Link2 className="w-5 h-5 stroke-[2.5]" />
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="font-extrabold text-lg text-slate-900 tracking-tight">
                  Me BUY <span className="text-emerald-600">MONEY</span>
                </span>
                <span className="bg-emerald-100 text-emerald-800 text-[9px] font-bold px-1.5 py-0.5 rounded-full uppercase tracking-wider">
                  Cashback
                </span>
              </div>
              <p className="text-[10px] text-slate-500 font-medium hidden sm:block -mt-0.5">
                Paste Any Product Link • Earn Real Cashback
              </p>
            </div>
          </div>

          {/* Center Navigation Shortcuts (desktop & tablet) */}
          <div className="hidden md:flex items-center gap-1">
            <button
              onClick={() => onSelectTab('home')}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-colors ${
                currentTab === 'home'
                  ? 'bg-slate-100 text-emerald-700'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-50'
              }`}
            >
              Home
            </button>
            <button
              onClick={() => onSelectTab('reward-link')}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-colors flex items-center gap-1.5 ${
                currentTab === 'reward-link'
                  ? 'bg-emerald-50 text-emerald-700 ring-1 ring-emerald-200'
                  : 'text-emerald-700 hover:bg-emerald-50'
              }`}
            >
              <Link2 className="w-3.5 h-3.5" />
              <span>Reward Link</span>
            </button>
            <button
              onClick={() => onSelectTab('inbox')}
              className={`relative px-3 py-1.5 rounded-xl text-xs font-bold transition-colors flex items-center gap-1.5 ${
                currentTab === 'inbox'
                  ? 'bg-slate-100 text-slate-900'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-50'
              }`}
            >
              <Inbox className="w-3.5 h-3.5" />
              <span>Inbox</span>
              {unreadInboxCount > 0 && (
                <span className="w-2 h-2 bg-emerald-600 rounded-full" />
              )}
            </button>
            <button
              onClick={() => onSelectTab('history')}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-colors flex items-center gap-1.5 ${
                currentTab === 'history'
                  ? 'bg-slate-100 text-slate-900'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-50'
              }`}
            >
              <ShoppingBag className="w-3.5 h-3.5" />
              <span>History</span>
            </button>
          </div>

          {/* Right Action Icons */}
          <div className="flex items-center gap-2 sm:gap-3">
            {/* Launch Standalone HTML Mobile App */}
            <a
              href="/user.html"
              className="flex items-center gap-1 px-2.5 py-1.5 rounded-xl bg-slate-100 hover:bg-slate-200 border border-slate-200/80 text-[11px] font-bold text-slate-700 transition-colors shadow-2xs"
              title="Launch Pure Standalone HTML Mobile App"
            >
              <span className="text-xs">📱</span>
              <span className="hidden sm:inline">HTML App</span>
            </a>

            {/* Inbox Icon (Mobile & Desktop) */}
            <button
              onClick={() => onSelectTab('inbox')}
              className={`relative p-2 rounded-xl transition-colors ${
                currentTab === 'inbox'
                  ? 'bg-slate-100 text-emerald-700'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
              }`}
              title="My Inbox (Delivered Reward Links)"
            >
              <Inbox className="w-5 h-5" />
              {unreadInboxCount > 0 && (
                <span className="absolute top-1.5 right-1.5 flex h-2 w-2">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75" />
                  <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-600" />
                </span>
              )}
            </button>

            {/* Wallet Chip */}
            <button
              onClick={() => onSelectTab('wallet')}
              className={`flex items-center gap-2 px-3 py-1.5 rounded-xl border text-xs font-semibold transition-all ${
                currentTab === 'wallet'
                  ? 'bg-emerald-600 text-white border-emerald-600 shadow-sm'
                  : 'bg-emerald-50 text-emerald-900 border-emerald-200/80 hover:bg-emerald-100'
              }`}
              title="My Wallet"
            >
              <Wallet className="w-4 h-4 text-emerald-600 group-hover:scale-110" />
              <div className="text-left">
                <span className="block text-[9px] uppercase font-bold text-emerald-700 tracking-wider">
                  Available
                </span>
                <span className="font-bold text-xs">
                  ₹{(wallet?.availableBalance ?? 0).toLocaleString('en-IN')}
                </span>
              </div>
            </button>

            {/* Notifications */}
            <button
              onClick={() => onSelectTab('notifications')}
              className={`relative p-2 rounded-xl transition-colors ${
                currentTab === 'notifications'
                  ? 'bg-slate-100 text-emerald-700'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
              }`}
              title="Notifications"
            >
              <Bell className="w-5 h-5" />
              {unreadNotificationsCount > 0 && (
                <span className="absolute top-1.5 right-1.5 w-2 h-2 bg-rose-500 rounded-full animate-pulse ring-2 ring-white" />
              )}
            </button>

            {/* User Profile or Sign Up / Login */}
            {profile ? (
              <button
                onClick={() => onSelectTab('profile')}
                className={`flex items-center gap-2 p-1.5 sm:px-3 sm:py-1.5 rounded-xl border transition-all ${
                  currentTab === 'profile'
                    ? 'bg-slate-900 text-white border-slate-900'
                    : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-50'
                }`}
              >
                <div className="w-6 h-6 rounded-full bg-emerald-600 text-white flex items-center justify-center text-xs font-bold uppercase">
                  {profile.displayName?.charAt(0) || 'U'}
                </div>
                <span className="hidden lg:inline text-xs font-medium max-w-[100px] truncate">
                  {profile.displayName?.split(' ')[0]}
                </span>
              </button>
            ) : (
              <div className="flex items-center gap-1.5">
                <button
                  onClick={() => openAuthModal('signin')}
                  className="px-3 py-1.5 rounded-xl text-slate-700 hover:bg-slate-100 text-xs font-bold transition-colors"
                >
                  Log In
                </button>
                <button
                  onClick={() => openAuthModal('signup')}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 text-white text-xs font-black shadow-xs transition-all hover:scale-105"
                >
                  <LogIn className="w-3.5 h-3.5" />
                  <span>Sign Up</span>
                </button>
              </div>
            )}
          </div>
        </div>
      </div>
    </header>
  );
};
