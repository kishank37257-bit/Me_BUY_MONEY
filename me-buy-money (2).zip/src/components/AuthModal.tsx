import React, { useState } from 'react';
import {
  X,
  Mail,
  Lock,
  User as UserIcon,
  Eye,
  EyeOff,
  Sparkles,
  ArrowRight,
  Shield,
  Gift,
  CheckCircle2,
  AlertCircle,
  Zap,
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';

export const AuthModal: React.FC = () => {
  const {
    isAuthModalOpen,
    authModalMode,
    closeAuthModal,
    setAuthModalMode,
    signUpWithEmail,
    signInWithEmail,
    signInWithGoogle,
    loginAsDemoUser,
    loading,
  } = useAuth();

  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  if (!isAuthModalOpen) return null;

  const handleGoogleClick = async () => {
    setErrorMsg(null);
    try {
      await signInWithGoogle();
      closeAuthModal();
    } catch (err: any) {
      setErrorMsg(err.message || 'Google Sign-in me error aayi. Kripya dobara try karein.');
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);

    if (authModalMode === 'signup') {
      if (!name.trim()) {
        setErrorMsg('Kripya apna Full Name enter karein.');
        return;
      }
      if (!email.trim() || !email.includes('@')) {
        setErrorMsg('Kripya valid Gmail ya Email address enter karein.');
        return;
      }
      if (password.length < 6) {
        setErrorMsg('Password kam se kam 6 characters ka hona chahiye.');
        return;
      }
      try {
        await signUpWithEmail(name, email, password);
        closeAuthModal();
      } catch (err: any) {
        setErrorMsg(err.message || 'Signup failed. Please try again.');
      }
    } else {
      if (!email.trim()) {
        setErrorMsg('Kripya apna Gmail address enter karein.');
        return;
      }
      if (!password) {
        setErrorMsg('Kripya apna password enter karein.');
        return;
      }
      try {
        await signInWithEmail(email, password);
        closeAuthModal();
      } catch (err: any) {
        setErrorMsg(err.message || 'Invalid email or password.');
      }
    }
  };

  const handleDemoLogin = async () => {
    try {
      await loginAsDemoUser(false);
      closeAuthModal();
    } catch (e: any) {
      setErrorMsg(e.message || 'Demo login failed');
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4 bg-slate-950/75 backdrop-blur-xs animate-in fade-in">
      <div className="bg-white w-full max-w-md rounded-t-3xl sm:rounded-3xl shadow-2xl border border-slate-100 overflow-hidden relative max-h-[92vh] overflow-y-auto animate-in slide-in-from-bottom-6 sm:zoom-in-95">
        
        {/* Mobile Pull Indicator */}
        <div className="w-12 h-1.5 bg-slate-300 rounded-full mx-auto mt-2.5 sm:hidden" />

        {/* Close Button */}
        <button
          onClick={closeAuthModal}
          className="absolute top-3.5 right-3.5 z-10 w-8 h-8 rounded-full bg-slate-100 hover:bg-slate-200 text-slate-500 hover:text-slate-800 flex items-center justify-center transition-colors"
        >
          <X className="w-4 h-4" />
        </button>

        {/* Modal Top Header with Brand */}
        <div className="bg-gradient-to-br from-emerald-900 via-teal-900 to-slate-900 text-white p-5 pt-6 text-center space-y-2 relative overflow-hidden">
          <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-emerald-500 to-teal-400 text-white flex items-center justify-center mx-auto shadow-lg shadow-emerald-500/25 font-black text-2xl">
            ₹
          </div>

          <h2 className="text-xl font-black tracking-tight">
            Me BUY <span className="text-emerald-400">MONEY</span>
          </h2>

          <p className="text-xs text-slate-300 max-w-xs mx-auto leading-relaxed">
            {authModalMode === 'signup'
              ? 'Naya shopper account banayein aur seedha apne bank & UPI me cashback payein!'
              : 'Apne account me login karein aur verified cashback wallet track karein.'}
          </p>

          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-500/20 border border-emerald-400/30 text-emerald-300 text-[11px] font-black uppercase tracking-wider">
            <Gift className="w-3.5 h-3.5" />
            <span>₹50 Welcome Bonus Free</span>
          </div>
        </div>

        {/* DIRECT GOOGLE LOGIN BUTTON (Top & Prominent) */}
        <div className="p-4 sm:p-5 pb-0 space-y-3">
          <button
            type="button"
            onClick={handleGoogleClick}
            disabled={loading}
            className="w-full py-3.5 px-4 rounded-2xl border-2 border-slate-200 hover:border-emerald-500 hover:bg-slate-50 font-black text-xs text-slate-800 flex items-center justify-center gap-3 transition-transform active:scale-95 shadow-xs"
          >
            <svg className="w-5 h-5 shrink-0" viewBox="0 0 24 24">
              <path
                fill="#4285F4"
                d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
              />
              <path
                fill="#34A853"
                d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
              />
              <path
                fill="#FBBC05"
                d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"
              />
              <path
                fill="#EA4335"
                d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"
              />
            </svg>
            <span>Direct Google se Login Karein</span>
          </button>

          {/* Divider */}
          <div className="relative py-1 text-center">
            <div className="absolute inset-0 flex items-center">
              <div className="w-full border-t border-slate-200" />
            </div>
            <span className="relative bg-white px-3 text-[10px] uppercase font-extrabold text-slate-400">
              Ya Gmail & Password se
            </span>
          </div>
        </div>

        {/* Mode Switcher Tabs */}
        <div className="grid grid-cols-2 p-1 bg-slate-100 mx-4 sm:mx-5 mt-2 rounded-2xl text-xs font-bold">
          <button
            type="button"
            onClick={() => {
              setAuthModalMode('signin');
              setErrorMsg(null);
            }}
            className={`py-2 rounded-xl transition-all ${
              authModalMode === 'signin'
                ? 'bg-white text-emerald-800 shadow-xs'
                : 'text-slate-500 hover:text-slate-800'
            }`}
          >
            Sign In (Login)
          </button>
          <button
            type="button"
            onClick={() => {
              setAuthModalMode('signup');
              setErrorMsg(null);
            }}
            className={`py-2 rounded-xl transition-all ${
              authModalMode === 'signup'
                ? 'bg-white text-emerald-800 shadow-xs'
                : 'text-slate-500 hover:text-slate-800'
            }`}
          >
            Create Account (+₹50)
          </button>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="p-4 sm:p-5 space-y-3 text-xs">
          {errorMsg && (
            <div className="bg-rose-50 border border-rose-200 text-rose-800 p-3 rounded-2xl flex items-center gap-2 text-xs">
              <AlertCircle className="w-4 h-4 shrink-0 text-rose-600" />
              <span>{errorMsg}</span>
            </div>
          )}

          {/* Name Field (Sign Up Only) */}
          {authModalMode === 'signup' && (
            <div className="space-y-1">
              <label className="font-bold text-slate-700">Full Name *</label>
              <div className="relative">
                <UserIcon className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  required
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="e.g. Rahul Sharma"
                  className="w-full pl-10 pr-3 py-3 bg-slate-50 border border-slate-200 rounded-2xl text-xs text-slate-900 placeholder-slate-400 outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500"
                />
              </div>
            </div>
          )}

          {/* Gmail / Email Field */}
          <div className="space-y-1">
            <label className="font-bold text-slate-700">Gmail / Email Address *</label>
            <div className="relative">
              <Mail className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
              <input
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="shopper@gmail.com"
                className="w-full pl-10 pr-3 py-3 bg-slate-50 border border-slate-200 rounded-2xl text-xs text-slate-900 placeholder-slate-400 outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500"
              />
            </div>
          </div>

          {/* Password Field (Password / Passport) */}
          <div className="space-y-1">
            <div className="flex items-center justify-between">
              <label className="font-bold text-slate-700">Password *</label>
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="text-[10px] text-emerald-700 font-bold hover:underline"
              >
                {showPassword ? 'Hide' : 'Show'}
              </button>
            </div>
            <div className="relative">
              <Lock className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
              <input
                type={showPassword ? 'text' : 'password'}
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="•••••••• (Min. 6 characters)"
                className="w-full pl-10 pr-10 py-3 bg-slate-50 border border-slate-200 rounded-2xl text-xs text-slate-900 placeholder-slate-400 outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 font-mono"
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute right-3.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600"
              >
                {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            </div>
          </div>



          {/* Submit Button */}
          <button
            type="submit"
            disabled={loading}
            className="w-full py-3.5 px-4 rounded-2xl bg-gradient-to-r from-emerald-600 via-teal-600 to-emerald-500 hover:from-emerald-700 hover:to-teal-700 text-white font-extrabold text-xs shadow-md shadow-emerald-600/25 flex items-center justify-center gap-2 transition-all hover:scale-[1.01] active:scale-95 disabled:opacity-50"
          >
            <span>
              {loading
                ? 'Processing...'
                : authModalMode === 'signup'
                ? 'Create Account & Claim ₹50 Bonus'
                : 'Sign In to Me BUY MONEY'}
            </span>
            <ArrowRight className="w-4 h-4" />
          </button>

          {/* Quick Demo Test Access */}
          <div className="pt-1 text-center">
            <button
              type="button"
              onClick={handleDemoLogin}
              className="text-[11px] text-slate-500 hover:text-slate-800 underline font-medium"
            >
              Demo Shopper se Instant Login Karein (Bina Password ke)
            </button>
          </div>

          {/* Security & Privacy Reassurance */}
          <div className="pt-1 text-center space-y-1">
            <p className="text-[11px] text-slate-500 flex items-center justify-center gap-1">
              <Shield className="w-3.5 h-3.5 text-emerald-600" />
              <span>256-Bit SSL Encrypted • Direct Bank & UPI Payouts</span>
            </p>
          </div>
        </form>
      </div>
    </div>
  );
};
