import React from 'react';
import { ShieldCheck, Info } from 'lucide-react';

export const AffiliateDisclosure: React.FC<{ compact?: boolean }> = ({ compact }) => {
  if (compact) {
    return (
      <div className="bg-slate-100 border border-slate-200 rounded-lg p-2.5 text-xs text-slate-600 flex items-center gap-2">
        <Info className="w-4 h-4 text-emerald-600 shrink-0" />
        <span>
          <strong>Affiliate Disclosure:</strong> When you purchase through links on Me BUY MONEY, we earn an affiliate commission and share 40% with you as cashback.
        </span>
      </div>
    );
  }

  return (
    <div className="bg-emerald-50/70 border border-emerald-200/80 rounded-xl p-4 text-xs text-slate-700 space-y-2">
      <div className="flex items-center gap-2 font-semibold text-emerald-900 text-sm">
        <ShieldCheck className="w-5 h-5 text-emerald-600" />
        <span>Official Affiliate & Cashback Transparency Policy</span>
      </div>
      <p className="leading-relaxed">
        <strong>Me BUY MONEY</strong> is an independent cashback and shopping rewards platform. We partner with officially authorized affiliate networks (including Amazon Associates, Flipkart Affiliate, Cuelinks, and Impact Radius). When you click a tracked deal and complete an eligible order, the retailer pays an affiliate commission. We share <strong>40% of confirmed commissions</strong> directly with your wallet, while retaining 60% for operating costs and payment gateway handling.
      </p>
      <p className="text-[11px] text-slate-500">
        *Cashback rates and tracking periods are subject to merchant terms. Returns, cancellations, or fraudulent orders will not qualify. Me BUY MONEY is not affiliated with CashKaro or any brand shown.
      </p>
    </div>
  );
};
