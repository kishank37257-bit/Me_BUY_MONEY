import React, { useEffect, useState } from 'react';
import { ExternalLink, CheckCircle2, ShieldCheck, Clock, AlertTriangle, X } from 'lucide-react';
import { Product } from '../types';

interface RedirectModalProps {
  product: Product | null;
  trackingSubId: string;
  trackedUrl: string;
  onClose: () => void;
}

export const RedirectModal: React.FC<RedirectModalProps> = ({
  product,
  trackingSubId,
  trackedUrl,
  onClose,
}) => {
  const [step, setStep] = useState<number>(1);

  useEffect(() => {
    if (!product) return;
    setStep(1);
    const t1 = setTimeout(() => setStep(2), 500);
    const t2 = setTimeout(() => setStep(3), 1100);
    return () => {
      clearTimeout(t1);
      clearTimeout(t2);
    };
  }, [product]);

  if (!product) return null;

  const handleOpenStore = () => {
    window.open(trackedUrl, '_blank', 'noopener,noreferrer');
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="bg-white w-full max-w-md rounded-2xl shadow-2xl border border-slate-100 overflow-hidden">
        {/* Header */}
        <div className="bg-gradient-to-r from-emerald-600 to-teal-700 p-5 text-white relative">
          <button
            onClick={onClose}
            className="absolute top-4 right-4 p-1.5 rounded-full bg-white/20 hover:bg-white/30 text-white transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-xl bg-white p-1.5 shadow-md flex items-center justify-center overflow-hidden">
              <img
                src={product.storeLogo}
                alt={product.storeName}
                className="w-full h-full object-contain"
              />
            </div>
            <div>
              <span className="text-xs font-semibold uppercase tracking-wider text-emerald-200">
                Me BUY MONEY Tracking
              </span>
              <h3 className="text-lg font-bold leading-tight">Activating Cashback</h3>
            </div>
          </div>
        </div>

        {/* Content */}
        <div className="p-5 space-y-4">
          {/* Tracking Step Animation */}
          <div className="bg-slate-50 border border-slate-200 rounded-xl p-3.5 space-y-2">
            <div className="flex items-center gap-2 text-xs font-medium">
              <CheckCircle2 className={`w-4 h-4 ${step >= 1 ? 'text-emerald-600' : 'text-slate-300'}`} />
              <span className={step >= 1 ? 'text-slate-800' : 'text-slate-400'}>
                Generated Tracking Token: <code className="bg-emerald-100 text-emerald-800 px-1 py-0.5 rounded font-mono text-[11px] font-semibold">{trackingSubId}</code>
              </span>
            </div>
            <div className="flex items-center gap-2 text-xs font-medium">
              <CheckCircle2 className={`w-4 h-4 ${step >= 2 ? 'text-emerald-600' : 'text-slate-300'}`} />
              <span className={step >= 2 ? 'text-slate-800' : 'text-slate-400'}>
                Attaching official affiliate parameters for {product.storeName}
              </span>
            </div>
            <div className="flex items-center gap-2 text-xs font-medium">
              <CheckCircle2 className={`w-4 h-4 ${step >= 3 ? 'text-emerald-600' : 'text-slate-300'}`} />
              <span className={step >= 3 ? 'text-emerald-700 font-semibold' : 'text-slate-400'}>
                Cashback rate locked: {product.cashbackLabel}
              </span>
            </div>
          </div>

          {/* Product brief */}
          <div className="flex items-center gap-3 p-3 border border-slate-100 rounded-xl bg-white shadow-sm">
            <img
              src={product.imageUrl}
              alt={product.title}
              className="w-14 h-14 object-cover rounded-lg"
            />
            <div className="flex-1 min-w-0">
              <h4 className="text-xs font-semibold text-slate-800 line-clamp-1">
                {product.title}
              </h4>
              <div className="flex items-baseline gap-2 mt-0.5">
                <span className="text-sm font-bold text-slate-900">
                  ₹{product.dealPrice.toLocaleString('en-IN')}
                </span>
                {product.originalPrice > product.dealPrice && (
                  <span className="text-xs text-slate-400 line-through">
                    ₹{product.originalPrice.toLocaleString('en-IN')}
                  </span>
                )}
              </div>
              <span className="inline-block mt-0.5 text-[10px] font-bold text-emerald-600 bg-emerald-50 px-1.5 py-0.5 rounded">
                {product.cashbackLabel}
              </span>
            </div>
          </div>

          {/* Guidelines */}
          <div className="space-y-1.5 text-xs text-slate-600 bg-amber-50/70 border border-amber-200/80 p-3 rounded-xl">
            <div className="flex items-center gap-1.5 font-semibold text-amber-900">
              <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0" />
              <span>To guarantee your cashback credit:</span>
            </div>
            <ul className="list-disc pl-5 space-y-1 text-[11px] text-amber-800">
              <li>Do not open other coupon or comparison tabs before buying.</li>
              <li>Add items to your cart <em>after</em> clicking from Me BUY MONEY.</li>
              <li>Cashback will appear as <strong>Order Pending</strong> in your dashboard within 48 hours.</li>
            </ul>
          </div>

          {/* Destination URL Display */}
          <div className="text-[11px] text-slate-400 truncate">
            Destination: <span className="font-mono">{trackedUrl}</span>
          </div>

          {/* Buttons */}
          <div className="pt-1 flex gap-2">
            <button
              onClick={onClose}
              className="flex-1 py-2.5 px-4 rounded-xl border border-slate-200 text-slate-700 text-xs font-semibold hover:bg-slate-50 transition-colors"
            >
              Cancel
            </button>
            <button
              onClick={handleOpenStore}
              className="flex-2 py-2.5 px-4 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 text-white text-xs font-bold shadow-md shadow-emerald-500/20 flex items-center justify-center gap-1.5 transition-all"
            >
              <span>Continue to {product.storeName}</span>
              <ExternalLink className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
