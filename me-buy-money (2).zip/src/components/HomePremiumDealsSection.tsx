import React, { useState, useEffect } from 'react';
import {
  Crown,
  Clock,
  Sparkles,
  Lock,
  Unlock,
  ExternalLink,
  ChevronRight,
  Flame,
  Zap,
} from 'lucide-react';
import { PremiumDeal } from '../types';
import { useAuth } from '../context/AuthContext';
import { buildStoreAffiliateUrl } from '../services/dbService';

interface HomePremiumDealsSectionProps {
  deals: PremiumDeal[];
  onSelectDeal?: (deal: PremiumDeal) => void;
}

// Live Countdown Timer component
const DealCountdownTimer: React.FC<{ expiryDate: string }> = ({ expiryDate }) => {
  const [timeLeft, setTimeLeft] = useState<{
    days: number;
    hours: number;
    minutes: number;
    seconds: number;
    isExpired: boolean;
  }>({ days: 0, hours: 0, minutes: 0, seconds: 0, isExpired: false });

  useEffect(() => {
    const calculateTime = () => {
      const diff = new Date(expiryDate).getTime() - Date.now();
      if (diff <= 0) {
        setTimeLeft({ days: 0, hours: 0, minutes: 0, seconds: 0, isExpired: true });
        return;
      }
      const days = Math.floor(diff / (1000 * 60 * 60 * 24));
      const hours = Math.floor((diff % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
      const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
      const seconds = Math.floor((diff % (1000 * 60)) / 1000);
      setTimeLeft({ days, hours, minutes, seconds, isExpired: false });
    };

    calculateTime();
    const interval = setInterval(calculateTime, 1000);
    return () => clearInterval(interval);
  }, [expiryDate]);

  if (timeLeft.isExpired) {
    return (
      <span className="inline-flex items-center gap-1 text-[10px] font-bold text-rose-600 bg-rose-50 px-2 py-0.5 rounded-md border border-rose-200">
        <Clock className="w-3 h-3" />
        <span>Offer Expired</span>
      </span>
    );
  }

  return (
    <div className="inline-flex items-center gap-1 px-2.5 py-1 rounded-xl bg-amber-500/10 border border-amber-500/30 text-amber-900 font-mono text-[11px] font-extrabold shadow-2xs">
      <Clock className="w-3.5 h-3.5 text-amber-600 animate-pulse" />
      <span>
        {timeLeft.days > 0 ? `${timeLeft.days}d : ` : ''}
        {String(timeLeft.hours).padStart(2, '0')}h : {String(timeLeft.minutes).padStart(2, '0')}m :{' '}
        {String(timeLeft.seconds).padStart(2, '0')}s
      </span>
    </div>
  );
};

export const HomePremiumDealsSection: React.FC<HomePremiumDealsSectionProps> = ({
  deals,
  onSelectDeal,
}) => {
  const { isSubscribed, openVIPModal, toggleVIPSubscription, profile } = useAuth();
  const [selectedCategory, setSelectedCategory] = useState<string>('All');

  // Extract all categories dynamically from deals
  const categories = [
    'All',
    ...Array.from(new Set(deals.map((d) => d.category))).filter(Boolean),
  ];

  const filteredDeals = deals.filter((deal) => {
    if (selectedCategory === 'All') return true;
    return deal.category.toLowerCase() === selectedCategory.toLowerCase();
  });

  const handleOpenAffiliateLink = (url: string, storeName: string) => {
    // Inject user tracking sub ID with store safety
    const subId = profile?.id ? `MBM_${profile.id.slice(0, 6)}` : 'MBM_GUEST';
    const destination = buildStoreAffiliateUrl(url, storeName, subId);
    window.open(destination, '_blank', 'noopener,noreferrer');
  };

  return (
    <section className="space-y-3.5 pt-1">
      {/* SECTION HEADER & VIP STATUS BAR */}
      <div className="bg-gradient-to-r from-amber-500 via-amber-600 to-yellow-600 rounded-3xl p-4 sm:p-5 text-white shadow-xl shadow-amber-600/15 space-y-3">
        <div className="flex items-center justify-between gap-2">
          <div className="space-y-0.5">
            <div className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full bg-black/25 text-amber-200 text-[10px] font-black uppercase tracking-wider">
              <Crown className="w-3 h-3 fill-amber-300 text-amber-300" />
              <span>Premium VIP Deals</span>
            </div>
            <h2 className="text-lg font-black text-white tracking-tight flex items-center gap-1.5">
              <span>Exclusive Member Offers</span>
              <Sparkles className="w-4 h-4 text-yellow-300 fill-yellow-300" />
            </h2>
            <p className="text-[11px] text-amber-100">
              High-ticket products with guaranteed maximum cashback rates & active countdown timers.
            </p>
          </div>

          {/* Quick Subscription Status Pill */}
          <div className="shrink-0 text-right">
            {isSubscribed ? (
              <div className="inline-flex flex-col items-end gap-1">
                <span className="inline-flex items-center gap-1 px-3 py-1 rounded-full bg-emerald-500 text-white text-[10px] font-black uppercase tracking-wider shadow-sm">
                  <Unlock className="w-3 h-3" />
                  <span>VIP Unlocked</span>
                </span>
                <button
                  type="button"
                  onClick={toggleVIPSubscription}
                  className="text-[9px] text-amber-100 hover:text-white underline"
                  title="Switch subscription status to test blurred state"
                >
                  (Test Blur View)
                </button>
              </div>
            ) : (
              <div className="inline-flex flex-col items-end gap-1">
                <button
                  type="button"
                  onClick={openVIPModal}
                  className="px-3.5 py-1.5 rounded-2xl bg-white text-slate-900 font-extrabold text-xs shadow-md shadow-black/10 hover:bg-amber-50 transition-all active:scale-95 flex items-center gap-1.5"
                >
                  <Crown className="w-3.5 h-3.5 text-amber-600 fill-amber-500" />
                  <span>Unlock VIP (₹49)</span>
                </button>
                <button
                  type="button"
                  onClick={toggleVIPSubscription}
                  className="text-[9px] text-amber-200 hover:text-white underline"
                  title="Instant free 1-click test unlock"
                >
                  (1-Click Test Unlock)
                </button>
              </div>
            )}
          </div>
        </div>

        {/* Informative Sub-banner */}
        <div className="bg-black/20 rounded-2xl p-2.5 flex items-center justify-between text-[11px] border border-white/10">
          <div className="flex items-center gap-2">
            <Flame className="w-4 h-4 text-amber-300 fill-amber-400 shrink-0" />
            <span className="text-amber-100 font-medium">
              {isSubscribed
                ? '✅ All Premium Deals & Direct Links are 100% unlocked for your account!'
                : '🔒 Exclusive deals are blurred. Subscribe to VIP to unblur & shop.'}
            </span>
          </div>
          {!isSubscribed && (
            <button
              onClick={openVIPModal}
              className="font-bold text-amber-300 hover:text-white underline shrink-0 pl-2"
            >
              Learn More →
            </button>
          )}
        </div>
      </div>

      {/* CATEGORY FILTER TABS (Admin configured categories for all products) */}
      <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none">
        {categories.map((cat) => {
          const count =
            cat === 'All'
              ? deals.length
              : deals.filter((d) => d.category.toLowerCase() === cat.toLowerCase()).length;
          const isActive = selectedCategory === cat;
          return (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all shrink-0 flex items-center gap-1.5 ${
                isActive
                  ? 'bg-amber-500 text-white shadow-sm ring-2 ring-amber-500/30'
                  : 'bg-white text-slate-700 border border-slate-200 hover:bg-slate-50'
              }`}
            >
              <span>{cat}</span>
              <span
                className={`text-[10px] px-1.5 py-0.2 rounded-full ${
                  isActive ? 'bg-amber-700 text-amber-100' : 'bg-slate-100 text-slate-500'
                }`}
              >
                {count}
              </span>
            </button>
          );
        })}
      </div>

      {/* DEALS LIST */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
        {filteredDeals.map((deal) => {
          const discountPercent = Math.round(
            ((deal.originalPrice - deal.dealPrice) / deal.originalPrice) * 100
          );

          return (
            <div
              key={deal.id}
              className="bg-white rounded-3xl border border-slate-200/80 shadow-xs hover:shadow-md transition-all overflow-hidden flex flex-col relative group"
            >
              {/* Product Image Header with Store & Live Timer */}
              <div className="relative h-44 w-full bg-slate-100 overflow-hidden">
                <img
                  src={deal.imageUrl}
                  alt={deal.title}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                />

                {/* Store Badge */}
                <div className="absolute top-3 left-3 bg-white/95 backdrop-blur-md px-2.5 py-1 rounded-xl shadow-xs border border-slate-200/80 flex items-center gap-1.5">
                  <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
                  <span className="text-[11px] font-bold text-slate-900">{deal.storeName}</span>
                </div>

                {/* Discount Badge */}
                <div className="absolute top-3 right-3 bg-gradient-to-r from-rose-600 to-orange-600 text-white font-black text-[10px] px-2 py-0.5 rounded-lg shadow-sm">
                  {discountPercent}% OFF
                </div>

                {/* Live Countdown Timer Badge */}
                <div className="absolute bottom-2.5 left-3 right-3 flex items-center justify-between">
                  <DealCountdownTimer expiryDate={deal.expiryDate} />
                  <span className="text-[10px] font-extrabold uppercase bg-slate-900/80 backdrop-blur-md text-amber-300 px-2 py-0.5 rounded-lg border border-white/10">
                    {deal.category}
                  </span>
                </div>
              </div>

              {/* Card Details Body */}
              <div className="p-4 flex-1 flex flex-col justify-between space-y-3 relative">
                <div className="space-y-1">
                  <h3 className="font-extrabold text-xs text-slate-900 line-clamp-2 leading-snug">
                    {deal.title}
                  </h3>
                  <p className="text-[11px] text-slate-500 line-clamp-1">
                    {deal.description}
                  </p>
                </div>

                {/* Price & Cashback Highlight */}
                <div className="flex items-baseline justify-between pt-1 border-t border-slate-100">
                  <div className="flex items-baseline gap-2">
                    <span className="text-base font-black text-slate-950 font-mono">
                      ₹{deal.dealPrice.toLocaleString('en-IN')}
                    </span>
                    <span className="text-xs text-slate-400 line-through font-mono">
                      ₹{deal.originalPrice.toLocaleString('en-IN')}
                    </span>
                  </div>
                  <span className="inline-flex items-center gap-1 text-[11px] font-black text-emerald-700 bg-emerald-50 px-2.5 py-1 rounded-xl border border-emerald-200">
                    <Zap className="w-3 h-3 fill-emerald-600 text-emerald-600" />
                    <span>{deal.cashbackLabel}</span>
                  </span>
                </div>

                {/* CONDITIONAL VIP ACCESS: UNLOCKED VS BLURRED */}
                {isSubscribed ? (
                  /* UNBLURRED / UNLOCKED ACTION AREA */
                  <div className="pt-1 border-t border-slate-100">
                    <button
                      type="button"
                      onClick={() => handleOpenAffiliateLink(deal.affiliateUrl, deal.storeName)}
                      className="w-full py-2.5 px-4 rounded-2xl bg-gradient-to-r from-emerald-600 via-teal-600 to-emerald-600 hover:from-emerald-700 hover:to-teal-700 text-white font-extrabold text-xs shadow-md shadow-emerald-600/20 flex items-center justify-center gap-2 transition-all active:scale-95"
                    >
                      <span>Shop Deal & Claim Cashback</span>
                      <ExternalLink className="w-3.5 h-3.5" />
                    </button>
                  </div>
                ) : (
                  /* BLURRED / LOCKED OVERLAY FOR NON-SUBSCRIBED USERS */
                  <div className="relative pt-1 border-t border-slate-100 overflow-hidden rounded-2xl">
                    {/* The blurred dummy content beneath */}
                    <div className="filter blur-[5px] select-none pointer-events-none opacity-40 py-1">
                      <div className="w-full py-2.5 rounded-xl bg-slate-400 text-white font-bold text-xs text-center">
                        Shop Deal & Claim Cashback
                      </div>
                    </div>

                    {/* Glassmorphic Lock Overlay Box */}
                    <div className="absolute inset-0 bg-white/75 backdrop-blur-[2px] flex flex-col items-center justify-center p-3 text-center space-y-2 rounded-2xl border border-amber-300/80 shadow-xs">
                      <div className="flex items-center gap-1 text-[11px] font-black text-amber-950 uppercase tracking-wide">
                        <Lock className="w-3.5 h-3.5 text-amber-600" />
                        <span>VIP Subscription Required</span>
                      </div>
                      <p className="text-[10px] text-slate-600 max-w-[240px] leading-tight">
                        Deal links, countdown timer protection & extra cashback are locked for non-members.
                      </p>
                      <button
                        type="button"
                        onClick={openVIPModal}
                        className="py-1.5 px-3.5 rounded-xl bg-gradient-to-r from-amber-500 to-yellow-600 hover:from-amber-600 hover:to-yellow-700 text-white font-black text-[11px] shadow-sm flex items-center gap-1.5 transition-all active:scale-95"
                      >
                        <Crown className="w-3 h-3 fill-white" />
                        <span>Unlock Deal (₹49)</span>
                      </button>
                    </div>
                  </div>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </section>
  );
};
