import React from 'react';
import { Home, Mail, Link2, History, Gift } from 'lucide-react';
import { ScreenTab } from '../types';

interface BottomNavProps {
  currentTab: ScreenTab;
  onSelectTab: (tab: ScreenTab) => void;
  pendingRewardRequestsCount?: number;
  unreadInboxCount?: number;
}

export const BottomNav: React.FC<BottomNavProps> = ({
  currentTab,
  onSelectTab,
  pendingRewardRequestsCount = 0,
  unreadInboxCount = 0,
}) => {
  return (
    <nav className="fixed bottom-0 left-0 right-0 z-40 bg-white/95 backdrop-blur-md border-t border-slate-200/90 py-1 px-1.5 shadow-xl shadow-slate-900/10">
      <div className="max-w-md mx-auto grid grid-cols-4 items-center">
        {/* Tab 1: Home */}
        <button
          onClick={() => onSelectTab('home')}
          className={`flex flex-col items-center justify-center py-1 transition-all ${
            currentTab === 'home'
              ? 'text-emerald-700 font-extrabold'
              : 'text-slate-400 hover:text-slate-600 font-medium'
          }`}
        >
          <Home
            className={`w-5 h-5 transition-transform ${
              currentTab === 'home' ? 'scale-110 text-emerald-600' : ''
            }`}
          />
          <span className="text-[10px] mt-0.5 tracking-tight">Home</span>
          {currentTab === 'home' && (
            <span className="w-1.5 h-1.5 bg-emerald-600 rounded-full mt-0.5" />
          )}
        </button>

        {/* Tab 2: Inbox (Mail / Delivered Links - "inbox wala Mel wala niche") */}
        <button
          onClick={() => onSelectTab('inbox')}
          className={`relative flex flex-col items-center justify-center py-1 transition-all ${
            currentTab === 'inbox'
              ? 'text-emerald-700 font-extrabold'
              : 'text-slate-400 hover:text-slate-600 font-medium'
          }`}
        >
          <div className="relative">
            <Mail
              className={`w-5 h-5 transition-transform ${
                currentTab === 'inbox' ? 'scale-110 text-emerald-600' : ''
              }`}
            />
            {unreadInboxCount > 0 && (
              <span className="absolute -top-1 -right-2 w-2.5 h-2.5 bg-emerald-600 rounded-full border border-white animate-pulse" />
            )}
          </div>
          <span className="text-[10px] mt-0.5 tracking-tight">Inbox</span>
          {currentTab === 'inbox' && (
            <span className="w-1.5 h-1.5 bg-emerald-600 rounded-full mt-0.5" />
          )}
        </button>

        {/* Tab 3: Reward Link (Center Prominent Elevated Feature Button) */}
        <button
          onClick={() => onSelectTab('reward-link')}
          className="relative flex flex-col items-center justify-center -mt-3.5 group"
        >
          <div
            className={`w-12 h-12 rounded-2xl flex items-center justify-center shadow-lg transition-all ${
              currentTab === 'reward-link'
                ? 'bg-gradient-to-tr from-emerald-600 via-teal-600 to-emerald-500 text-white shadow-emerald-600/35 ring-3 ring-emerald-100 scale-105'
                : 'bg-gradient-to-tr from-emerald-600 to-teal-700 text-white shadow-emerald-600/25 hover:scale-105'
            }`}
          >
            <Link2 className="w-5 h-5 stroke-[2.5]" />
          </div>
          <span
            className={`text-[9px] font-extrabold mt-0.5 tracking-tight ${
              currentTab === 'reward-link' ? 'text-emerald-700' : 'text-slate-700'
            }`}
          >
            Reward Link
          </span>
          {pendingRewardRequestsCount > 0 && (
            <span className="absolute -top-1 right-2 w-2.5 h-2.5 bg-amber-500 rounded-full border-2 border-white animate-pulse" />
          )}
        </button>

        {/* Tab 4: History ("Sara kuchh usmein hi") */}
        <button
          onClick={() => onSelectTab('history')}
          className={`flex flex-col items-center justify-center py-1 transition-all ${
            currentTab === 'history'
              ? 'text-teal-700 font-extrabold'
              : 'text-slate-400 hover:text-slate-600 font-medium'
          }`}
        >
          <History
            className={`w-5 h-5 transition-transform ${
              currentTab === 'history' ? 'scale-110 text-teal-600' : ''
            }`}
          />
          <span className="text-[10px] mt-0.5 tracking-tight">History</span>
          {currentTab === 'history' && (
            <span className="w-1.5 h-1.5 bg-teal-600 rounded-full mt-0.5" />
          )}
        </button>
      </div>
    </nav>
  );
};
