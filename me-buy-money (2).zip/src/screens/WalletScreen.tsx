import React from 'react';
import { useAuth } from '../context/AuthContext';
import {
  Wallet as WalletIcon,
  ArrowUpRight,
  Clock,
  CheckCircle2,
  AlertOctagon,
  TrendingUp,
  PieChart,
  ShieldCheck,
  History,
  Info,
} from 'lucide-react';
import { ScreenTab } from '../types';

interface WalletScreenProps {
  onNavigate: (tab: ScreenTab) => void;
}

export const WalletScreen: React.FC<WalletScreenProps> = ({ onNavigate }) => {
  const { wallet, profile } = useAuth();

  const available = wallet?.availableBalance ?? 0;
  const pending = wallet?.pendingCashback ?? 0;
  const confirmed = wallet?.confirmedCashback ?? 0;
  const totalEarned = wallet?.totalEarned ?? 0;
  const totalWithdrawn = wallet?.totalWithdrawn ?? 0;
  const rejected = wallet?.rejectedCashback ?? 0;

  return (
    <div className="space-y-6 pb-20">
      {/* Top Banner */}
      <div className="bg-gradient-to-br from-emerald-800 via-teal-800 to-slate-900 text-white rounded-3xl p-6 sm:p-8 shadow-xl relative overflow-hidden space-y-5">
        <div className="relative z-10 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <span className="text-emerald-300 text-xs font-bold uppercase tracking-wider block">
              Official Cashback Wallet
            </span>
            <h1 className="text-3xl sm:text-4xl font-black mt-1">
              ₹{available.toLocaleString('en-IN', { minimumFractionDigits: 2 })}
            </h1>
            <p className="text-xs text-emerald-100 font-medium mt-1">
              Available Balance (Ready for instant UPI or Bank Transfer)
            </p>
          </div>

          <div className="flex gap-2">
            <button
              onClick={() => onNavigate('withdraw')}
              disabled={available < 250}
              className={`px-5 py-3 rounded-2xl font-bold text-xs shadow-lg flex items-center gap-2 transition-all ${
                available >= 250
                  ? 'bg-white text-emerald-900 hover:bg-emerald-50 hover:scale-105 shadow-white/10'
                  : 'bg-white/20 text-white/60 cursor-not-allowed'
              }`}
            >
              <ArrowUpRight className="w-4 h-4" />
              <span>Withdraw Money</span>
            </button>
            <button
              onClick={() => onNavigate('transactions')}
              className="px-4 py-3 rounded-2xl bg-white/10 hover:bg-white/20 text-white font-semibold text-xs transition-colors flex items-center gap-1.5"
            >
              <History className="w-4 h-4" />
              <span className="hidden sm:inline">Passbook</span>
            </button>
          </div>
        </div>

        {available < 250 && (
          <div className="relative z-10 bg-white/10 backdrop-blur-sm rounded-xl p-2.5 text-[11px] text-emerald-100 flex items-center gap-2">
            <Info className="w-4 h-4 text-emerald-300 shrink-0" />
            <span>
              Minimum withdrawal is <strong>₹250</strong>. You need ₹{(250 - available).toFixed(2)} more to cash out!
            </span>
          </div>
        )}
      </div>

      {/* 6 Required Wallet Metrics */}
      <div className="grid grid-cols-2 sm:grid-cols-3 gap-3.5">
        {/* Pending */}
        <div className="bg-white p-4 rounded-2xl border border-slate-200/90 shadow-xs space-y-1">
          <div className="flex items-center justify-between text-slate-400">
            <span className="text-[10px] font-bold uppercase tracking-wider">Pending Cashback</span>
            <Clock className="w-4 h-4 text-amber-500" />
          </div>
          <div className="text-lg sm:text-xl font-black text-amber-600">
            ₹{pending.toLocaleString('en-IN', { minimumFractionDigits: 2 })}
          </div>
          <p className="text-[10px] text-slate-400">Awaiting store return window</p>
        </div>

        {/* Confirmed */}
        <div className="bg-white p-4 rounded-2xl border border-slate-200/90 shadow-xs space-y-1">
          <div className="flex items-center justify-between text-slate-400">
            <span className="text-[10px] font-bold uppercase tracking-wider">Confirmed Cashback</span>
            <CheckCircle2 className="w-4 h-4 text-emerald-600" />
          </div>
          <div className="text-lg sm:text-xl font-black text-emerald-600">
            ₹{confirmed.toLocaleString('en-IN', { minimumFractionDigits: 2 })}
          </div>
          <p className="text-[10px] text-slate-400">Verified by affiliate network</p>
        </div>

        {/* Available Balance */}
        <div className="bg-white p-4 rounded-2xl border border-slate-200/90 shadow-xs space-y-1">
          <div className="flex items-center justify-between text-slate-400">
            <span className="text-[10px] font-bold uppercase tracking-wider">Available Balance</span>
            <WalletIcon className="w-4 h-4 text-teal-600" />
          </div>
          <div className="text-lg sm:text-xl font-black text-slate-900">
            ₹{available.toLocaleString('en-IN', { minimumFractionDigits: 2 })}
          </div>
          <p className="text-[10px] text-slate-400">Ready to withdraw</p>
        </div>

        {/* Total Earned */}
        <div className="bg-white p-4 rounded-2xl border border-slate-200/90 shadow-xs space-y-1">
          <div className="flex items-center justify-between text-slate-400">
            <span className="text-[10px] font-bold uppercase tracking-wider">Total Earned</span>
            <TrendingUp className="w-4 h-4 text-blue-600" />
          </div>
          <div className="text-lg sm:text-xl font-black text-blue-600">
            ₹{totalEarned.toLocaleString('en-IN', { minimumFractionDigits: 2 })}
          </div>
          <p className="text-[10px] text-slate-400">Lifetime confirmed cashback</p>
        </div>

        {/* Total Withdrawn */}
        <div className="bg-white p-4 rounded-2xl border border-slate-200/90 shadow-xs space-y-1">
          <div className="flex items-center justify-between text-slate-400">
            <span className="text-[10px] font-bold uppercase tracking-wider">Total Withdrawn</span>
            <ArrowUpRight className="w-4 h-4 text-purple-600" />
          </div>
          <div className="text-lg sm:text-xl font-black text-purple-600">
            ₹{totalWithdrawn.toLocaleString('en-IN', { minimumFractionDigits: 2 })}
          </div>
          <p className="text-[10px] text-slate-400">Transferred to Bank/UPI</p>
        </div>

        {/* Rejected Cashback */}
        <div className="bg-white p-4 rounded-2xl border border-slate-200/90 shadow-xs space-y-1">
          <div className="flex items-center justify-between text-slate-400">
            <span className="text-[10px] font-bold uppercase tracking-wider">Rejected Cashback</span>
            <AlertOctagon className="w-4 h-4 text-rose-500" />
          </div>
          <div className="text-lg sm:text-xl font-black text-rose-500">
            ₹{rejected.toLocaleString('en-IN', { minimumFractionDigits: 2 })}
          </div>
          <p className="text-[10px] text-slate-400">Cancelled / returned orders</p>
        </div>
      </div>

      {/* 40% User vs 60% Platform Explainer Card */}
      <div className="bg-white rounded-3xl p-6 border border-slate-200/90 shadow-xs space-y-4">
        <div className="flex items-center gap-2">
          <PieChart className="w-5 h-5 text-emerald-600" />
          <h3 className="text-base font-bold text-slate-900">
            Transparent Commission Distribution (40% / 60% Split)
          </h3>
        </div>

        <p className="text-xs text-slate-600 leading-relaxed">
          Unlike ordinary discount sites that keep 100% of the merchant affiliate commission, Me BUY MONEY returns <strong>40% of confirmed commissions</strong> to our shoppers.
        </p>

        {/* Distribution diagram */}
        <div className="bg-slate-50 p-4 rounded-2xl border border-slate-200/70 space-y-3">
          <div className="flex justify-between text-xs font-bold text-slate-700">
            <span>Example: Store Pays ₹100 Affiliate Commission</span>
            <span className="text-emerald-700">₹100 Gross Payout</span>
          </div>

          {/* Progress bar split */}
          <div className="h-6 w-full rounded-xl bg-slate-200 overflow-hidden flex text-[10px] font-bold text-white text-center leading-6">
            <div className="bg-emerald-600 w-[40%]">
              40% (₹40 to YOU)
            </div>
            <div className="bg-slate-700 w-[60%]">
              60% (₹60 Platform Operations & Taxes)
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1 text-xs">
            <div className="bg-emerald-50 p-2.5 rounded-xl border border-emerald-100">
              <strong className="text-emerald-900 font-bold block">Your Share: 40% (₹40)</strong>
              <span className="text-[11px] text-emerald-800">
                Credited to your Available Balance once the merchant verifies the order. Withdraw anytime to UPI or Bank.
              </span>
            </div>
            <div className="bg-slate-100 p-2.5 rounded-xl border border-slate-200">
              <strong className="text-slate-900 font-bold block">Platform Share: 60% (₹60)</strong>
              <span className="text-[11px] text-slate-600">
                Covers server infrastructure, API tracking, banking transfer fees, and GST compliance.
              </span>
            </div>
          </div>
        </div>

        {/* Security badge */}
        <div className="flex items-center gap-2 text-xs text-slate-500 pt-1">
          <ShieldCheck className="w-4 h-4 text-emerald-600 shrink-0" />
          <span>
            Secure ledger enforced: Wallet balances are validated server-side. No client-side modifications permitted.
          </span>
        </div>
      </div>
    </div>
  );
};
