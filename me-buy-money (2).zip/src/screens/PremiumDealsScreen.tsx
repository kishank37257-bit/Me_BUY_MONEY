import React, { useState, useEffect } from 'react';
import {
  Sparkles,
  Flame,
  Clock,
  ShieldCheck,
  ExternalLink,
  Search,
  Filter,
  ArrowRight,
  Tag,
  CheckCircle2,
  Crown,
  Lock,
  Unlock,
} from 'lucide-react';
import { getPremiumDeals, buildStoreAffiliateUrl } from '../services/dbService';
import { PremiumDeal, ScreenTab } from '../types';
import { useAuth } from '../context/AuthContext';

interface PremiumDealsScreenProps {
  onNavigate: (tab: ScreenTab) => void;
  onSelectDeal?: (deal: PremiumDeal) => void;
}

export const PremiumDealsScreen: React.FC<PremiumDealsScreenProps> = ({
  onNavigate,
  onSelectDeal,
}) => {
  const { isSubscribed, openVIPModal, toggleVIPSubscription } = useAuth();
  const [deals, setDeals] = useState<PremiumDeal[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [searchQuery, setSearchQuery] = useState('');
  const [redirectingDeal, setRedirectingDeal] = useState<PremiumDeal | null>(null);

  const categories = ['All', 'Electronics', 'Fashion', 'Beauty', 'Travel', 'Home & Kitchen', 'Watches', 'Gaming'];

  useEffect(() => {
    loadDeals();
  }, []);

  const loadDeals = async () => {
    try {
      setLoading(true);
      const data = await getPremiumDeals();
      setDeals(data);
    } catch (e) {
      console.warn('Error loading premium deals:', e);
    } finally {
      setLoading(false);
    }
  };

  const filteredDeals = deals.filter((deal) => {
    const matchesCat =
      selectedCategory === 'All' ||
      deal.category.toLowerCase().includes(selectedCategory.toLowerCase());
    const matchesSearch =
      !searchQuery.trim() ||
      deal.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      deal.storeName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      deal.description.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCat && matchesSearch;
  });

  const handleShopDeal = (deal: PremiumDeal) => {
    setRedirectingDeal(deal);
    setTimeout(() => {
      const destination = buildStoreAffiliateUrl(deal.affiliateUrl, deal.storeName, 'MBM_VIP');
      window.open(destination, '_blank', 'noopener,noreferrer');
      setRedirectingDeal(null);
    }, 1200);
  };

  return (
    <div className="space-y-6 pb-24 max-w-5xl mx-auto">
      {/* Hero Header */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-r from-purple-900 via-indigo-900 to-slate-900 text-white p-6 sm:p-8 shadow-xl">
        <div className="relative z-10 max-w-xl space-y-3">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-white/10 backdrop-blur-md border border-white/20 text-purple-200 text-xs font-bold uppercase tracking-wider">
            <Sparkles className="w-3.5 h-3.5 text-amber-300" />
            <span>Curated High-Payout Deals</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-black tracking-tight text-white">
            Me BUY MONEY Deals
          </h1>
          <p className="text-xs text-purple-200/90 leading-relaxed">
            Hand-picked offers with guaranteed enhanced cashback rates. All transactions verified via partner affiliate networks.
          </p>
        </div>

        {/* Decorative background glow */}
        <div className="absolute right-0 top-0 bottom-0 w-1/2 bg-gradient-to-l from-purple-500/20 to-transparent pointer-events-none" />
      </div>

      {/* Filter & Search Bar */}
      <div className="space-y-3">
        <div className="flex flex-col sm:flex-row gap-3">
          {/* Search */}
          <div className="relative flex-1">
            <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search premium deals, products or stores..."
              className="w-full pl-10 pr-4 py-3 bg-white border border-slate-200 rounded-2xl text-xs font-medium text-slate-800 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-purple-500/20 focus:border-purple-500"
            />
          </div>

          {/* Custom Link CTA */}
          <button
            onClick={() => onNavigate('reward-link')}
            className="px-4 py-3 rounded-2xl bg-emerald-50 text-emerald-800 hover:bg-emerald-100 font-bold text-xs border border-emerald-200 flex items-center justify-center gap-2 shrink-0 transition-colors"
          >
            <Tag className="w-4 h-4 text-emerald-600" />
            <span>Have another product? Create Reward Link</span>
          </button>
        </div>

        {/* Categories Pills */}
        <div className="flex items-center gap-2 overflow-x-auto pb-1 scrollbar-none">
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-4 py-2 rounded-xl text-xs font-bold whitespace-nowrap transition-all ${
                selectedCategory === cat
                  ? 'bg-purple-600 text-white shadow-sm shadow-purple-600/30'
                  : 'bg-white text-slate-600 hover:bg-slate-100 border border-slate-200/80'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>
      </div>

      {/* Deals Grid */}
      {loading ? (
        <div className="text-center py-16 text-xs text-slate-400">Loading exclusive premium deals...</div>
      ) : filteredDeals.length === 0 ? (
        <div className="bg-white rounded-3xl p-12 text-center border border-slate-200 space-y-3">
          <p className="text-sm font-bold text-slate-700">No deals found matching your query</p>
          <p className="text-xs text-slate-400">
            Try adjusting your search or category filters, or generate your own cashback link using our Reward Link tool.
          </p>
          <button
            onClick={() => {
              setSelectedCategory('All');
              setSearchQuery('');
            }}
            className="px-4 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold"
          >
            Clear Filters
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {filteredDeals.map((deal) => {
            const discountPct = Math.round(
              ((deal.originalPrice - deal.dealPrice) / deal.originalPrice) * 100
            );

            return (
              <div
                key={deal.id}
                className="bg-white rounded-3xl border border-slate-200/90 hover:border-purple-300 transition-all duration-200 overflow-hidden shadow-xs hover:shadow-md flex flex-col group"
              >
                {/* Image & Badges Container */}
                <div className="relative aspect-4/3 bg-slate-100 overflow-hidden">
                  <img
                    src={deal.imageUrl}
                    alt={deal.title}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                    loading="lazy"
                  />

                  {/* Exclusive Tag */}
                  {deal.isExclusive && (
                    <div className="absolute top-3 left-3 bg-gradient-to-r from-amber-500 to-rose-500 text-white text-[10px] font-black uppercase px-2.5 py-1 rounded-full shadow-md flex items-center gap-1">
                      <Flame className="w-3 h-3 fill-current" />
                      <span>MBM Exclusive</span>
                    </div>
                  )}

                  {/* Store Badge */}
                  <div className="absolute bottom-3 left-3 bg-white/95 backdrop-blur-md px-2.5 py-1 rounded-xl shadow-xs text-[11px] font-bold text-slate-800 flex items-center gap-1.5 border border-slate-200/60">
                    <img
                      src={deal.storeLogo}
                      alt={deal.storeName}
                      className="w-4 h-4 object-contain rounded"
                      onError={(e) => {
                        (e.target as HTMLElement).style.display = 'none';
                      }}
                    />
                    <span>{deal.storeName}</span>
                  </div>

                  {/* Category & Live Expiry */}
                  <div className="absolute top-3 right-3 bg-slate-900/85 backdrop-blur-md text-amber-300 text-[10px] font-mono font-bold px-2.5 py-1 rounded-xl flex items-center gap-1.5 border border-white/10 shadow-sm">
                    <Clock className="w-3.5 h-3.5 text-amber-400 animate-pulse" />
                    <span>Ending Soon</span>
                  </div>
                </div>

                {/* Content */}
                <div className="p-4 sm:p-5 flex-1 flex flex-col justify-between space-y-4">
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-[10px] font-extrabold uppercase text-purple-700 bg-purple-50 px-2 py-0.5 rounded-md border border-purple-200">
                        {deal.category}
                      </span>
                      {isSubscribed ? (
                        <span className="text-[10px] font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-md flex items-center gap-1">
                          <Unlock className="w-3 h-3 text-emerald-600" />
                          <span>Unlocked</span>
                        </span>
                      ) : (
                        <span className="text-[10px] font-bold text-amber-700 bg-amber-50 px-2 py-0.5 rounded-md flex items-center gap-1">
                          <Lock className="w-3 h-3 text-amber-600" />
                          <span>VIP Locked</span>
                        </span>
                      )}
                    </div>

                    <h3 className="font-extrabold text-sm text-slate-900 line-clamp-2 leading-snug group-hover:text-purple-700 transition-colors">
                      {deal.title}
                    </h3>
                    <p className="text-xs text-slate-500 line-clamp-2 leading-relaxed">
                      {deal.description}
                    </p>
                  </div>

                  {/* Pricing and Cashback Highlight */}
                  <div className="space-y-3 pt-1 border-t border-slate-100">
                    <div className="flex items-baseline justify-between">
                      <div className="flex items-baseline gap-2">
                        <span className="text-lg font-black text-slate-900">
                          ₹{deal.dealPrice.toLocaleString('en-IN')}
                        </span>
                        <span className="text-xs text-slate-400 line-through">
                          ₹{deal.originalPrice.toLocaleString('en-IN')}
                        </span>
                      </div>
                      <span className="text-[11px] font-bold text-emerald-600 bg-emerald-50 px-2 py-0.5 rounded-lg border border-emerald-200">
                        {discountPct}% OFF
                      </span>
                    </div>

                    {/* Prominent Cashback Badge */}
                    <div className="bg-gradient-to-r from-purple-50 to-indigo-50 border border-purple-200/80 rounded-2xl p-2.5 flex items-center justify-between">
                      <div className="flex items-center gap-1.5">
                        <Sparkles className="w-3.5 h-3.5 text-purple-600 shrink-0" />
                        <span className="text-xs font-black text-purple-900">
                          {deal.cashbackLabel}
                        </span>
                      </div>
                      <span className="text-[10px] uppercase font-bold text-purple-600">
                        Verified
                      </span>
                    </div>
                  </div>

                  {/* Subscribed: Unblurred Action vs Unsubscribed: Blurred */}
                  {isSubscribed ? (
                    <div>
                      <button
                        onClick={() => handleShopDeal(deal)}
                        className="w-full py-3 px-4 rounded-2xl bg-gradient-to-r from-purple-600 via-indigo-600 to-purple-600 hover:from-purple-700 hover:to-indigo-700 text-white font-extrabold text-xs shadow-md shadow-purple-600/20 flex items-center justify-center gap-2 transition-all hover:scale-[1.01]"
                      >
                        <span>Shop with Cashback</span>
                        <ExternalLink className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  ) : (
                    <div className="relative pt-1 overflow-hidden rounded-2xl">
                      <div className="filter blur-[5px] select-none pointer-events-none opacity-40">
                        <div className="w-full py-3 rounded-2xl bg-purple-600 text-white text-xs font-bold text-center">
                          Shop with Cashback
                        </div>
                      </div>
                      <div className="absolute inset-0 bg-white/80 backdrop-blur-[2px] flex flex-col items-center justify-center p-3 text-center space-y-1.5 rounded-2xl border border-amber-300 shadow-xs">
                        <div className="flex items-center gap-1 text-[11px] font-black text-amber-950 uppercase">
                          <Lock className="w-3 h-3 text-amber-600" />
                          <span>VIP Exclusive</span>
                        </div>
                        <button
                          type="button"
                          onClick={openVIPModal}
                          className="py-1.5 px-4 rounded-xl bg-gradient-to-r from-amber-500 to-yellow-600 text-white font-black text-xs shadow-sm flex items-center gap-1"
                        >
                          <Crown className="w-3 h-3 fill-white" />
                          <span>Unlock Deal (₹49)</span>
                        </button>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Redirecting Modal */}
      {redirectingDeal && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl p-6 max-w-sm w-full text-center space-y-4 shadow-2xl animate-in zoom-in-95">
            <div className="w-12 h-12 rounded-2xl bg-purple-100 text-purple-600 flex items-center justify-center mx-auto animate-bounce">
              <ExternalLink className="w-6 h-6" />
            </div>
            <div className="space-y-1">
              <h3 className="font-extrabold text-slate-900 text-base">
                Redirecting to {redirectingDeal.storeName}
              </h3>
              <p className="text-xs text-slate-500">
                Attaching your Me BUY MONEY affiliate sub-ID to activate verified cashback...
              </p>
            </div>
            <div className="w-full bg-slate-100 rounded-full h-1.5 overflow-hidden">
              <div className="bg-purple-600 h-full w-full animate-pulse" />
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
