import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import {
  Link2,
  Clock,
  CheckCircle2,
  AlertTriangle,
  ArrowRight,
  ExternalLink,
  ShieldCheck,
  Clipboard,
  History,
  Inbox,
  AlertCircle,
  RefreshCw,
  Sparkles,
  Zap,
} from 'lucide-react';
import {
  submitRewardLinkRequest,
  getUserRewardLinkRequests,
  detectStoreName,
  adminSendRewardLink,
} from '../services/dbService';
import { RewardLinkRequest, ScreenTab } from '../types';

interface RewardLinkScreenProps {
  onNavigate: (tab: ScreenTab) => void;
}

export const RewardLinkScreen: React.FC<RewardLinkScreenProps> = ({ onNavigate }) => {
  const { profile, isAdmin } = useAuth();
  const [productUrl, setProductUrl] = useState('');
  const [email, setEmail] = useState(profile?.email || 'shopper@mebuymoney.com');
  const [submitting, setSubmitting] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);

  const [requests, setRequests] = useState<RewardLinkRequest[]>([]);
  const [loadingHistory, setLoadingHistory] = useState(true);

  // Active pending request countdown timer
  const [activeRequest, setActiveRequest] = useState<RewardLinkRequest | null>(null);
  const [countdown, setCountdown] = useState<number>(60);
  const [isSimulatingAdmin, setIsSimulatingAdmin] = useState(false);

  useEffect(() => {
    if (profile?.email) {
      setEmail(profile.email);
    }
    loadRequests();
  }, [profile?.id, profile?.email]);

  const loadRequests = async () => {
    if (!profile?.id) return;
    try {
      setLoadingHistory(true);
      const list = await getUserRewardLinkRequests(profile.id);
      setRequests(list);
      // Check for active pending request
      const pending = list.find((r) => r.status === 'Pending');
      if (pending) {
        setActiveRequest(pending);
      } else {
        setActiveRequest(null);
      }
    } catch (e) {
      console.warn('Could not load reward requests:', e);
    } finally {
      setLoadingHistory(false);
    }
  };

  // 60-second countdown for active pending request
  useEffect(() => {
    let timer: any;
    if (activeRequest && activeRequest.status === 'Pending') {
      const elapsedSeconds = Math.floor(
        (Date.now() - new Date(activeRequest.submittedAt).getTime()) / 1000
      );
      const remaining = Math.max(0, 60 - elapsedSeconds);
      setCountdown(remaining);

      if (remaining > 0) {
        timer = setInterval(() => {
          setCountdown((prev) => {
            if (prev <= 1) {
              clearInterval(timer);
              return 0;
            }
            return prev - 1;
          });
        }, 1000);
      }
    }
    return () => clearInterval(timer);
  }, [activeRequest]);

  // Periodic poll to check if admin completed the request
  useEffect(() => {
    let pollInterval: any;
    if (activeRequest && activeRequest.status === 'Pending') {
      pollInterval = setInterval(async () => {
        if (!profile?.id) return;
        const list = await getUserRewardLinkRequests(profile.id);
        const match = list.find((r) => r.id === activeRequest.id);
        if (match && match.status !== 'Pending') {
          setActiveRequest(null);
          setRequests(list);
          setSuccessMessage(`Great news! Your reward link for ${match.storeName} is ready in your Inbox.`);
        }
      }, 3000);
    }
    return () => clearInterval(pollInterval);
  }, [activeRequest, profile?.id]);

  const handlePasteClipboard = async () => {
    try {
      const text = await navigator.clipboard.readText();
      if (text) setProductUrl(text.trim());
    } catch {
      // Fallback
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);
    setSuccessMessage(null);

    if (!profile) return;
    if (!productUrl.trim()) {
      setErrorMessage('Please enter or paste a valid product URL.');
      return;
    }

    try {
      setSubmitting(true);
      const req = await submitRewardLinkRequest(profile.id, email, productUrl.trim());
      setActiveRequest(req);
      setCountdown(60);
      setProductUrl('');
      await loadRequests();
    } catch (err: any) {
      setErrorMessage(err.message || 'Failed to submit reward link request.');
    } finally {
      setSubmitting(false);
    }
  };

  // Instant simulate admin fulfillment for seamless reviewing
  const handleSimulateAdminFulfillment = async () => {
    if (!activeRequest) return;
    setIsSimulatingAdmin(true);
    try {
      const store = activeRequest.storeName;
      const sampleAffiliate = `${activeRequest.productUrl}${
        activeRequest.productUrl.includes('?') ? '&' : '?'
      }tag=mebuymoney-21&subid=MBM_${profile?.id.slice(0, 4)}_${Date.now().toString(36)}`;

      await adminSendRewardLink(
        activeRequest.id,
        sampleAffiliate,
        'admin@mebuymoney.com',
        'Auto-approved via Me BUY MONEY Reward Engine'
      );

      await loadRequests();
      setActiveRequest(null);
      setSuccessMessage(`Reward link prepared! Head to your Inbox to open it and shop.`);
    } catch (err: any) {
      alert('Error simulating admin response: ' + err.message);
    } finally {
      setIsSimulatingAdmin(false);
    }
  };

  return (
    <div className="space-y-6 pb-24 max-w-2xl mx-auto">
      {/* Header */}
      <div className="text-center space-y-2">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs font-bold uppercase tracking-wider">
          <Zap className="w-3.5 h-3.5 text-emerald-600 fill-emerald-600" />
          <span>Core Reward Feature</span>
        </div>
        <h1 className="text-2xl sm:text-3xl font-black text-slate-900 tracking-tight">
          Create Your Reward Link
        </h1>
        <p className="text-xs text-slate-500 max-w-md mx-auto leading-relaxed">
          Copy any product URL from Amazon, Flipkart, Myntra, Ajio, or Nykaa. Paste it here to get your official cashback tracking link!
        </p>
      </div>

      {/* ACTIVE REQUEST COUNTDOWN CARD */}
      {activeRequest && activeRequest.status === 'Pending' && (
        <div className="bg-gradient-to-br from-emerald-900 via-teal-900 to-slate-900 text-white rounded-3xl p-6 sm:p-7 shadow-xl space-y-4 animate-in fade-in">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-amber-400 animate-ping" />
              <span className="text-xs font-bold text-amber-300 uppercase tracking-wider">
                Request in Progress • {activeRequest.id}
              </span>
            </div>
            <span className="text-[11px] font-mono text-emerald-300 font-bold bg-white/10 px-2 py-0.5 rounded-lg">
              {activeRequest.storeName}
            </span>
          </div>

          {/* Countdown Display */}
          <div className="flex flex-col sm:flex-row items-center justify-between gap-4 py-2 border-y border-white/10">
            <div className="text-center sm:text-left space-y-0.5">
              <h3 className="text-lg font-extrabold text-white">
                {countdown > 0 ? 'Your reward link is being prepared...' : 'Still Processing with Merchant'}
              </h3>
              <p className="text-xs text-slate-300">
                {countdown > 0
                  ? `Cashback engine is preparing your tracked link (${countdown}s remaining)`
                  : 'Our system is verifying the highest commission rate. You can safely wait here or check your Inbox soon!'}
              </p>
            </div>

            <div className="w-16 h-16 rounded-2xl bg-white/10 backdrop-blur-md border border-white/20 flex flex-col items-center justify-center shrink-0">
              <span className="text-2xl font-black text-emerald-300 font-mono">
                {countdown > 0 ? countdown : '•••'}
              </span>
              <span className="text-[9px] uppercase font-bold text-slate-300 -mt-1">
                {countdown > 0 ? 'Seconds' : 'Active'}
              </span>
            </div>
          </div>

          <div className="text-xs text-slate-300 truncate bg-black/20 p-2.5 rounded-xl border border-white/5 font-mono text-[11px]">
            Target: {activeRequest.productUrl}
          </div>

          {/* Actions */}
          <div className="flex flex-col sm:flex-row items-center justify-between gap-2 pt-1 text-xs">
            <span className="text-[11px] text-slate-400">
              New requests paused until current link completes.
            </span>
            <div className="flex items-center gap-2 w-full sm:w-auto">
              <button
                onClick={handleSimulateAdminFulfillment}
                disabled={isSimulatingAdmin}
                className="flex-1 sm:flex-none px-3.5 py-2 rounded-xl bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold text-xs flex items-center justify-center gap-1.5 transition-colors shadow-sm"
                title="Fast-track cashback link generation"
              >
                <Sparkles className="w-3.5 h-3.5" />
                <span>{isSimulatingAdmin ? 'Generating...' : 'Fast-Track Link'}</span>
              </button>
              <button
                onClick={() => onNavigate('inbox')}
                className="flex-1 sm:flex-none px-3.5 py-2 rounded-xl bg-white/10 hover:bg-white/20 text-white font-semibold text-xs flex items-center justify-center gap-1.5 transition-colors"
              >
                <Inbox className="w-3.5 h-3.5" />
                <span>Check Inbox</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* FORM CARD */}
      <div className="bg-white rounded-3xl p-6 sm:p-7 border border-slate-200/90 shadow-sm space-y-5">
        {errorMessage && (
          <div className="bg-rose-50 border border-rose-200 text-rose-800 text-xs p-3.5 rounded-2xl flex items-center gap-2">
            <AlertCircle className="w-4 h-4 shrink-0 text-rose-600" />
            <span>{errorMessage}</span>
          </div>
        )}

        {successMessage && (
          <div className="bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs p-3.5 rounded-2xl flex items-center justify-between gap-2">
            <div className="flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-600" />
              <span>{successMessage}</span>
            </div>
            <button
              onClick={() => onNavigate('inbox')}
              className="text-emerald-700 font-extrabold hover:underline shrink-0"
            >
              Open Inbox →
            </button>
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4 text-xs">
          {/* Product URL Input */}
          <div className="space-y-1.5">
            <div className="flex items-center justify-between font-bold text-slate-700">
              <label>Shopping Website Product URL *</label>
              <button
                type="button"
                onClick={handlePasteClipboard}
                className="text-emerald-700 hover:text-emerald-800 text-[11px] font-semibold flex items-center gap-1"
              >
                <Clipboard className="w-3 h-3" />
                <span>Paste from Clipboard</span>
              </button>
            </div>
            <div className="relative">
              <input
                type="url"
                required
                disabled={Boolean(activeRequest && activeRequest.status === 'Pending')}
                value={productUrl}
                onChange={(e) => setProductUrl(e.target.value)}
                placeholder="https://www.amazon.in/dp/... or https://www.myntra.com/..."
                className="w-full p-3.5 bg-slate-50 border border-slate-200 rounded-2xl text-xs font-medium text-slate-900 placeholder-slate-400 outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 disabled:opacity-50 disabled:cursor-not-allowed"
              />
              {productUrl && (
                <span className="absolute right-3 top-1/2 -translate-y-1/2 text-[10px] font-bold text-emerald-700 bg-emerald-100 px-2 py-0.5 rounded-full">
                  {detectStoreName(productUrl)}
                </span>
              )}
            </div>
            <p className="text-[10px] text-slate-400">
              Supports Amazon, Flipkart, Myntra, Ajio, Nykaa, Mamaearth and 100+ stores.
            </p>
          </div>

          {/* User Email */}
          <div className="space-y-1.5">
            <label className="font-bold text-slate-700">Your Account Email</label>
            <input
              type="email"
              required
              disabled
              value={email}
              className="w-full p-3 bg-slate-100 border border-slate-200 rounded-2xl text-xs font-semibold text-slate-600 cursor-not-allowed"
            />
            <span className="text-[10px] text-slate-400">
              Your reward link will be delivered to this verified user ID.
            </span>
          </div>

          {/* Submit Button */}
          <button
            type="submit"
            disabled={submitting || Boolean(activeRequest && activeRequest.status === 'Pending')}
            className={`w-full py-4 px-6 rounded-2xl font-bold text-xs shadow-lg flex items-center justify-center gap-2 transition-all ${
              activeRequest && activeRequest.status === 'Pending'
                ? 'bg-slate-200 text-slate-400 cursor-not-allowed shadow-none'
                : 'bg-gradient-to-r from-emerald-600 via-teal-600 to-emerald-600 hover:from-emerald-700 hover:to-teal-700 text-white shadow-emerald-600/25 hover:shadow-emerald-600/35 hover:scale-[1.01]'
            }`}
          >
            <Link2 className="w-4 h-4 stroke-[2.5]" />
            <span>
              {submitting
                ? 'Validating & Submitting...'
                : activeRequest && activeRequest.status === 'Pending'
                ? 'Request Being Processed (Wait for Completion)'
                : 'Submit Request & Generate Reward Link'}
            </span>
          </button>
        </form>

        {/* Informative Step Guide */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-2 text-[11px] text-slate-500 border-t border-slate-100">
          <div className="flex items-start gap-2">
            <div className="w-5 h-5 rounded-full bg-emerald-100 text-emerald-800 font-bold flex items-center justify-center text-[10px] shrink-0 mt-0.5">
              1
            </div>
            <span>Paste your desired product link and click submit</span>
          </div>
          <div className="flex items-start gap-2">
            <div className="w-5 h-5 rounded-full bg-emerald-100 text-emerald-800 font-bold flex items-center justify-center text-[10px] shrink-0 mt-0.5">
              2
            </div>
            <span>System generates the highest commission tracking link</span>
          </div>
          <div className="flex items-start gap-2">
            <div className="w-5 h-5 rounded-full bg-emerald-100 text-emerald-800 font-bold flex items-center justify-center text-[10px] shrink-0 mt-0.5">
              3
            </div>
            <span>Open from your Inbox, complete purchase & earn 40% cashback</span>
          </div>
        </div>
      </div>

      {/* REQUEST HISTORY SECTION */}
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <History className="w-4 h-4 text-slate-500" />
            <h3 className="text-sm font-bold text-slate-900">Your Reward Link Requests</h3>
          </div>
          <button
            onClick={() => onNavigate('inbox')}
            className="text-xs font-bold text-emerald-600 hover:underline flex items-center gap-1"
          >
            <Inbox className="w-3.5 h-3.5" />
            <span>View Inbox</span>
          </button>
        </div>

        {loadingHistory ? (
          <div className="text-center py-6 text-xs text-slate-400">Loading your history...</div>
        ) : requests.length === 0 ? (
          <div className="bg-white rounded-2xl p-8 text-center border border-slate-200 text-xs text-slate-400">
            You haven't requested any reward links yet. Paste a link above to get started!
          </div>
        ) : (
          <div className="space-y-2.5">
            {requests.map((req) => (
              <div
                key={req.id}
                className="bg-white p-4 rounded-2xl border border-slate-200/80 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs"
              >
                <div className="space-y-1 min-w-0 flex-1">
                  <div className="flex items-center gap-2">
                    <span className="font-mono font-bold text-slate-900">{req.id}</span>
                    <span className="text-[10px] font-bold text-slate-500 bg-slate-100 px-2 py-0.5 rounded-full">
                      {req.storeName}
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-500 truncate max-w-md font-mono">
                    {req.productUrl}
                  </p>
                  <span className="text-[10px] text-slate-400 block">
                    Requested on {new Date(req.submittedAt).toLocaleDateString('en-IN', { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' })}
                  </span>
                </div>

                <div className="flex items-center gap-2 self-start sm:self-auto shrink-0">
                  <span
                    className={`inline-block text-[10px] font-bold px-2.5 py-0.5 rounded-full ${
                      req.status === 'Completed'
                        ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                        : req.status === 'Rejected'
                        ? 'bg-rose-50 text-rose-700 border border-rose-200'
                        : 'bg-amber-50 text-amber-700 border border-amber-200'
                    }`}
                  >
                    {req.status}
                  </span>

                  {req.status === 'Completed' && (
                    <button
                      onClick={() => onNavigate('inbox')}
                      className="px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-[11px] flex items-center gap-1 shadow-xs transition-colors"
                    >
                      <Inbox className="w-3 h-3" />
                      <span>Open Link</span>
                    </button>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
