import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import {
  Inbox,
  ExternalLink,
  CheckCircle2,
  Clock,
  ShieldCheck,
  Tag,
  ArrowRight,
  MousePointerClick,
  XCircle,
  Copy,
  Check,
} from 'lucide-react';
import { getUserInbox, openUserRewardLink, markInboxItemRead } from '../services/dbService';
import { UserInboxItem, ScreenTab } from '../types';

interface InboxScreenProps {
  onNavigate: (tab: ScreenTab) => void;
}

export const InboxScreen: React.FC<InboxScreenProps> = ({ onNavigate }) => {
  const { profile } = useAuth();
  const [inboxItems, setInboxItems] = useState<UserInboxItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [clickedToast, setClickedToast] = useState<string | null>(null);

  useEffect(() => {
    if (profile?.id) {
      loadInbox();
    }
  }, [profile?.id]);

  const loadInbox = async () => {
    if (!profile?.id) return;
    try {
      setLoading(true);
      const list = await getUserInbox(profile.id);
      setInboxItems(list);
    } catch (e) {
      console.warn('Error fetching inbox:', e);
    } finally {
      setLoading(false);
    }
  };

  const handleOpenLink = async (item: UserInboxItem) => {
    if (!profile?.id) return;
    await openUserRewardLink(item.requestId, item.id, profile.id, item.affiliateUrl);
    setClickedToast(`Aapka order click track ho gaya hai! ${item.storeName} ke liye 7 Days Verification Pending shuru ho gaya hai. Aap ise History tab me dekh sakte hain.`);
    await loadInbox();
  };

  const handleCopyLink = (url: string, id: string) => {
    navigator.clipboard.writeText(url);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  return (
    <div className="space-y-6 pb-24 max-w-2xl mx-auto">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl sm:text-2xl font-extrabold text-slate-900 tracking-tight">
            My Inbox
          </h1>
          <p className="text-xs text-slate-500">
            Delivered official cashback reward links ready for shopping & cashback tracking
          </p>
        </div>
        <button
          onClick={() => onNavigate('reward-link')}
          className="px-3.5 py-1.5 rounded-xl bg-emerald-50 text-emerald-700 hover:bg-emerald-100 font-bold text-xs border border-emerald-200 transition-colors"
        >
          + Request New Link
        </button>
      </div>
      
      {/* 7-Day Order Click Notification Banner */}
      {clickedToast && (
        <div className="bg-amber-50 border border-amber-300 text-amber-950 p-4 rounded-2xl flex items-start justify-between gap-3 shadow-xs">
          <div className="flex items-start gap-2.5">
            <Clock className="w-5 h-5 text-amber-600 shrink-0 mt-0.5 animate-pulse" />
            <div>
              <h4 className="font-extrabold text-xs text-amber-950">Order Clicked • 7 Days Verification Active</h4>
              <p className="text-[11px] text-amber-900/90 mt-0.5 leading-relaxed">{clickedToast}</p>
            </div>
          </div>
          <button
            onClick={() => onNavigate('history')}
            className="px-3 py-1.5 rounded-xl bg-amber-600 hover:bg-amber-700 text-white font-black text-xs shrink-0 shadow-2xs"
          >
            Check History &rarr;
          </button>
        </div>
      )}

      {loading ? (
        <div className="text-center py-12 text-xs text-slate-400">Loading your inbox...</div>
      ) : inboxItems.length === 0 ? (
        <div className="bg-white rounded-3xl p-12 text-center border border-slate-200 shadow-xs space-y-3">
          <div className="w-14 h-14 bg-emerald-50 text-emerald-600 rounded-2xl flex items-center justify-center mx-auto">
            <Inbox className="w-7 h-7" />
          </div>
          <h3 className="text-sm font-bold text-slate-800">No Reward Links Yet</h3>
          <p className="text-xs text-slate-500 max-w-sm mx-auto leading-relaxed">
            Whenever you paste a product link into the <strong>Reward Link</strong> tab, your official cashback tracking link arrives directly here!
          </p>
          <button
            onClick={() => onNavigate('reward-link')}
            className="px-5 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs shadow-md shadow-emerald-600/20"
          >
            Create Reward Link Now
          </button>
        </div>
      ) : (
        <div className="space-y-4">
          {inboxItems.map((item) => (
            <div
              key={item.id}
              className={`bg-white rounded-3xl border transition-all overflow-hidden p-5 space-y-4 ${
                !item.isRead
                  ? 'border-emerald-300 ring-2 ring-emerald-500/10 shadow-md'
                  : 'border-slate-200 shadow-xs'
              }`}
            >
              {/* Top Meta */}
              <div className="flex items-center justify-between border-b border-slate-100 pb-3">
                <div className="flex items-center gap-2">
                  <span className="font-mono text-xs font-bold text-slate-900 bg-slate-100 px-2 py-0.5 rounded-lg">
                    {item.requestId}
                  </span>
                  <span className="text-xs font-bold text-emerald-800 bg-emerald-50 px-2 py-0.5 rounded-full border border-emerald-200">
                    {item.storeName}
                  </span>
                </div>
                <div className="text-[11px] text-slate-400 flex items-center gap-1.5">
                  <Clock className="w-3.5 h-3.5" />
                  <span>
                    {new Date(item.receivedAt).toLocaleDateString('en-IN', {
                      month: 'short',
                      day: 'numeric',
                      hour: '2-digit',
                      minute: '2-digit',
                    })}
                  </span>
                </div>
              </div>

              {/* URLs Section */}
              <div className="space-y-2.5 text-xs">
                {/* Original Product Link */}
                <div className="bg-slate-50 p-3 rounded-2xl border border-slate-100 space-y-1">
                  <span className="text-[10px] uppercase font-bold text-slate-400 block">
                    Product URL Submitted by You:
                  </span>
                  <p className="font-mono text-[11px] text-slate-600 truncate">
                    {item.productUrl}
                  </p>
                </div>

                {/* Affiliate Link Delivered by Admin */}
                <div className="bg-emerald-50/70 p-3.5 rounded-2xl border border-emerald-200/80 space-y-1.5">
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] uppercase font-bold text-emerald-800 flex items-center gap-1">
                      <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
                      <span>Verified Affiliate Reward Link (With Sub-ID Tracking)</span>
                    </span>
                    <button
                      onClick={() => handleCopyLink(item.affiliateUrl, item.id)}
                      className="text-emerald-700 hover:text-emerald-900 font-bold text-[10px] flex items-center gap-1"
                    >
                      {copiedId === item.id ? (
                        <>
                          <Check className="w-3 h-3 text-emerald-600" />
                          <span>Copied</span>
                        </>
                      ) : (
                        <>
                          <Copy className="w-3 h-3 text-emerald-600" />
                          <span>Copy Link</span>
                        </>
                      )}
                    </button>
                  </div>
                  <p className="font-mono text-[11px] text-emerald-900 truncate bg-white/70 p-2 rounded-xl border border-emerald-100">
                    {item.affiliateUrl}
                  </p>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex flex-col sm:flex-row items-center justify-between gap-3 pt-1 text-xs">
                <div className="text-[11px] text-slate-500">
                  {item.clickCount > 0 ? (
                    <span className="text-emerald-700 font-bold flex items-center gap-1">
                      <CheckCircle2 className="w-3.5 h-3.5" />
                      <span>Opened {item.clickCount} time(s) • Tracking Active</span>
                    </span>
                  ) : (
                    <span>Tap below to open store and shop with cashback.</span>
                  )}
                </div>

                <button
                  onClick={() => handleOpenLink(item)}
                  className="w-full sm:w-auto px-6 py-3 rounded-2xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 text-white font-extrabold text-xs shadow-md shadow-emerald-600/20 flex items-center justify-center gap-2 transition-all hover:scale-[1.02]"
                >
                  <span>Open Reward Link</span>
                  <ExternalLink className="w-4 h-4" />
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
