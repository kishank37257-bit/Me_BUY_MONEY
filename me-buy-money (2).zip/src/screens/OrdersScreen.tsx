import React, { useState } from 'react';
import { Transaction, OrderStatus } from '../types';
import {
  PackageCheck,
  Clock,
  CheckCircle2,
  XCircle,
  HelpCircle,
  Search,
  AlertCircle,
  ShieldAlert,
  Plus,
  X,
  FileText,
  Link2,
  Send,
  MousePointerClick,
  Banknote,
} from 'lucide-react';
import { submitMissingOrderClaim } from '../services/dbService';
import { useAuth } from '../context/AuthContext';

interface OrdersScreenProps {
  transactions: Transaction[];
  onRefresh: () => void;
}

export const OrdersScreen: React.FC<OrdersScreenProps> = ({ transactions, onRefresh }) => {
  const { profile } = useAuth();
  const [filterStatus, setFilterStatus] = useState<string>('all');
  const [showClaimModal, setShowClaimModal] = useState(false);

  // Form state for claim
  const [claimStore, setClaimStore] = useState('Amazon India');
  const [claimOrderId, setClaimOrderId] = useState('');
  const [claimAmount, setClaimAmount] = useState('');
  const [claimDate, setClaimDate] = useState(new Date().toISOString().split('T')[0]);
  const [claimSubId, setClaimSubId] = useState('');
  const [claimNotes, setClaimNotes] = useState('');
  const [submittingClaim, setSubmittingClaim] = useState(false);
  const [claimMessage, setClaimMessage] = useState<string | null>(null);

  const getStatusBadge = (status: OrderStatus) => {
    switch (status) {
      case 'Link Requested':
        return (
          <span className="inline-flex items-center gap-1 text-[11px] font-bold text-amber-700 bg-amber-50 px-2.5 py-0.5 rounded-full border border-amber-200">
            <Clock className="w-3 h-3 text-amber-600" />
            <span>Link Requested</span>
          </span>
        );
      case 'Link Sent':
        return (
          <span className="inline-flex items-center gap-1 text-[11px] font-bold text-blue-700 bg-blue-50 px-2.5 py-0.5 rounded-full border border-blue-200">
            <Send className="w-3 h-3 text-blue-600" />
            <span>Link Sent (In Inbox)</span>
          </span>
        );
      case 'Link Clicked':
        return (
          <span className="inline-flex items-center gap-1 text-[11px] font-bold text-indigo-700 bg-indigo-50 px-2.5 py-0.5 rounded-full border border-indigo-200">
            <MousePointerClick className="w-3 h-3 text-indigo-600" />
            <span>Link Clicked</span>
          </span>
        );
      case 'Purchase Tracking Pending':
        return (
          <span className="inline-flex items-center gap-1 text-[11px] font-bold text-amber-800 bg-amber-50 px-2.5 py-0.5 rounded-full border border-amber-300">
            <Clock className="w-3 h-3 text-amber-600" />
            <span>Purchase Tracking Pending</span>
          </span>
        );
      case 'Cashback Pending':
        return (
          <span className="inline-flex items-center gap-1 text-[11px] font-bold text-teal-800 bg-teal-50 px-2.5 py-0.5 rounded-full border border-teal-200">
            <Clock className="w-3 h-3 text-teal-600" />
            <span>Cashback Pending</span>
          </span>
        );
      case 'Cashback Confirmed':
        return (
          <span className="inline-flex items-center gap-1 text-[11px] font-bold text-emerald-700 bg-emerald-50 px-2.5 py-0.5 rounded-full border border-emerald-200">
            <CheckCircle2 className="w-3 h-3 text-emerald-600" />
            <span>Cashback Confirmed</span>
          </span>
        );
      case 'Cashback Rejected':
        return (
          <span className="inline-flex items-center gap-1 text-[11px] font-bold text-rose-700 bg-rose-50 px-2.5 py-0.5 rounded-full border border-rose-200">
            <XCircle className="w-3 h-3 text-rose-600" />
            <span>Cashback Rejected</span>
          </span>
        );
      case 'Cashback Paid':
        return (
          <span className="inline-flex items-center gap-1 text-[11px] font-bold text-purple-700 bg-purple-50 px-2.5 py-0.5 rounded-full border border-purple-200">
            <Banknote className="w-3 h-3 text-purple-600" />
            <span>Cashback Paid</span>
          </span>
        );
      default:
        return (
          <span className="inline-flex items-center gap-1 text-[11px] font-bold text-slate-700 bg-slate-100 px-2.5 py-0.5 rounded-full border border-slate-200">
            <span>{status}</span>
          </span>
        );
    }
  };

  const filteredTransactions = transactions.filter((t) => {
    if (filterStatus === 'all') return true;
    if (filterStatus === 'pending') {
      return (
        t.status === 'Link Requested' ||
        t.status === 'Link Sent' ||
        t.status === 'Purchase Tracking Pending' ||
        t.status === 'Cashback Pending'
      );
    }
    if (filterStatus === 'confirmed') return t.status === 'Cashback Confirmed';
    if (filterStatus === 'paid') return t.status === 'Cashback Paid';
    if (filterStatus === 'clicked') return t.status === 'Link Clicked';
    if (filterStatus === 'rejected') return t.status === 'Cashback Rejected';
    return t.status === filterStatus;
  });

  const handleClaimSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!profile) return;
    if (!claimOrderId || !claimAmount) {
      alert('Please fill in Order ID and Order Amount');
      return;
    }

    try {
      setSubmittingClaim(true);
      await submitMissingOrderClaim(
        profile.id,
        profile.email,
        claimStore,
        'net_custom',
        claimOrderId,
        parseFloat(claimAmount),
        claimDate,
        claimSubId,
        claimNotes
      );
      setClaimMessage('Missing cashback claim submitted! It is now visible as Purchase Tracking Pending.');
      setTimeout(() => {
        setShowClaimModal(false);
        setClaimMessage(null);
        setClaimOrderId('');
        setClaimAmount('');
        onRefresh();
      }, 1500);
    } catch (err: any) {
      alert('Error submitting claim: ' + err.message);
    } finally {
      setSubmittingClaim(false);
    }
  };

  return (
    <div className="space-y-6 pb-24 max-w-4xl mx-auto">
      {/* Top Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h1 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight">
            My Orders & Tracking
          </h1>
          <p className="text-xs text-slate-500">
            Track affiliate order detection, validation stages, and confirmed cashback payouts
          </p>
        </div>

        <button
          onClick={() => setShowClaimModal(true)}
          className="inline-flex items-center gap-1.5 px-4 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-2xl text-xs font-extrabold shadow-sm transition-colors self-start sm:self-auto"
        >
          <Plus className="w-4 h-4" />
          <span>Claim Missing Cashback</span>
        </button>
      </div>

      {/* Verification Notice */}
      <div className="bg-amber-50 border border-amber-200/80 rounded-3xl p-4 sm:p-5 text-xs text-amber-900 flex items-start gap-3">
        <ShieldAlert className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
        <div className="space-y-1">
          <strong className="font-bold text-amber-900">Affiliate Attribution & Verification Policy:</strong>
          <p className="text-amber-800 leading-relaxed text-[11px]">
            Merely clicking a link or submitting an order ID does not mark cashback as confirmed. Retailers reconcile actual dispatched purchases against our tracking sub-IDs upon expiry of the return window (typically 60-90 days). Once confirmed by the merchant feed, your 40% share is instantly credited to your Available Balance!
          </p>
        </div>
      </div>

      {/* Status Filter Tabs */}
      <div className="flex gap-2 overflow-x-auto pb-1 text-xs scrollbar-none">
        <button
          onClick={() => setFilterStatus('all')}
          className={`px-3.5 py-2 rounded-xl font-bold whitespace-nowrap shrink-0 transition-colors ${
            filterStatus === 'all'
              ? 'bg-slate-900 text-white'
              : 'bg-white text-slate-600 border border-slate-200 hover:bg-slate-50'
          }`}
        >
          All Orders ({transactions.length})
        </button>
        <button
          onClick={() => setFilterStatus('pending')}
          className={`px-3.5 py-2 rounded-xl font-bold whitespace-nowrap shrink-0 transition-colors ${
            filterStatus === 'pending'
              ? 'bg-amber-600 text-white'
              : 'bg-white text-slate-600 border border-slate-200 hover:bg-slate-50'
          }`}
        >
          Pending
        </button>
        <button
          onClick={() => setFilterStatus('confirmed')}
          className={`px-3.5 py-2 rounded-xl font-bold whitespace-nowrap shrink-0 transition-colors ${
            filterStatus === 'confirmed'
              ? 'bg-emerald-600 text-white'
              : 'bg-white text-slate-600 border border-slate-200 hover:bg-slate-50'
          }`}
        >
          Confirmed
        </button>
        <button
          onClick={() => setFilterStatus('paid')}
          className={`px-3.5 py-2 rounded-xl font-bold whitespace-nowrap shrink-0 transition-colors ${
            filterStatus === 'paid'
              ? 'bg-purple-600 text-white'
              : 'bg-white text-slate-600 border border-slate-200 hover:bg-slate-50'
          }`}
        >
          Cashback Paid
        </button>
        <button
          onClick={() => setFilterStatus('clicked')}
          className={`px-3.5 py-2 rounded-xl font-bold whitespace-nowrap shrink-0 transition-colors ${
            filterStatus === 'clicked'
              ? 'bg-indigo-600 text-white'
              : 'bg-white text-slate-600 border border-slate-200 hover:bg-slate-50'
          }`}
        >
          Clicks Logged
        </button>
        <button
          onClick={() => setFilterStatus('rejected')}
          className={`px-3.5 py-2 rounded-xl font-bold whitespace-nowrap shrink-0 transition-colors ${
            filterStatus === 'rejected'
              ? 'bg-rose-600 text-white'
              : 'bg-white text-slate-600 border border-slate-200 hover:bg-slate-50'
          }`}
        >
          Rejected
        </button>
      </div>

      {/* Orders List */}
      {filteredTransactions.length === 0 ? (
        <div className="bg-white rounded-3xl p-12 text-center border border-slate-200 shadow-xs space-y-3">
          <div className="w-12 h-12 bg-slate-100 rounded-full flex items-center justify-center mx-auto text-slate-400">
            <PackageCheck className="w-6 h-6" />
          </div>
          <h3 className="text-sm font-bold text-slate-800">No orders in this view</h3>
          <p className="text-xs text-slate-500 max-w-sm mx-auto">
            When you request a Reward Link, click from your Inbox, or shop a Deal, transactions appear here automatically!
          </p>
        </div>
      ) : (
        <div className="space-y-3">
          {filteredTransactions.map((txn) => (
            <div
              key={txn.id}
              className="bg-white rounded-3xl border border-slate-200/90 p-4 sm:p-5 shadow-xs space-y-3 hover:border-slate-300 transition-colors"
            >
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-100 pb-3">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-2xl bg-emerald-50 text-emerald-700 flex items-center justify-center font-black text-xs shrink-0 border border-emerald-100">
                    {txn.storeName.substring(0, 2).toUpperCase()}
                  </div>
                  <div>
                    <h3 className="text-sm font-extrabold text-slate-900">{txn.productTitle}</h3>
                    <div className="flex items-center gap-2 text-[11px] text-slate-500">
                      <span>Store: <strong>{txn.storeName}</strong></span>
                      <span>•</span>
                      <span>{new Date(txn.createdAt).toLocaleDateString('en-IN', { month: 'short', day: 'numeric', year: 'numeric' })}</span>
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-2 self-start sm:self-auto">
                  {getStatusBadge(txn.status)}
                </div>
              </div>

              {/* Data Grid */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs bg-slate-50/70 p-3.5 rounded-2xl border border-slate-100">
                <div>
                  <span className="block text-[10px] text-slate-400 uppercase font-bold">
                    Order Amount
                  </span>
                  <span className="font-bold text-slate-800">
                    {txn.orderAmount ? `₹${txn.orderAmount.toLocaleString('en-IN')}` : '--'}
                  </span>
                </div>
                <div>
                  <span className="block text-[10px] text-slate-400 uppercase font-bold">
                    Tracking Sub-ID
                  </span>
                  <code className="text-[11px] font-mono font-semibold text-emerald-800 bg-emerald-50 px-1 py-0.5 rounded">
                    {txn.trackingSubId || 'ANS_PENDING'}
                  </code>
                </div>
                <div>
                  <span className="block text-[10px] text-slate-400 uppercase font-bold">
                    Your Share (40%)
                  </span>
                  <span className="font-black text-emerald-600">
                    {txn.userCashbackAmount ? `₹${txn.userCashbackAmount.toLocaleString('en-IN')}` : 'Calculating...'}
                  </span>
                </div>
                <div>
                  <span className="block text-[10px] text-slate-400 uppercase font-bold">
                    Network Ref
                  </span>
                  <span className="text-slate-600 font-mono text-[11px] truncate block">
                    {txn.networkOrderId || 'Pending Match'}
                  </span>
                </div>
              </div>

              {/* Status explanation note */}
              {txn.notes && (
                <p className="text-[11px] text-slate-500 italic bg-slate-50 p-2.5 rounded-xl">
                  Note: {txn.notes}
                </p>
              )}
              {txn.rejectionReason && (
                <div className="bg-rose-50 border border-rose-200 p-3 rounded-2xl text-xs text-rose-800">
                  <strong>Rejection Reason:</strong> {txn.rejectionReason}
                </div>
              )}
            </div>
          ))}
        </div>
      )}

      {/* Claim Modal */}
      {showClaimModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="bg-white w-full max-w-lg rounded-3xl shadow-2xl border border-slate-100 overflow-hidden animate-in zoom-in-95">
            <div className="bg-slate-900 text-white p-5 flex items-center justify-between">
              <div>
                <h3 className="text-base font-bold">Claim Missing Cashback</h3>
                <p className="text-xs text-slate-400">
                  Did your purchase not track automatically within 48 hours?
                </p>
              </div>
              <button
                onClick={() => setShowClaimModal(false)}
                className="p-1 rounded-full text-slate-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleClaimSubmit} className="p-5 space-y-4 text-xs">
              {claimMessage && (
                <div className="bg-emerald-50 border border-emerald-200 text-emerald-800 p-3 rounded-2xl font-medium">
                  {claimMessage}
                </div>
              )}

              <div className="space-y-1">
                <label className="font-bold text-slate-700">Retailer / Store Name</label>
                <select
                  value={claimStore}
                  onChange={(e) => setClaimStore(e.target.value)}
                  className="w-full p-3 bg-slate-50 border border-slate-200 rounded-2xl font-medium text-slate-800 outline-none focus:ring-1 focus:ring-emerald-500"
                >
                  <option value="Amazon India">Amazon India</option>
                  <option value="Flipkart">Flipkart</option>
                  <option value="Myntra">Myntra</option>
                  <option value="Ajio">Ajio</option>
                  <option value="Nykaa">Nykaa</option>
                  <option value="Mamaearth">Mamaearth</option>
                  <option value="MakeMyTrip">MakeMyTrip</option>
                  <option value="Other Store">Other Store</option>
                </select>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="font-bold text-slate-700">Merchant Order ID *</label>
                  <input
                    type="text"
                    required
                    value={claimOrderId}
                    onChange={(e) => setClaimOrderId(e.target.value)}
                    placeholder="e.g. 402-1234567-890"
                    className="w-full p-3 bg-slate-50 border border-slate-200 rounded-2xl font-medium text-slate-800 outline-none focus:ring-1 focus:ring-emerald-500"
                  />
                </div>

                <div className="space-y-1">
                  <label className="font-bold text-slate-700">Order Amount (₹) *</label>
                  <input
                    type="number"
                    step="0.01"
                    required
                    value={claimAmount}
                    onChange={(e) => setClaimAmount(e.target.value)}
                    placeholder="e.g. 1499"
                    className="w-full p-3 bg-slate-50 border border-slate-200 rounded-2xl font-medium text-slate-800 outline-none focus:ring-1 focus:ring-emerald-500"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="font-bold text-slate-700">Date of Purchase</label>
                  <input
                    type="date"
                    value={claimDate}
                    onChange={(e) => setClaimDate(e.target.value)}
                    className="w-full p-3 bg-slate-50 border border-slate-200 rounded-2xl font-medium text-slate-800 outline-none focus:ring-1 focus:ring-emerald-500"
                  />
                </div>

                <div className="space-y-1">
                  <label className="font-bold text-slate-700">Tracking Sub-ID (Optional)</label>
                  <input
                    type="text"
                    value={claimSubId}
                    onChange={(e) => setClaimSubId(e.target.value)}
                    placeholder="e.g. ANS_..."
                    className="w-full p-3 bg-slate-50 border border-slate-200 rounded-2xl font-medium text-slate-800 outline-none focus:ring-1 focus:ring-emerald-500 font-mono text-[11px]"
                  />
                </div>
              </div>

              <div className="space-y-1">
                <label className="font-bold text-slate-700">Additional Details / Product Name</label>
                <textarea
                  rows={2}
                  value={claimNotes}
                  onChange={(e) => setClaimNotes(e.target.value)}
                  placeholder="Items bought, coupon code used, or invoice details..."
                  className="w-full p-3 bg-slate-50 border border-slate-200 rounded-2xl font-medium text-slate-800 outline-none focus:ring-1 focus:ring-emerald-500"
                />
              </div>

              <div className="pt-2 flex gap-2">
                <button
                  type="button"
                  onClick={() => setShowClaimModal(false)}
                  className="flex-1 py-3 px-4 rounded-2xl border border-slate-200 text-slate-700 font-semibold hover:bg-slate-50"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={submittingClaim}
                  className="flex-2 py-3 px-4 rounded-2xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold shadow-md shadow-emerald-500/20 disabled:opacity-50"
                >
                  {submittingClaim ? 'Submitting Claim...' : 'Submit Claim'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
