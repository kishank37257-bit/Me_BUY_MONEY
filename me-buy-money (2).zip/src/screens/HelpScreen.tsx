import React, { useState } from 'react';
import { HelpCircle, ChevronDown, ChevronUp, Mail, ShieldCheck, Plus, CheckCircle2 } from 'lucide-react';
import { ScreenTab } from '../types';

interface HelpScreenProps {
  onNavigate: (tab: ScreenTab) => void;
}

export const HelpScreen: React.FC<HelpScreenProps> = ({ onNavigate }) => {
  const [openFaq, setOpenFaq] = useState<number | null>(0);

  const faqs = [
    {
      q: 'How does Me BUY MONEY pay real cashback directly to my bank account?',
      a: 'When you click from Me BUY MONEY to a partner store (like Amazon, Flipkart, Myntra, or Ajio) and make a purchase, the merchant pays us an affiliate advertising commission. Instead of pocketing all of it like other websites, we pass 40% of this commission directly back to you as real money!',
    },
    {
      q: 'Why does cashback take 60 to 90 days to change from Pending to Confirmed?',
      a: 'Retailers have a 15-30 day return and exchange window. Once that return window expires and the store confirms that the product was neither returned nor canceled, they remit the affiliate payment to us. Once received, your cashback is automatically moved to Available Balance.',
    },
    {
      q: 'What is the 40% User vs 60% Platform revenue split?',
      a: 'If a merchant pays a confirmed affiliate fee of ₹100 for your order, ₹40 is directly credited to your wallet for withdrawal. The remaining ₹60 supports server hosting, affiliate tracking technology, banking transfer costs, and statutory taxes.',
    },
    {
      q: 'What should I do if my purchase did not track within 48 hours?',
      a: 'You can submit a Missing Cashback Claim from the "My Orders" screen. Enter your retailer name, order ID, amount, and date. Our administration team will manually reconcile the transaction with the network report.',
    },
    {
      q: 'How can I withdraw my cashback money?',
      a: 'Once your available balance reaches ₹250, go to "My Wallet" and tap "Withdraw Money". You can transfer directly to your UPI ID (GPay, PhonePe, Paytm) or enter your Bank Account details. Payouts are processed within 1-3 business days.',
    },
    {
      q: 'Are there any hidden charges or fees for withdrawal?',
      a: 'Zero! There are no withdrawal fees, joining fees, or monthly subscription charges. 100% of your confirmed available balance goes to your bank.',
    },
  ];

  return (
    <div className="space-y-6 pb-20 max-w-3xl mx-auto">
      <div>
        <h1 className="text-xl sm:text-2xl font-extrabold text-slate-900 tracking-tight">
          Help & Support Center
        </h1>
        <p className="text-xs text-slate-500">
          Everything you need to know about cashback tracking, payouts, and store policies
        </p>
      </div>

      {/* Quick Action: Missing claim */}
      <div className="bg-gradient-to-r from-emerald-600 to-teal-700 text-white rounded-3xl p-6 shadow-md flex flex-col sm:flex-row items-center justify-between gap-4">
        <div className="space-y-1 text-center sm:text-left">
          <h3 className="text-base font-bold">Did your order not track?</h3>
          <p className="text-xs text-emerald-100 max-w-md">
            If it has been more than 48 hours since your purchase, submit an order claim and our team will reconcile it!
          </p>
        </div>
        <button
          onClick={() => onNavigate('orders')}
          className="px-5 py-2.5 rounded-xl bg-white text-emerald-900 hover:bg-emerald-50 text-xs font-bold shadow-md shrink-0 flex items-center gap-1.5 transition-colors"
        >
          <Plus className="w-4 h-4" />
          <span>Claim Missing Cashback</span>
        </button>
      </div>

      {/* FAQs */}
      <div className="bg-white rounded-3xl border border-slate-200/90 shadow-sm p-6 space-y-4">
        <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
          <HelpCircle className="w-4 h-4 text-emerald-600" />
          <span>Frequently Asked Questions</span>
        </h3>

        <div className="divide-y divide-slate-100">
          {faqs.map((faq, idx) => {
            const isOpen = openFaq === idx;
            return (
              <div key={idx} className="py-3.5">
                <button
                  onClick={() => setOpenFaq(isOpen ? null : idx)}
                  className="w-full flex items-center justify-between text-left text-xs font-bold text-slate-900 hover:text-emerald-700 transition-colors gap-3"
                >
                  <span>{faq.q}</span>
                  {isOpen ? (
                    <ChevronUp className="w-4 h-4 text-slate-400 shrink-0" />
                  ) : (
                    <ChevronDown className="w-4 h-4 text-slate-400 shrink-0" />
                  )}
                </button>
                {isOpen && (
                  <p className="mt-2 text-xs text-slate-600 leading-relaxed animate-in fade-in duration-150">
                    {faq.a}
                  </p>
                )}
              </div>
            );
          })}
        </div>
      </div>

      {/* Contact Card */}
      <div className="bg-slate-50 border border-slate-200/80 rounded-3xl p-6 text-center space-y-2">
        <Mail className="w-6 h-6 text-emerald-600 mx-auto" />
        <h4 className="text-xs font-bold text-slate-900">Still have questions?</h4>
        <p className="text-xs text-slate-500">
          Our friendly support team responds within 24 business hours.
        </p>
        <div className="pt-1">
          <a
            href="mailto:support@mebuymoney.com"
            className="text-xs font-bold text-emerald-600 hover:underline"
          >
            support@mebuymoney.com
          </a>
        </div>
      </div>
    </div>
  );
};
