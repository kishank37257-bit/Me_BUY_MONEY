import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import {
  Share2,
  Copy,
  Check,
  Gift,
  Users,
  Award,
  ShieldAlert,
  ArrowRight,
  Sparkles,
} from 'lucide-react';
import { getUserReferrals } from '../services/dbService';
import { Referral } from '../types';

export const ReferralScreen: React.FC = () => {
  const { profile } = useAuth();
  const [copiedCode, setCopiedCode] = useState(false);
  const [copiedLink, setCopiedLink] = useState(false);
  const [referrals, setReferrals] = useState<Referral[]>([]);
  const [loading, setLoading] = useState(true);

  const referralCode = profile?.referralCode || 'MBMUSER99';
  const shareUrl = `${window.location.origin}?ref=${referralCode}`;

  useEffect(() => {
    if (profile?.id) {
      getUserReferrals(profile.id)
        .then((list) => setReferrals(list || []))
        .catch(console.error)
        .finally(() => setLoading(false));
    }
  }, [profile?.id]);

  const copyCode = () => {
    navigator.clipboard.writeText(referralCode);
    setCopiedCode(true);
    setTimeout(() => setCopiedCode(false), 2000);
  };

  const copyLink = () => {
    navigator.clipboard.writeText(shareUrl);
    setCopiedLink(true);
    setTimeout(() => setCopiedLink(false), 2000);
  };

  const shareOnWhatsApp = () => {
    const text = encodeURIComponent(
      `Hey! I use Me BUY MONEY to get up to 8% real cashback into my bank account every time I shop on Amazon, Flipkart, Myntra, or Ajio!\n\nSign up with my code *${referralCode}* to get ₹50 bonus on your first order:\n${shareUrl}`
    );
    window.open(`https://api.whatsapp.com/send?text=${text}`, '_blank');
  };

  const qualifiedReferrals = referrals.filter(
    (r) => r.status === 'qualifying_order_completed' || r.status === 'rewarded'
  );
  const totalEarned = referrals
    .filter((r) => r.isPaid)
    .reduce((acc, r) => acc + (r.rewardAmount || 0), 0);

  return (
    <div className="space-y-6 pb-20 max-w-3xl mx-auto">
      {/* Hero Banner */}
      <div className="bg-gradient-to-r from-purple-700 via-indigo-700 to-slate-900 text-white rounded-3xl p-6 sm:p-8 shadow-xl space-y-4">
        <div className="flex items-center gap-2">
          <Gift className="w-5 h-5 text-purple-300" />
          <span className="text-xs font-bold uppercase tracking-wider text-purple-200">
            Referral Program
          </span>
        </div>
        <h1 className="text-2xl sm:text-3xl font-black">
          Invite Friends & Earn ₹50 Bonus Each!
        </h1>
        <p className="text-xs sm:text-sm text-purple-100 max-w-lg leading-relaxed">
          Share your love for savings. When a friend joins with your code and places their first qualifying purchase of ₹500+, both of you receive ₹50 cashback directly!
        </p>
      </div>

      {/* Code & Share Card */}
      <div className="bg-white rounded-3xl p-6 border border-slate-200/90 shadow-sm space-y-4">
        <h3 className="text-sm font-bold text-slate-900">Your Unique Referral Code</h3>

        <div className="flex flex-col sm:flex-row gap-3">
          <div className="flex-1 bg-slate-50 border border-slate-200 rounded-2xl p-3 flex items-center justify-between">
            <div>
              <span className="block text-[10px] uppercase font-bold text-slate-400">Referral Code</span>
              <span className="text-lg font-mono font-black text-slate-900 tracking-wider">
                {referralCode}
              </span>
            </div>
            <button
              onClick={copyCode}
              className="p-2.5 rounded-xl bg-white border border-slate-200 hover:bg-slate-100 text-slate-700 font-bold text-xs flex items-center gap-1.5 transition-colors"
            >
              {copiedCode ? <Check className="w-4 h-4 text-emerald-600" /> : <Copy className="w-4 h-4" />}
              <span>{copiedCode ? 'Copied' : 'Copy'}</span>
            </button>
          </div>

          <button
            onClick={shareOnWhatsApp}
            className="px-6 py-3 rounded-2xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold shadow-md shadow-emerald-500/20 flex items-center justify-center gap-2 transition-all hover:scale-102"
          >
            <Share2 className="w-4 h-4" />
            <span>Share via WhatsApp</span>
          </button>
        </div>

        {/* Share link */}
        <div className="flex items-center gap-2 bg-slate-50 p-2.5 rounded-xl border border-slate-200 text-xs">
          <span className="text-slate-400 truncate flex-1 font-mono text-[11px]">{shareUrl}</span>
          <button
            onClick={copyLink}
            className="text-emerald-600 font-bold hover:underline shrink-0 text-xs"
          >
            {copiedLink ? 'Copied Link!' : 'Copy Link'}
          </button>
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-3 gap-3">
        <div className="bg-white p-4 rounded-2xl border border-slate-200/90 text-center space-y-1">
          <Users className="w-5 h-5 text-indigo-600 mx-auto" />
          <div className="text-xl font-black text-slate-900">{referrals.length}</div>
          <p className="text-[10px] text-slate-500 uppercase font-bold">Friends Invited</p>
        </div>

        <div className="bg-white p-4 rounded-2xl border border-slate-200/90 text-center space-y-1">
          <Award className="w-5 h-5 text-emerald-600 mx-auto" />
          <div className="text-xl font-black text-emerald-600">{qualifiedReferrals.length}</div>
          <p className="text-[10px] text-slate-500 uppercase font-bold">Qualified Orders</p>
        </div>

        <div className="bg-white p-4 rounded-2xl border border-slate-200/90 text-center space-y-1">
          <Gift className="w-5 h-5 text-purple-600 mx-auto" />
          <div className="text-xl font-black text-purple-600">₹{totalEarned}</div>
          <p className="text-[10px] text-slate-500 uppercase font-bold">Bonus Earned</p>
        </div>
      </div>

      {/* Terms & Fraud Protection */}
      <div className="bg-slate-50 rounded-2xl p-5 border border-slate-200 text-xs text-slate-600 space-y-2">
        <div className="flex items-center gap-2 font-bold text-slate-800">
          <ShieldAlert className="w-4 h-4 text-emerald-600" />
          <span>Referral Rules & Anti-Fraud Policy</span>
        </div>
        <ul className="list-disc pl-5 space-y-1 text-[11px] text-slate-600">
          <li>Referred friend must register using your code and place an eligible order of ₹500 or more.</li>
          <li>Bonus is released into Available Balance once the merchant confirms the purchase.</li>
          <li>Self-referrals, fake email addresses, or multiple accounts from the same device/IP are blocked by automated fraud checks.</li>
          <li>Maximum referral rewards limit: 50 friends per calendar year per user.</li>
        </ul>
      </div>

      {/* Referral History */}
      <div className="space-y-3">
        <h3 className="text-sm font-bold text-slate-900">Your Invited Friends</h3>
        {loading ? (
          <div className="text-center py-6 text-xs text-slate-400">Loading referral history...</div>
        ) : referrals.length === 0 ? (
          <div className="bg-white rounded-2xl p-6 text-center border border-slate-200 text-xs text-slate-400">
            You haven't invited any friends yet. Share your code above to get started!
          </div>
        ) : (
          <div className="space-y-2">
            {referrals.map((ref) => (
              <div
                key={ref.id}
                className="bg-white p-3.5 rounded-2xl border border-slate-200/80 flex items-center justify-between text-xs"
              >
                <div>
                  <span className="font-bold text-slate-800">{ref.referredEmail}</span>
                  <span className="block text-[10px] text-slate-400">
                    Joined on {new Date(ref.createdAt).toLocaleDateString('en-IN')}
                  </span>
                </div>
                <div className="text-right">
                  <span
                    className={`inline-block text-[10px] font-bold px-2 py-0.5 rounded-full ${
                      ref.status === 'rewarded'
                        ? 'bg-emerald-50 text-emerald-700'
                        : ref.status === 'qualifying_order_completed'
                        ? 'bg-blue-50 text-blue-700'
                        : 'bg-slate-100 text-slate-600'
                    }`}
                  >
                    {ref.status === 'rewarded'
                      ? 'Rewarded (₹50)'
                      : ref.status === 'qualifying_order_completed'
                      ? 'Order Verified'
                      : 'Registered'}
                  </span>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
