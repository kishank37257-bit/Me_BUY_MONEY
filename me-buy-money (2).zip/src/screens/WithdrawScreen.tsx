import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import {
  ArrowUpRight,
  CreditCard,
  QrCode,
  ShieldCheck,
  CheckCircle2,
  Clock,
  XCircle,
  AlertCircle,
  FileCheck,
} from 'lucide-react';
import {
  requestWithdrawal,
  getUserWithdrawals,
  getPlatformSettings,
} from '../services/dbService';
import { WithdrawalRequest, PayoutMethod } from '../types';

export const WithdrawScreen: React.FC = () => {
  const { profile, wallet, refreshWallet } = useAuth();
  const [minAmount, setMinAmount] = useState<number>(250);
  const [withdrawals, setWithdrawals] = useState<WithdrawalRequest[]>([]);
  const [loadingHistory, setLoadingHistory] = useState(true);

  // Form
  const [amount, setAmount] = useState<string>('250');
  const [method, setMethod] = useState<PayoutMethod>('UPI');
  const [upiId, setUpiId] = useState<string>(profile?.upiId || '');
  const [accountHolder, setAccountHolder] = useState<string>(profile?.displayName || '');
  const [accountNumber, setAccountNumber] = useState<string>('');
  const [ifscCode, setIfscCode] = useState<string>('');
  const [bankName, setBankName] = useState<string>('');

  const [submitting, setSubmitting] = useState(false);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  const availableBalance = wallet?.availableBalance ?? 0;

  useEffect(() => {
    getPlatformSettings()
      .then((s) => setMinAmount(s.minWithdrawalAmount))
      .catch(() => setMinAmount(250));

    if (profile?.id) {
      loadHistory();
    }
  }, [profile?.id]);

  const loadHistory = async () => {
    if (!profile?.id) return;
    try {
      setLoadingHistory(true);
      const list = await getUserWithdrawals(profile.id);
      setWithdrawals(list);
    } catch (e) {
      console.error('Error fetching withdrawal history:', e);
    } finally {
      setLoadingHistory(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);
    setSuccessMessage(null);

    if (!profile) return;
    const numAmount = parseFloat(amount);

    if (isNaN(numAmount) || numAmount <= 0) {
      setErrorMessage('Please enter a valid withdrawal amount.');
      return;
    }

    if (numAmount < minAmount) {
      setErrorMessage(`Minimum withdrawal amount is ₹${minAmount}.`);
      return;
    }

    if (numAmount > availableBalance) {
      setErrorMessage(
        `Insufficient available balance. You only have ₹${availableBalance.toFixed(2)}.`
      );
      return;
    }

    if (method === 'UPI' && (!upiId || !upiId.includes('@'))) {
      setErrorMessage('Please provide a valid UPI ID (e.g., yourname@okaxis).');
      return;
    }

    if (method === 'BANK' && (!accountNumber || !ifscCode || !accountHolder)) {
      setErrorMessage('Please fill in complete Bank Account details (Name, Account No, IFSC).');
      return;
    }

    try {
      setSubmitting(true);
      const payoutDetails =
        method === 'UPI'
          ? { upiId }
          : { accountHolder, accountNumber, ifscCode, bankName };

      await requestWithdrawal(
        profile.id,
        profile.email,
        numAmount,
        method,
        payoutDetails
      );

      setSuccessMessage(
        `Withdrawal of ₹${numAmount} successfully requested! Funds are reserved and will be transferred to your ${method}.`
      );
      await refreshWallet();
      await loadHistory();
    } catch (err: any) {
      setErrorMessage(err.message || 'Withdrawal request failed.');
    } finally {
      setSubmitting(false);
    }
  };

  const getStatusBadge = (status: WithdrawalRequest['status']) => {
    switch (status) {
      case 'Pending':
        return (
          <span className="inline-flex items-center gap-1 text-[11px] font-bold text-amber-700 bg-amber-50 px-2 py-0.5 rounded-full border border-amber-200">
            <Clock className="w-3 h-3 text-amber-600" />
            <span>Pending Review</span>
          </span>
        );
      case 'Processing':
        return (
          <span className="inline-flex items-center gap-1 text-[11px] font-bold text-blue-700 bg-blue-50 px-2 py-0.5 rounded-full border border-blue-200">
            <Clock className="w-3 h-3 text-blue-600" />
            <span>Processing Payout</span>
          </span>
        );
      case 'Paid':
        return (
          <span className="inline-flex items-center gap-1 text-[11px] font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-full border border-emerald-200">
            <CheckCircle2 className="w-3 h-3 text-emerald-600" />
            <span>Paid (Completed)</span>
          </span>
        );
      case 'Rejected':
        return (
          <span className="inline-flex items-center gap-1 text-[11px] font-bold text-rose-700 bg-rose-50 px-2 py-0.5 rounded-full border border-rose-200">
            <XCircle className="w-3 h-3 text-rose-600" />
            <span>Rejected (Refunded)</span>
          </span>
        );
      default:
        return null;
    }
  };

  return (
    <div className="space-y-6 pb-20 max-w-3xl mx-auto">
      <div>
        <h1 className="text-xl sm:text-2xl font-extrabold text-slate-900 tracking-tight">
          Withdraw Cashback Money
        </h1>
        <p className="text-xs text-slate-500">
          Transfer your confirmed cashback balance directly to your bank account or UPI ID
        </p>
      </div>

      {/* Available Balance Box */}
      <div className="bg-gradient-to-r from-emerald-600 to-teal-700 text-white p-6 rounded-2xl shadow-md flex items-center justify-between">
        <div>
          <span className="text-emerald-200 text-xs font-bold uppercase tracking-wider">
            Available Balance
          </span>
          <div className="text-2xl sm:text-3xl font-black mt-0.5">
            ₹{availableBalance.toLocaleString('en-IN', { minimumFractionDigits: 2 })}
          </div>
        </div>
        <div className="text-right text-xs text-emerald-100">
          <span className="block font-semibold">Min. Withdrawal</span>
          <span className="font-bold text-white text-sm">₹{minAmount}</span>
        </div>
      </div>

      {/* Form */}
      <div className="bg-white rounded-3xl p-6 border border-slate-200/90 shadow-sm space-y-5">
        <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
          <CreditCard className="w-4 h-4 text-emerald-600" />
          <span>Select Payout Method & Amount</span>
        </h3>

        {errorMessage && (
          <div className="bg-rose-50 border border-rose-200 text-rose-800 text-xs p-3 rounded-xl flex items-center gap-2">
            <AlertCircle className="w-4 h-4 shrink-0 text-rose-600" />
            <span>{errorMessage}</span>
          </div>
        )}

        {successMessage && (
          <div className="bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs p-3.5 rounded-xl flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-600" />
            <span>{successMessage}</span>
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4 text-xs">
          {/* Method selector */}
          <div className="grid grid-cols-2 gap-3">
            <button
              type="button"
              onClick={() => setMethod('UPI')}
              className={`p-4 rounded-2xl border text-left flex items-center gap-3 transition-all ${
                method === 'UPI'
                  ? 'border-emerald-600 bg-emerald-50/50 ring-1 ring-emerald-600 text-emerald-950 font-bold'
                  : 'border-slate-200 hover:border-slate-300 text-slate-700'
              }`}
            >
              <div className="w-10 h-10 rounded-xl bg-white border border-slate-200 flex items-center justify-center text-emerald-600 font-bold text-sm">
                UPI
              </div>
              <div>
                <span className="block text-xs font-bold">UPI Transfer</span>
                <span className="text-[10px] text-slate-500">GPay, PhonePe, Paytm</span>
              </div>
            </button>

            <button
              type="button"
              onClick={() => setMethod('BANK')}
              className={`p-4 rounded-2xl border text-left flex items-center gap-3 transition-all ${
                method === 'BANK'
                  ? 'border-emerald-600 bg-emerald-50/50 ring-1 ring-emerald-600 text-emerald-950 font-bold'
                  : 'border-slate-200 hover:border-slate-300 text-slate-700'
              }`}
            >
              <div className="w-10 h-10 rounded-xl bg-white border border-slate-200 flex items-center justify-center text-emerald-600 font-bold text-sm">
                <CreditCard className="w-5 h-5" />
              </div>
              <div>
                <span className="block text-xs font-bold">Bank Account</span>
                <span className="text-[10px] text-slate-500">NEFT / IMPS Transfer</span>
              </div>
            </button>
          </div>

          {/* Amount Input */}
          <div className="space-y-1.5">
            <div className="flex justify-between font-bold text-slate-700">
              <label>Withdrawal Amount (₹)</label>
              <button
                type="button"
                onClick={() => setAmount(availableBalance.toString())}
                className="text-emerald-600 hover:underline text-[11px]"
              >
                Withdraw Full Balance (₹{availableBalance.toFixed(2)})
              </button>
            </div>
            <input
              type="number"
              step="1"
              required
              min={minAmount}
              max={availableBalance}
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              className="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl text-sm font-bold text-slate-900 outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500"
              placeholder={`Min. ₹${minAmount}`}
            />
          </div>

          {/* Method Specific Details */}
          {method === 'UPI' ? (
            <div className="space-y-1.5">
              <label className="font-bold text-slate-700">UPI ID / VPA *</label>
              <input
                type="text"
                required
                value={upiId}
                onChange={(e) => setUpiId(e.target.value)}
                placeholder="yourname@okaxis / 9876543210@paytm"
                className="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl font-medium text-slate-900 outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500"
              />
              <span className="text-[10px] text-slate-400">
                Ensure your UPI ID is linked to your active bank account.
              </span>
            </div>
          ) : (
            <div className="space-y-3">
              <div className="space-y-1">
                <label className="font-bold text-slate-700">Account Holder Name *</label>
                <input
                  type="text"
                  required
                  value={accountHolder}
                  onChange={(e) => setAccountHolder(e.target.value)}
                  placeholder="As per bank passbook"
                  className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl font-medium text-slate-900 outline-none focus:ring-1 focus:ring-emerald-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="font-bold text-slate-700">Bank Account Number *</label>
                  <input
                    type="password"
                    required
                    value={accountNumber}
                    onChange={(e) => setAccountNumber(e.target.value)}
                    placeholder="Account Number"
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl font-medium text-slate-900 outline-none focus:ring-1 focus:ring-emerald-500 font-mono"
                  />
                </div>
                <div className="space-y-1">
                  <label className="font-bold text-slate-700">IFSC Code *</label>
                  <input
                    type="text"
                    required
                    value={ifscCode}
                    onChange={(e) => setIfscCode(e.target.value.toUpperCase())}
                    placeholder="e.g. HDFC0001234"
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl font-medium text-slate-900 outline-none focus:ring-1 focus:ring-emerald-500 uppercase font-mono"
                  />
                </div>
              </div>

              <div className="space-y-1">
                <label className="font-bold text-slate-700">Bank Name (Optional)</label>
                <input
                  type="text"
                  value={bankName}
                  onChange={(e) => setBankName(e.target.value)}
                  placeholder="e.g. HDFC Bank, SBI, ICICI"
                  className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl font-medium text-slate-900 outline-none focus:ring-1 focus:ring-emerald-500"
                />
              </div>
            </div>
          )}

          {/* Guidelines */}
          <div className="p-3 rounded-xl bg-slate-50 text-[11px] text-slate-500 space-y-1 border border-slate-200/60">
            <div className="flex items-center gap-1.5 font-bold text-slate-700">
              <ShieldCheck className="w-4 h-4 text-emerald-600" />
              <span>Security & Payout Rules</span>
            </div>
            <p>
              • The requested amount is instantly reserved from your available balance to prevent duplicate withdrawals.
            </p>
            <p>
              • Payouts are verified and processed directly to your UPI/Bank within 1-3 business days. Payment reference (UTR) is posted upon transfer.
            </p>
          </div>

          <button
            type="submit"
            disabled={submitting || availableBalance < minAmount}
            className="w-full py-3.5 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs shadow-md shadow-emerald-500/20 disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2 transition-all"
          >
            <ArrowUpRight className="w-4 h-4" />
            <span>{submitting ? 'Submitting Request...' : `Submit Withdrawal Request (₹${amount})`}</span>
          </button>
        </form>
      </div>

      {/* Withdrawal History */}
      <div className="space-y-3">
        <h3 className="text-sm font-bold text-slate-900">Withdrawal Request History</h3>

        {loadingHistory ? (
          <div className="text-center py-6 text-xs text-slate-400">Loading requests...</div>
        ) : withdrawals.length === 0 ? (
          <div className="bg-white rounded-2xl p-6 text-center border border-slate-200 text-xs text-slate-400">
            No withdrawal requests submitted yet.
          </div>
        ) : (
          <div className="space-y-2.5">
            {withdrawals.map((w) => (
              <div
                key={w.id}
                className="bg-white p-4 rounded-2xl border border-slate-200/80 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs"
              >
                <div>
                  <div className="flex items-center gap-2">
                    <span className="font-extrabold text-sm text-slate-900">
                      ₹{w.amount.toLocaleString('en-IN')}
                    </span>
                    <span className="text-[10px] uppercase font-bold text-slate-400 bg-slate-100 px-1.5 py-0.5 rounded">
                      {w.method}
                    </span>
                  </div>
                  <div className="text-slate-500 text-[11px] mt-0.5">
                    Requested on {new Date(w.requestedAt).toLocaleDateString('en-IN', { month: 'short', day: 'numeric', year: 'numeric' })}
                    {w.payoutDetails?.upiId && ` • UPI: ${w.payoutDetails.upiId}`}
                  </div>
                  {w.transactionReference && (
                    <div className="mt-1 text-[11px] font-mono text-emerald-800 bg-emerald-50 px-2 py-0.5 rounded inline-block">
                      Bank Ref / UTR: <strong>{w.transactionReference}</strong>
                    </div>
                  )}
                  {w.adminNotes && (
                    <p className="mt-1 text-[11px] text-slate-400 italic">Note: {w.adminNotes}</p>
                  )}
                </div>

                <div>{getStatusBadge(w.status)}</div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
