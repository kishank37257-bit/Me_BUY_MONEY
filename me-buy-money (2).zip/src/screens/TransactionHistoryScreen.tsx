import React, { useState } from 'react';
import { Transaction, WithdrawalRequest } from '../types';
import { History, ArrowDownLeft, ArrowUpRight, Clock, ShieldCheck, Filter } from 'lucide-react';

interface TransactionHistoryScreenProps {
  transactions: Transaction[];
  withdrawals: WithdrawalRequest[];
}

export const TransactionHistoryScreen: React.FC<TransactionHistoryScreenProps> = ({
  transactions,
  withdrawals,
}) => {
  const [filterType, setFilterType] = useState<'all' | 'credits' | 'withdrawals'>('all');

  // Combine transactions and withdrawals into a unified chronological ledger
  type LedgerItem = {
    id: string;
    type: 'credit' | 'withdrawal' | 'click' | 'pending';
    title: string;
    subtitle: string;
    amount: number;
    status: string;
    timestamp: string;
    refId: string;
  };

  const ledgerItems: LedgerItem[] = [
    // Confirmed cashbacks (Credits)
    ...transactions
      .filter((t) => t.status === 'Cashback Confirmed' || t.status === 'Cashback Paid')
      .map((t) => ({
        id: t.id,
        type: 'credit' as const,
        title: `Cashback Confirmed: ${t.storeName}`,
        subtitle: `Order #${t.networkOrderId || t.id.slice(0, 8)} • 40% Share of commission`,
        amount: t.userCashbackAmount,
        status: t.status,
        timestamp: t.confirmationDate || t.createdAt,
        refId: t.trackingSubId,
      })),

    // Pending cashbacks
    ...transactions
      .filter((t) => t.status === 'Cashback Pending' || t.status === 'Purchase Tracking Pending')
      .map((t) => ({
        id: t.id,
        type: 'pending' as const,
        title: `Cashback Pending: ${t.storeName}`,
        subtitle: `Awaiting return window completion`,
        amount: t.userCashbackAmount,
        status: t.status,
        timestamp: t.createdAt,
        refId: t.trackingSubId,
      })),

    // Withdrawals (Debits)
    ...withdrawals.map((w) => ({
      id: w.id,
      type: 'withdrawal' as const,
      title: `Payout Withdrawal via ${w.method}`,
      subtitle: w.transactionReference ? `Ref/UTR: ${w.transactionReference}` : `Pending accounts processing`,
      amount: -w.amount,
      status: w.status,
      timestamp: w.requestedAt,
      refId: w.id,
    })),
  ];

  const sortedLedger = ledgerItems.sort(
    (a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime()
  );

  const filtered = sortedLedger.filter((item) => {
    if (filterType === 'all') return true;
    if (filterType === 'credits') return item.type === 'credit' || item.type === 'pending';
    if (filterType === 'withdrawals') return item.type === 'withdrawal';
    return true;
  });

  return (
    <div className="space-y-6 pb-20 max-w-3xl mx-auto">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h1 className="text-xl sm:text-2xl font-extrabold text-slate-900 tracking-tight">
            Transaction History & Ledger
          </h1>
          <p className="text-xs text-slate-500">
            Immutable passbook of all cashback credits, pending tracking, and withdrawal debits
          </p>
        </div>

        {/* Filter Pills */}
        <div className="flex gap-2 text-xs">
          <button
            onClick={() => setFilterType('all')}
            className={`px-3 py-1.5 rounded-xl font-bold transition-colors ${
              filterType === 'all'
                ? 'bg-slate-900 text-white'
                : 'bg-white text-slate-600 border border-slate-200'
            }`}
          >
            All
          </button>
          <button
            onClick={() => setFilterType('credits')}
            className={`px-3 py-1.5 rounded-xl font-bold transition-colors ${
              filterType === 'credits'
                ? 'bg-emerald-600 text-white'
                : 'bg-white text-slate-600 border border-slate-200'
            }`}
          >
            Cashback Credits
          </button>
          <button
            onClick={() => setFilterType('withdrawals')}
            className={`px-3 py-1.5 rounded-xl font-bold transition-colors ${
              filterType === 'withdrawals'
                ? 'bg-purple-600 text-white'
                : 'bg-white text-slate-600 border border-slate-200'
            }`}
          >
            Withdrawals
          </button>
        </div>
      </div>

      {filtered.length === 0 ? (
        <div className="bg-white rounded-2xl p-12 text-center border border-slate-200 text-xs text-slate-400">
          No ledger transactions match this filter.
        </div>
      ) : (
        <div className="bg-white rounded-3xl border border-slate-200/90 shadow-xs divide-y divide-slate-100 overflow-hidden">
          {filtered.map((item) => {
            const isPositive = item.amount > 0;
            return (
              <div
                key={item.id}
                className="p-4 sm:p-5 flex items-center justify-between gap-4 hover:bg-slate-50/60 transition-colors"
              >
                <div className="flex items-center gap-3.5">
                  <div
                    className={`w-10 h-10 rounded-2xl flex items-center justify-center shrink-0 ${
                      item.type === 'credit'
                        ? 'bg-emerald-50 text-emerald-600'
                        : item.type === 'withdrawal'
                        ? 'bg-purple-50 text-purple-600'
                        : 'bg-amber-50 text-amber-600'
                    }`}
                  >
                    {item.type === 'credit' ? (
                      <ArrowDownLeft className="w-5 h-5" />
                    ) : item.type === 'withdrawal' ? (
                      <ArrowUpRight className="w-5 h-5" />
                    ) : (
                      <Clock className="w-5 h-5" />
                    )}
                  </div>

                  <div>
                    <h4 className="text-xs font-bold text-slate-900">{item.title}</h4>
                    <p className="text-[11px] text-slate-500">{item.subtitle}</p>
                    <div className="flex items-center gap-2 mt-0.5 text-[10px] text-slate-400">
                      <span>{new Date(item.timestamp).toLocaleDateString('en-IN', { month: 'short', day: 'numeric', year: 'numeric' })}</span>
                      <span>•</span>
                      <span className="font-mono">{item.refId}</span>
                    </div>
                  </div>
                </div>

                <div className="text-right">
                  <div
                    className={`text-sm font-black ${
                      item.type === 'credit'
                        ? 'text-emerald-600'
                        : item.type === 'withdrawal'
                        ? 'text-slate-900'
                        : 'text-amber-600'
                    }`}
                  >
                    {isPositive ? `+₹${item.amount.toLocaleString('en-IN')}` : `-₹${Math.abs(item.amount).toLocaleString('en-IN')}`}
                  </div>
                  <span
                    className={`inline-block text-[9px] font-bold px-1.5 py-0.2 rounded uppercase mt-0.5 ${
                      item.status === 'Paid' || item.status === 'Cashback Confirmed'
                        ? 'bg-emerald-50 text-emerald-700'
                        : item.status === 'Pending' || item.status === 'Cashback Pending' || item.status === 'Order Pending'
                        ? 'bg-amber-50 text-amber-700'
                        : 'bg-slate-100 text-slate-600'
                    }`}
                  >
                    {item.status}
                  </span>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
