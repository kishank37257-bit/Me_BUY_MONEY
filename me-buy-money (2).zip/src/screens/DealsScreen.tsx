import React, { useState } from 'react';
import { Product } from '../types';
import { Flame, Copy, Check, ExternalLink, Tag, ShieldCheck, ArrowRight } from 'lucide-react';

interface DealsScreenProps {
  products: Product[];
  onSelectProduct: (product: Product) => void;
}

export const DealsScreen: React.FC<DealsScreenProps> = ({ products, onSelectProduct }) => {
  const [copiedCode, setCopiedCode] = useState<string | null>(null);

  const handleCopyCode = (code: string) => {
    navigator.clipboard.writeText(code);
    setCopiedCode(code);
    setTimeout(() => setCopiedCode(null), 2000);
  };

  return (
    <div className="space-y-6 pb-20">
      {/* Header */}
      <div className="bg-gradient-to-r from-rose-500 via-orange-500 to-amber-500 text-white p-6 sm:p-8 rounded-3xl shadow-lg shadow-orange-500/15 space-y-2">
        <div className="flex items-center gap-2">
          <Flame className="w-5 h-5 fill-white" />
          <span className="text-xs font-bold uppercase tracking-wider text-rose-100">
            Handpicked Curated Offers
          </span>
        </div>
        <h1 className="text-2xl sm:text-3xl font-black">Best Deals & Cashback Boosts</h1>
        <p className="text-xs sm:text-sm text-rose-50 max-w-xl">
          Stack merchant store discounts with coupon codes AND get up to 8% real cashback into your wallet.
        </p>
      </div>

      {/* Deals Grid with Deep Math Breakdown */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
        {products.map((prod) => {
          const discount = prod.originalPrice - prod.dealPrice;
          const discountPct = Math.round((discount / prod.originalPrice) * 100);

          // Calculate cashback amount
          const cashbackAmount =
            prod.cashbackType === 'flat'
              ? prod.cashbackRate
              : Math.round((prod.dealPrice * prod.cashbackRate) / 100);

          const effectivePrice = Math.max(0, prod.dealPrice - cashbackAmount);

          return (
            <div
              key={prod.id}
              className="bg-white rounded-2xl border border-slate-200/90 shadow-sm overflow-hidden flex flex-col justify-between hover:shadow-md transition-shadow"
            >
              {/* Top Details */}
              <div className="p-5 space-y-4">
                <div className="flex items-start gap-4">
                  <div className="relative w-28 h-28 shrink-0 rounded-xl overflow-hidden bg-slate-50 border border-slate-100">
                    <img
                      src={prod.imageUrl}
                      alt={prod.title}
                      className="w-full h-full object-cover"
                    />
                    {discountPct > 0 && (
                      <span className="absolute top-1.5 left-1.5 bg-rose-600 text-white font-black text-[9px] px-1.5 py-0.5 rounded shadow">
                        {discountPct}% OFF
                      </span>
                    )}
                  </div>

                  <div className="flex-1 min-w-0 space-y-1.5">
                    <div className="flex items-center gap-2">
                      <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider">
                        {prod.storeName}
                      </span>
                      <span className="w-1 h-1 bg-slate-300 rounded-full" />
                      <span className="text-[10px] text-emerald-600 font-bold bg-emerald-50 px-1.5 py-0.2 rounded">
                        Verified Deal
                      </span>
                    </div>

                    <h3 className="text-sm font-bold text-slate-900 leading-snug line-clamp-2">
                      {prod.title}
                    </h3>

                    <p className="text-xs text-slate-500 line-clamp-2 leading-relaxed">
                      {prod.description}
                    </p>
                  </div>
                </div>

                {/* Cashback & Pricing Math Table */}
                <div className="bg-slate-50 rounded-xl p-3 border border-slate-100 space-y-2 text-xs">
                  <div className="flex justify-between text-slate-500">
                    <span>Retail Price (MRP):</span>
                    <span className="line-through">₹{prod.originalPrice.toLocaleString('en-IN')}</span>
                  </div>
                  <div className="flex justify-between text-slate-800 font-medium">
                    <span>Deal Price on {prod.storeName}:</span>
                    <span>₹{prod.dealPrice.toLocaleString('en-IN')}</span>
                  </div>
                  <div className="flex justify-between text-emerald-700 font-bold">
                    <span>Me BUY MONEY Cashback (You Earn):</span>
                    <span>- ₹{cashbackAmount.toLocaleString('en-IN')}</span>
                  </div>
                  <div className="pt-1.5 border-t border-slate-200 flex justify-between items-baseline">
                    <span className="font-extrabold text-slate-900">Your Effective Price:</span>
                    <span className="text-base font-black text-emerald-600">
                      ₹{effectivePrice.toLocaleString('en-IN')}
                    </span>
                  </div>
                </div>
              </div>

              {/* Bottom Actions */}
              <div className="p-4 bg-slate-50/80 border-t border-slate-100 flex flex-wrap items-center justify-between gap-3">
                {prod.couponCode ? (
                  <button
                    onClick={() => handleCopyCode(prod.couponCode!)}
                    className="flex items-center gap-1.5 px-3 py-1.5 bg-white border border-dashed border-emerald-500 text-emerald-800 rounded-xl text-xs font-mono font-bold hover:bg-emerald-50 transition-colors"
                  >
                    <Tag className="w-3.5 h-3.5 text-emerald-600" />
                    <span>{prod.couponCode}</span>
                    {copiedCode === prod.couponCode ? (
                      <Check className="w-3.5 h-3.5 text-emerald-600" />
                    ) : (
                      <Copy className="w-3.5 h-3.5 text-slate-400" />
                    )}
                  </button>
                ) : (
                  <span className="text-xs text-slate-400 italic">No code required</span>
                )}

                <button
                  onClick={() => onSelectProduct(prod)}
                  className="py-2 px-5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold shadow-md shadow-emerald-500/20 flex items-center gap-2 transition-all hover:gap-3"
                >
                  <span>Shop & Earn ₹{cashbackAmount}</span>
                  <ExternalLink className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
