import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import {
  User,
  Mail,
  Phone,
  CreditCard,
  Shield,
  HelpCircle,
  FileText,
  LogOut,
  Check,
  ChevronRight,
  Sparkles,
  ShieldCheck,
  ExternalLink,
} from 'lucide-react';
import { updateUserPaymentPreferences } from '../services/dbService';
import { ScreenTab } from '../types';

interface ProfileScreenProps {
  onNavigate: (tab: ScreenTab) => void;
}

export const ProfileScreen: React.FC<ProfileScreenProps> = ({ onNavigate }) => {
  const { profile, isAdmin, logout, refreshProfile, openAuthModal, signInWithGoogle, currentUser } = useAuth();
  const [upiId, setUpiId] = useState(profile?.upiId || '');
  const [phone, setPhone] = useState(profile?.phone || '');
  const [saving, setSaving] = useState(false);
  const [savedSuccess, setSavedSuccess] = useState(false);

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!profile) return;
    setSaving(true);
    try {
      await updateUserPaymentPreferences(profile.id, upiId, phone);
      await refreshProfile();
      setSavedSuccess(true);
      setTimeout(() => setSavedSuccess(false), 2000);
    } catch (e: any) {
      alert('Error updating preferences: ' + e.message);
    } finally {
      setSaving(false);
    }
  };

  const isGuest = !currentUser && (!profile || profile.id === 'demo_shopper_01');

  return (
    <div className="space-y-4 pb-20 max-w-md mx-auto px-1 sm:px-0">
      {/* If Guest, Show Mobile Login Card */}
      {isGuest && (
        <div className="bg-gradient-to-br from-emerald-900 via-teal-900 to-slate-900 text-white rounded-3xl p-5 shadow-lg space-y-3.5">
          <div className="flex items-center justify-between">
            <div className="space-y-0.5">
              <span className="text-[10px] font-bold text-emerald-300 uppercase tracking-wider">Shopper Account</span>
              <h2 className="text-base font-black text-white">Login to Me BUY MONEY</h2>
            </div>
            <span className="bg-emerald-500/20 text-emerald-300 border border-emerald-400/30 text-[10px] font-black px-2 py-0.5 rounded-full uppercase">
              +₹50 Bonus
            </span>
          </div>
          <p className="text-xs text-slate-300 leading-relaxed">
            Apne Gmail account se login karein jisse aapka cashback, reward links aur UPI wallet safe rahe.
          </p>

          <div className="space-y-2 pt-1">
            <button
              onClick={signInWithGoogle}
              className="w-full py-3 px-4 rounded-2xl bg-white text-slate-900 font-black text-xs flex items-center justify-center gap-2.5 shadow-sm active:scale-95 transition-transform"
            >
              <svg className="w-4 h-4 shrink-0" viewBox="0 0 24 24">
                <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/>
                <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/>
                <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"/>
                <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"/>
              </svg>
              <span>Direct Google se Login Karein</span>
            </button>

            <div className="grid grid-cols-2 gap-2 text-xs">
              <button
                onClick={() => openAuthModal('signin')}
                className="py-2.5 px-3 rounded-2xl bg-white/10 hover:bg-white/20 text-white font-bold border border-white/15 text-center active:scale-95 transition-transform"
              >
                Gmail & Password
              </button>
              <button
                onClick={() => openAuthModal('signup')}
                className="py-2.5 px-3 rounded-2xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black text-center active:scale-95 transition-transform"
              >
                Create Account (+₹50)
              </button>
            </div>
          </div>
        </div>
      )}

      {/* User Header */}
      <div className="bg-white rounded-3xl p-5 border border-slate-200/90 shadow-sm flex items-center gap-4">
        <div className="w-14 h-14 rounded-2xl bg-gradient-to-tr from-emerald-600 to-teal-500 text-white font-black text-xl flex items-center justify-center shadow-md shadow-emerald-500/20 uppercase shrink-0">
          {profile?.displayName?.charAt(0) || 'U'}
        </div>
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2">
            <h2 className="text-base font-black text-slate-900 truncate">
              {profile?.displayName || 'Me BUY MONEY Shopper'}
            </h2>
            <span
              className={`text-[9px] font-bold px-2 py-0.5 rounded-full uppercase ${
                isAdmin ? 'bg-purple-100 text-purple-800' : 'bg-emerald-100 text-emerald-800'
              }`}
            >
              {isAdmin ? 'Admin' : 'Shopper'}
            </span>
          </div>
          <p className="text-xs text-slate-500 truncate font-mono">{profile?.email || 'shopper@mebuymoney.com'}</p>
        </div>
      </div>

      {/* Payment Settings */}
      <div className="bg-white rounded-3xl p-6 border border-slate-200/90 shadow-sm space-y-4">
        <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
          <CreditCard className="w-4 h-4 text-emerald-600" />
          <span>Default Payout Information</span>
        </h3>
        <p className="text-xs text-slate-500">
          Save your verified UPI ID so you can withdraw cashback in 1-click.
        </p>

        {savedSuccess && (
          <div className="bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs p-3 rounded-xl flex items-center gap-2">
            <Check className="w-4 h-4 text-emerald-600" />
            <span>Payment settings updated successfully!</span>
          </div>
        )}

        <form onSubmit={handleSave} className="space-y-3 text-xs">
          <div className="space-y-1">
            <label className="font-bold text-slate-700">UPI ID for Cashback Withdrawals</label>
            <input
              type="text"
              value={upiId}
              onChange={(e) => setUpiId(e.target.value)}
              placeholder="e.g. mobile@paytm or name@okaxis"
              className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl font-medium text-slate-900 outline-none focus:ring-1 focus:ring-emerald-500"
            />
          </div>

          <div className="space-y-1">
            <label className="font-bold text-slate-700">Phone Number (Optional)</label>
            <input
              type="text"
              value={phone}
              onChange={(e) => setPhone(e.target.value)}
              placeholder="+91 9876543210"
              className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl font-medium text-slate-900 outline-none focus:ring-1 focus:ring-emerald-500"
            />
          </div>

          <button
            type="submit"
            disabled={saving}
            className="py-2.5 px-5 rounded-xl bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs transition-colors"
          >
            {saving ? 'Saving...' : 'Save Payment Preferences'}
          </button>
        </form>
      </div>

      {/* Account Security & Fast Account Switch */}
      <div className="bg-emerald-50/60 border border-emerald-200/80 rounded-3xl p-5 space-y-3 text-xs">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <ShieldCheck className="w-4 h-4 text-emerald-700" />
            <h3 className="font-bold text-emerald-950">Bank-Grade Account Security</h3>
          </div>
          <span className="text-[10px] font-bold text-emerald-700 bg-emerald-100 px-2 py-0.5 rounded-full">
            Active & Verified
          </span>
        </div>
        <p className="text-emerald-900 text-[11px] leading-relaxed">
          Your cashback wallet, payment IDs, and personal information are strictly encrypted with 256-bit SSL security. Me BUY MONEY never shares your private credentials.
        </p>
        <div className="flex flex-col sm:flex-row gap-2 pt-1">
          <button
            onClick={() => openAuthModal('signup')}
            className="flex-1 py-2.5 px-4 rounded-xl font-bold text-xs bg-emerald-600 hover:bg-emerald-700 text-white transition-colors flex items-center justify-center gap-2 shadow-xs"
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>+ Create New Account (₹50 Bonus)</span>
          </button>
          <button
            onClick={() => openAuthModal('signin')}
            className="flex-1 py-2.5 px-4 rounded-xl font-bold text-xs bg-white text-slate-800 border border-slate-200 hover:bg-slate-50 transition-colors flex items-center justify-center gap-2"
          >
            <span>Sign In to Another Account</span>
          </button>
        </div>
      </div>


      {/* Quick Navigation Links */}
      <div className="bg-white rounded-3xl border border-slate-200/90 shadow-sm divide-y divide-slate-100 overflow-hidden text-xs">
        <button
          onClick={() => onNavigate('help')}
          className="w-full p-4 flex items-center justify-between text-slate-700 hover:bg-slate-50 transition-colors"
        >
          <div className="flex items-center gap-3">
            <HelpCircle className="w-4 h-4 text-slate-400" />
            <span className="font-medium">Help, FAQ & Cashback Guide</span>
          </div>
          <ChevronRight className="w-4 h-4 text-slate-400" />
        </button>

        <button
          onClick={() => onNavigate('store-offers')}
          className="w-full p-4 flex items-center justify-between text-slate-700 hover:bg-slate-50 transition-colors"
        >
          <div className="flex items-center gap-3">
            <ShieldCheck className="w-4 h-4 text-slate-400" />
            <span>Affiliate Disclosure & Partner Terms</span>
          </div>
          <ChevronRight className="w-4 h-4 text-slate-400" />
        </button>

        <button
          onClick={logout}
          className="w-full p-4 flex items-center justify-between text-rose-600 hover:bg-rose-50 transition-colors font-bold"
        >
          <div className="flex items-center gap-3">
            <LogOut className="w-4 h-4 text-rose-600" />
            <span>Sign Out</span>
          </div>
          <ChevronRight className="w-4 h-4 text-rose-400" />
        </button>
      </div>
    </div>
  );
};
