import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import {
  Bell,
  CheckCircle2,
  Clock,
  ArrowUpRight,
  Gift,
  ShoppingBag,
  ExternalLink,
  CheckCheck,
} from 'lucide-react';
import { getUserNotifications, markNotificationAsRead } from '../services/dbService';
import { AppNotification, ScreenTab } from '../types';

interface NotificationsScreenProps {
  onNavigate: (tab: ScreenTab) => void;
  onRefreshCount?: () => void;
}

export const NotificationsScreen: React.FC<NotificationsScreenProps> = ({
  onNavigate,
  onRefreshCount,
}) => {
  const { profile } = useAuth();
  const [notifications, setNotifications] = useState<AppNotification[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (profile?.id) {
      loadNotifications();
    }
  }, [profile?.id]);

  const loadNotifications = async () => {
    if (!profile?.id) return;
    try {
      setLoading(true);
      const list = await getUserNotifications(profile.id);
      setNotifications(list);
    } catch (e) {
      console.error('Error fetching notifications:', e);
    } finally {
      setLoading(false);
    }
  };

  const handleMarkAllRead = async () => {
    for (const n of notifications) {
      if (!n.isRead) {
        await markNotificationAsRead(n.id);
      }
    }
    setNotifications((prev) => prev.map((n) => ({ ...n, isRead: true })));
    if (onRefreshCount) onRefreshCount();
  };

  const getIcon = (type: AppNotification['type']) => {
    switch (type) {
      case 'click':
        return <ShoppingBag className="w-4 h-4 text-emerald-600" />;
      case 'order':
        return <Clock className="w-4 h-4 text-blue-600" />;
      case 'cashback':
        return <CheckCircle2 className="w-4 h-4 text-emerald-600" />;
      case 'withdrawal':
        return <ArrowUpRight className="w-4 h-4 text-purple-600" />;
      case 'referral':
        return <Gift className="w-4 h-4 text-amber-600" />;
      default:
        return <Bell className="w-4 h-4 text-slate-600" />;
    }
  };

  return (
    <div className="space-y-6 pb-20 max-w-2xl mx-auto">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl sm:text-2xl font-extrabold text-slate-900 tracking-tight">
            Notifications & Inbox
          </h1>
          <p className="text-xs text-slate-500">
            Real-time updates on affiliate tracking, order confirmations and withdrawals
          </p>
        </div>

        {notifications.some((n) => !n.isRead) && (
          <button
            onClick={handleMarkAllRead}
            className="text-xs font-bold text-emerald-600 hover:text-emerald-700 flex items-center gap-1"
          >
            <CheckCheck className="w-4 h-4" />
            <span>Mark all read</span>
          </button>
        )}
      </div>

      {loading ? (
        <div className="text-center py-10 text-xs text-slate-400">Loading notifications...</div>
      ) : notifications.length === 0 ? (
        <div className="bg-white rounded-2xl p-12 text-center border border-slate-200 space-y-3">
          <div className="w-12 h-12 bg-slate-100 rounded-full flex items-center justify-center mx-auto text-slate-400">
            <Bell className="w-6 h-6" />
          </div>
          <h3 className="text-sm font-bold text-slate-800">Inbox is empty</h3>
          <p className="text-xs text-slate-500 max-w-sm mx-auto">
            You will receive instant alerts here whenever a click is logged, order is detected, or your cashback confirms!
          </p>
        </div>
      ) : (
        <div className="space-y-2.5">
          {notifications.map((notif) => (
            <div
              key={notif.id}
              onClick={() => {
                if (!notif.isRead) markNotificationAsRead(notif.id);
                setNotifications((prev) =>
                  prev.map((n) => (n.id === notif.id ? { ...n, isRead: true } : n))
                );
              }}
              className={`p-4 rounded-2xl border transition-all cursor-pointer flex items-start gap-3.5 ${
                notif.isRead
                  ? 'bg-white border-slate-200/80 text-slate-700'
                  : 'bg-emerald-50/40 border-emerald-200 text-slate-900 shadow-xs'
              }`}
            >
              <div className="w-9 h-9 rounded-xl bg-white border border-slate-200 shadow-xs flex items-center justify-center shrink-0">
                {getIcon(notif.type)}
              </div>

              <div className="flex-1 min-w-0 space-y-1">
                <div className="flex items-center justify-between gap-2">
                  <h4 className="text-xs font-bold leading-tight">{notif.title}</h4>
                  <span className="text-[10px] text-slate-400 shrink-0">
                    {new Date(notif.createdAt).toLocaleDateString('en-IN', {
                      month: 'short',
                      day: 'numeric',
                      hour: '2-digit',
                      minute: '2-digit',
                    })}
                  </span>
                </div>
                <p className="text-xs text-slate-600 leading-relaxed">{notif.message}</p>
              </div>

              {!notif.isRead && (
                <span className="w-2 h-2 rounded-full bg-emerald-600 shrink-0 mt-1.5" />
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
