import React, { useState } from 'react';
import {
  History,
  Link2,
  ShoppingBag,
  ArrowUpRight,
  Clock,
  CheckCircle2,
  XCircle,
  ExternalLink,
  Search,
  Filter,
  Plus,
  ArrowRight,
  FileText,
  Inbox,
  AlertCircle,
  Banknote,
  MousePointerClick,
  Send,
} from 'lucide-react';
import {
  Transaction,
  WithdrawalRequest,
  RewardLinkRequest,
  UserInboxItem,
  ScreenTab,
  OrderStatus,
} from '../types';
import { useAuth } from '../context/AuthContext';

interface UnifiedHistoryScreenProps {
  transactions: Transaction[];
  withdrawals: WithdrawalRequest[];
  rewardRequests: RewardLinkRequest[];
  inboxItems: UserInboxItem[];
  onNavigate: (tab: ScreenTab) => void;
  onRefresh: () => void;
}

export const UnifiedHistoryScreen: React.FC<UnifiedHistoryScreenProps> = ({
  transactions,
  withdrawals,
  rewardRequests,
  inboxItems,
  onNavigate,
  onRefresh,
}) => {
  const { wallet } = useAuth();
  const [filterType, setFilterType] = useState<'all' | 'reward-links' | 'orders' | 'withdrawals'>('all');
  const [searchQuery, setSearchQuery] = useState('');

  // 1. Map Reward Requests
  const requestItems = rewardRequests.map((r) => ({
    id: r.id,
    type: 'reward_link' as const,
    title: `${r.storeName} Reward Link Request`,
    subtitle: r.productUrl,
    date: r.submittedAt,
    status: r.status,
    amount: null,
    refId: r.id,
    storeName: r.storeName,
    raw: r,
  }));

  // 2. Map Transactions / Orders
  const orderItems = transactions.map((t) => ({
    id: t.id,
    type: 'order' as const,
    title: t.productTitle || `${t.storeName} Order`,
    subtitle: `Store: ${t.storeName} • Sub-ID: ${t.trackingSubId}`,
    date: t.createdAt,
    status: t.status,
    amount: t.userCashbackAmount ? `+₹${t.userCashbackAmount.toLocaleString('en-IN')}` : null,
    refId: t.trackingSubId || t.id,
    storeName: t.storeName,
    raw: t,
  }));

  // 3. Map Withdrawals
  const withdrawalItems = withdrawals.map((w) => ({
    id: w.id,
    type: 'withdrawal' as const,
    title: `Withdrawal via ${w.method}`,
    subtitle:
      w.method === 'UPI'
        ? `UPI ID: ${w.payoutDetails?.upiId || 'Saved UPI'}`
        : `Bank: ${w.payoutDetails?.bankName || 'Bank Account'} (${w.payoutDetails?.accountNumber?.slice(-4) || '****'})`,
    date: w.requestedAt,
    status: w.status,
    amount: `-₹${w.amount.toLocaleString('en-IN')}`,
    refId: w.transactionReference || w.id,
    storeName: w.method,
    raw: w,
  }));

  // Combine and sort chronologically
  const allItems = [...requestItems, ...orderItems, ...withdrawalItems].sort(
    (a, b) => new Date(b.date).getTime() - new Date(a.date).getTime()
  );

  const filteredItems = allItems.filter((item) => {
    const matchesFilter =
      filterType === 'all' ||
      (filterType === 'reward-links' && item.type === 'reward_link') ||
      (filterType === 'orders' && item.type === 'order') ||
      (filterType === 'withdrawals' && item.type === 'withdrawal');

    const matchesSearch =
      !searchQuery.trim() ||
      item.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.subtitle.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.refId.toLowerCase().includes(searchQuery.toLowerCase());

    return matchesFilter && matchesSearch;
  });

  const getDaysRemaining = (clickedAt?: string, deadline?: string) => {
    const target = deadline
      ? new Date(deadline).getTime()
      : (clickedAt ? new Date(clickedAt).getTime() + 7 * 86400000 : Date.now() + 7 * 86400000);
    const diffMs = target - Date.now();
    const days = Math.max(0, Math.ceil(diffMs / (1000 * 60 * 60 * 24)));
    return days;
  };

  const getStatusBadge = (status: string, type: 'reward_link' | 'order' | 'withdrawal', raw?: any) => {
    if (status === 'Completed' || status === 'Paid' || status === 'Cashback Confirmed') {
      return (
        <span className="inline-flex items-center gap-1 text-[10px] font-extrabold text-emerald-800 bg-emerald-50 border border-emerald-200 px-2.5 py-0.5 rounded-full">
          <CheckCircle2 className="w-3 h-3 text-emerald-600" />
          <span>{type === 'order' ? 'Order Successful' : status}</span>
        </span>
      );
    }
    if (status === 'Pending' || status === 'Link Requested' || status === 'Purchase Tracking Pending' || status === 'Cashback Pending' || status === 'Link Clicked') {
      const daysLeft = type === 'order' ? getDaysRemaining(raw?.clickedAt, raw?.verificationDeadline) : null;
      return (
        <span className="inline-flex items-center gap-1 text-[10px] font-extrabold text-amber-800 bg-amber-50 border border-amber-300 px-2.5 py-0.5 rounded-full">
          <Clock className="w-3 h-3 text-amber-600" />
          <span>{type === 'order' ? `7 Days Pending (${daysLeft ?? 7}d left)` : status}</span>
        </span>
      );
    }
    if (status === 'Link Sent') {
      return (
        <span className="inline-flex items-center gap-1 text-[10px] font-extrabold text-blue-800 bg-blue-50 border border-blue-200 px-2.5 py-0.5 rounded-full">
          <Send className="w-3 h-3 text-blue-600" />
          <span>Ready in Inbox</span>
        </span>
      );
    }
    if (status === 'Rejected' || status === 'Cashback Rejected') {
      return (
        <span className="inline-flex items-center gap-1 text-[10px] font-extrabold text-rose-800 bg-rose-50 border border-rose-200 px-2.5 py-0.5 rounded-full">
          <XCircle className="w-3 h-3 text-rose-600" />
          <span>{type === 'order' ? 'Order Rejected' : status}</span>
        </span>
      );
    }
    return (
      <span className="inline-flex items-center gap-1 text-[10px] font-bold text-slate-700 bg-slate-100 px-2.5 py-0.5 rounded-full">
        <span>{status}</span>
      </span>
    );
  };

  return (
    <div className="space-y-4 pb-24 max-w-md mx-auto px-1 sm:px-0">
      {/* Header */}
      <div className="flex items-center justify-between pt-1">
        <div>
          <h1 className="text-xl font-black text-slate-900 tracking-tight flex items-center gap-2">
            <History className="w-5 h-5 text-emerald-600" />
            <span>Complete History</span>
          </h1>
          <p className="text-[11px] text-slate-500">
            All your links, tracked orders, cashbacks & withdrawals in one place
          </p>
        </div>

        <button
          onClick={onRefresh}
          className="text-xs font-bold text-emerald-700 hover:text-emerald-800 bg-emerald-50 px-2.5 py-1.5 rounded-xl border border-emerald-200"
        >
          Refresh
        </button>
      </div>

      {/* Summary KPI Cards Strip */}
      <div className="grid grid-cols-3 gap-2 text-center">
        <div className="bg-white p-2.5 rounded-2xl border border-slate-200/80 shadow-xs">
          <span className="text-[9px] uppercase font-bold text-slate-400 block">Links Requested</span>
          <span className="text-base font-black text-slate-900 font-mono">
            {rewardRequests.length}
          </span>
        </div>
        <div className="bg-white p-2.5 rounded-2xl border border-slate-200/80 shadow-xs">
          <span className="text-[9px] uppercase font-bold text-emerald-700 block">Confirmed Earned</span>
          <span className="text-base font-black text-emerald-600 font-mono">
            ₹{(wallet?.totalEarned ?? 0).toLocaleString('en-IN')}
          </span>
        </div>
        <div className="bg-white p-2.5 rounded-2xl border border-slate-200/80 shadow-xs">
          <span className="text-[9px] uppercase font-bold text-purple-700 block">Withdrawn</span>
          <span className="text-base font-black text-purple-600 font-mono">
            ₹{(wallet?.totalWithdrawn ?? 0).toLocaleString('en-IN')}
          </span>
        </div>
      </div>

      {/* Search Input */}
      <div className="relative">
        <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
        <input
          type="text"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          placeholder="Search by store, product, ID..."
          className="w-full pl-9 pr-3 py-2.5 bg-white border border-slate-200 rounded-2xl text-xs text-slate-900 placeholder-slate-400 outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500"
        />
      </div>

      {/* Category Filter Pills */}
      <div className="flex gap-1.5 overflow-x-auto pb-1 scrollbar-none text-xs">
        <button
          onClick={() => setFilterType('all')}
          className={`px-3 py-1.5 rounded-xl font-bold whitespace-nowrap transition-colors ${
            filterType === 'all'
              ? 'bg-slate-900 text-white'
              : 'bg-white text-slate-600 border border-slate-200 hover:bg-slate-50'
          }`}
        >
          All ({allItems.length})
        </button>
        <button
          onClick={() => setFilterType('reward-links')}
          className={`px-3 py-1.5 rounded-xl font-bold whitespace-nowrap transition-colors ${
            filterType === 'reward-links'
              ? 'bg-emerald-600 text-white'
              : 'bg-white text-slate-600 border border-slate-200 hover:bg-slate-50'
          }`}
        >
          Links ({rewardRequests.length})
        </button>
        <button
          onClick={() => setFilterType('orders')}
          className={`px-3 py-1.5 rounded-xl font-bold whitespace-nowrap transition-colors ${
            filterType === 'orders'
              ? 'bg-teal-700 text-white'
              : 'bg-white text-slate-600 border border-slate-200 hover:bg-slate-50'
          }`}
        >
          Orders ({transactions.length})
        </button>
        <button
          onClick={() => setFilterType('withdrawals')}
          className={`px-3 py-1.5 rounded-xl font-bold whitespace-nowrap transition-colors ${
            filterType === 'withdrawals'
              ? 'bg-purple-700 text-white'
              : 'bg-white text-slate-600 border border-slate-200 hover:bg-slate-50'
          }`}
        >
          Payouts ({withdrawals.length})
        </button>
      </div>

      {/* Main Unified History Feed */}
      {filteredItems.length === 0 ? (
        <div className="bg-white rounded-3xl p-8 text-center border border-slate-200 shadow-xs space-y-2.5">
          <div className="w-12 h-12 rounded-2xl bg-slate-100 text-slate-400 flex items-center justify-center mx-auto">
            <History className="w-6 h-6" />
          </div>
          <h3 className="text-xs font-bold text-slate-800">No activity found</h3>
          <p className="text-[11px] text-slate-400 max-w-xs mx-auto">
            When you request a reward link, shop online, or withdraw cash, all updates appear here.
          </p>
          <button
            onClick={() => onNavigate('reward-link')}
            className="px-4 py-2 bg-emerald-600 text-white font-bold text-xs rounded-xl shadow-sm"
          >
            Create Reward Link
          </button>
        </div>
      ) : (
        <div className="space-y-2.5">
          {filteredItems.map((item) => (
            <div
              key={`${item.type}_${item.id}`}
              className="bg-white p-3.5 sm:p-4 rounded-2xl border border-slate-200/90 shadow-xs hover:border-slate-300 transition-colors space-y-2.5"
            >
              {/* Header row */}
              <div className="flex items-start justify-between gap-2">
                <div className="flex items-center gap-2 min-w-0">
                  <div
                    className={`w-8 h-8 rounded-xl flex items-center justify-center shrink-0 ${
                      item.type === 'reward_link'
                        ? 'bg-emerald-50 text-emerald-700'
                        : item.type === 'order'
                        ? 'bg-teal-50 text-teal-700'
                        : 'bg-purple-50 text-purple-700'
                    }`}
                  >
                    {item.type === 'reward_link' ? (
                      <Link2 className="w-4 h-4" />
                    ) : item.type === 'order' ? (
                      <ShoppingBag className="w-4 h-4" />
                    ) : (
                      <Banknote className="w-4 h-4" />
                    )}
                  </div>

                  <div className="min-w-0">
                    <h4 className="text-xs font-extrabold text-slate-900 truncate leading-tight">
                      {item.title}
                    </h4>
                    <span className="text-[10px] text-slate-400 block font-mono">
                      {item.refId}
                    </span>
                  </div>
                </div>

                <div className="text-right shrink-0">
                  {getStatusBadge(item.status, item.type, item.raw)}
                  {item.amount && (
                    <span
                      className={`text-xs font-black block mt-1 font-mono ${
                        item.amount.startsWith('+') ? 'text-emerald-600' : 'text-slate-800'
                      }`}
                    >
                      {item.amount}
                    </span>
                  )}
                </div>
              </div>

              {/* Subtitle / Details */}
              <p className="text-[11px] text-slate-500 truncate font-mono bg-slate-50 p-2 rounded-xl border border-slate-100">
                {item.subtitle}
              </p>

              {/* Order 7-Day Tracking Timeline Box */}
              {item.type === 'order' && (
                <div
                  className={`p-3 rounded-2xl border text-xs space-y-2 ${
                    item.status === 'Cashback Confirmed'
                      ? 'bg-emerald-50/80 border-emerald-200 text-emerald-950'
                      : item.status === 'Cashback Rejected'
                      ? 'bg-rose-50/80 border-rose-200 text-rose-950'
                      : 'bg-amber-50/90 border-amber-300 text-amber-950'
                  }`}
                >
                  <div className="flex items-center justify-between font-extrabold text-[11px]">
                    <span className="flex items-center gap-1.5">
                      {item.status === 'Cashback Confirmed' ? (
                        <>
                          <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                          <span>Order Successful • Cashback Credited!</span>
                        </>
                      ) : item.status === 'Cashback Rejected' ? (
                        <>
                          <XCircle className="w-4 h-4 text-rose-600 shrink-0" />
                          <span>Order Verification Rejected</span>
                        </>
                      ) : (
                        <>
                          <Clock className="w-4 h-4 text-amber-600 shrink-0 animate-pulse" />
                          <span>Order Clicked • 7 Days Verification Pending</span>
                        </>
                      )}
                    </span>
                    <span className="font-mono text-[10px] px-2 py-0.5 rounded-lg bg-white/90 border border-current/20 shadow-2xs">
                      {item.status === 'Cashback Confirmed'
                        ? 'Payment Credited'
                        : item.status === 'Cashback Rejected'
                        ? 'No Order Found'
                        : `${getDaysRemaining((item.raw as Transaction).clickedAt, (item.raw as Transaction).verificationDeadline)} days left`}
                    </span>
                  </div>

                  <p className="text-[11px] leading-relaxed opacity-90">
                    {item.status === 'Cashback Confirmed'
                      ? 'Admin ne aapka order store affiliate report se verify kar diya hai aur cashback wallet me successfully credit ho gaya hai! 🎉'
                      : item.status === 'Cashback Rejected'
                      ? ((item.raw as Transaction).rejectionReason || 'Affiliate network par is link click se koi qualifying order record nahi hua ya cancel/return ho gaya.')
                      : 'Aapka order click track ho gaya hai! Admin 7 din ke andar store report check karke Successful mark karega aur payment mil jaega.'}
                  </p>

                  {/* 3-Step visual status bar */}
                  <div className="grid grid-cols-3 gap-1 pt-1 text-[9px] font-bold text-center">
                    <div className="bg-emerald-600 text-white py-1 px-1.5 rounded-md flex items-center justify-center gap-1">
                      <span>✓ 1. Link Clicked</span>
                    </div>
                    <div
                      className={`py-1 px-1.5 rounded-md flex items-center justify-center gap-1 ${
                        item.status === 'Cashback Confirmed'
                          ? 'bg-emerald-600 text-white'
                          : item.status === 'Cashback Rejected'
                          ? 'bg-rose-600 text-white'
                          : 'bg-amber-400 text-amber-950 animate-pulse font-extrabold'
                      }`}
                    >
                      <span>2. 7-Day Verification</span>
                    </div>
                    <div
                      className={`py-1 px-1.5 rounded-md flex items-center justify-center gap-1 ${
                        item.status === 'Cashback Confirmed'
                          ? 'bg-emerald-600 text-white font-extrabold'
                          : 'bg-slate-200 text-slate-500'
                      }`}
                    >
                      <span>3. Cashback Paid</span>
                    </div>
                  </div>
                </div>
              )}

              {/* Footer action / timestamp */}
              <div className="flex items-center justify-between text-[10px] text-slate-400 pt-0.5">
                <span>
                  {new Date(item.date).toLocaleDateString('en-IN', {
                    month: 'short',
                    day: 'numeric',
                    hour: '2-digit',
                    minute: '2-digit',
                  })}
                </span>

                {item.type === 'reward_link' && item.status === 'Completed' && (
                  <button
                    onClick={() => onNavigate('inbox')}
                    className="text-emerald-700 font-extrabold hover:underline flex items-center gap-1"
                  >
                    <Inbox className="w-3 h-3" />
                    <span>Open in Inbox</span>
                  </button>
                )}
                {item.type === 'withdrawal' && (
                  <button
                    onClick={() => onNavigate('wallet')}
                    className="text-purple-700 font-extrabold hover:underline"
                  >
                    View Wallet →
                  </button>
                )}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
