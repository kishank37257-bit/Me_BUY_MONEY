import React from 'react';
import { AffiliateNetwork, Product } from '../types';
import { Store, Clock, Calendar, ShieldCheck, ExternalLink, CheckCircle2, XCircle } from 'lucide-react';

interface StoreOffersScreenProps {
  networks: AffiliateNetwork[];
  products: Product[];
  onSelectProduct: (product: Product) => void;
}

export const StoreOffersScreen: React.FC<StoreOffersScreenProps> = ({
  networks,
  products,
  onSelectProduct,
}) => {
  const storeCatalog = [
    {
      storeName: 'Amazon India',
      networkName: 'Amazon Associates',
      logo: 'https://images.unsplash.com/photo-1523474255658-4af61825044d?w=120&auto=format&fit=crop&q=80',
      cashbackRate: 'Up to 3.5% Cashback',
      trackingSpeed: '24 - 48 Hours',
      confirmationSpeed: '60 - 90 Days',
      userShare: '40% of Affiliate Payout',
      terms: 'Applicable across Mobiles, Laptops, Fashion, Pantry & Appliances. Not valid on Amazon Gift Cards or Gold/Silver coins.',
      dos: ['Add products to cart only AFTER clicking from Me BUY MONEY', 'Complete purchase in the same browser session'],
      donts: ['Do not use browser extensions like Honey or Coupert', 'Do not click external promotional ads before checkout'],
      sampleProduct: products.find((p) => p.storeName === 'Amazon India') || products[0],
    },
    {
      storeName: 'Flipkart',
      networkName: 'Flipkart Affiliate Program',
      logo: 'https://images.unsplash.com/photo-1578916171728-46686eac8d58?w=120&auto=format&fit=crop&q=80',
      cashbackRate: 'Up to 4.0% Cashback',
      trackingSpeed: '48 Hours',
      confirmationSpeed: '60 - 75 Days',
      userShare: '40% of Affiliate Payout',
      terms: 'Eligible on Electronics, Audio, TVs, Home appliances and Fashion. Orders must not be returned or cancelled.',
      dos: ['Check that cookies are enabled in your browser', 'Ensure order is delivered and return window passes'],
      donts: ['Do not place bulk or reseller purchases', 'Do not use corporate/employee coupon codes'],
      sampleProduct: products.find((p) => p.storeName === 'Flipkart') || products[1],
    },
    {
      storeName: 'Myntra',
      networkName: 'Cuelinks / Myntra Affiliate',
      logo: 'https://images.unsplash.com/photo-1441986300917-64674bd600d8?w=120&auto=format&fit=crop&q=80',
      cashbackRate: 'Flat 5.5% Cashback',
      trackingSpeed: '24 Hours',
      confirmationSpeed: '60 - 70 Days',
      userShare: '40% of Affiliate Payout',
      terms: 'Applies to all clothing, footwear, accessories and luxury cosmetics. Valid on both web and app redirected orders.',
      dos: ['Use official coupons listed on Me BUY MONEY', 'Keep return window receipt intact'],
      donts: ['Do not return or exchange items (exchanges void affiliate tracking)', 'Do not close tab during payment gateway redirect'],
      sampleProduct: products.find((p) => p.storeName === 'Myntra') || products[2],
    },
    {
      storeName: 'Ajio',
      networkName: 'Reliance Retail Affiliate',
      logo: 'https://images.unsplash.com/photo-1441986300917-64674bd600d8?w=120&auto=format&fit=crop&q=80',
      cashbackRate: 'Flat 6.0% Cashback',
      trackingSpeed: '48 Hours',
      confirmationSpeed: '60 - 80 Days',
      userShare: '40% of Affiliate Payout',
      terms: 'High payout on fashion brands, denim, ethnic wear and sneakers. Valid on prepaid and cash-on-delivery orders.',
      dos: ['Click Shop Now immediately before placing order', 'Verify your order receipt'],
      donts: ['Do not use unlisted third-party vouchers', 'Do not cancel part of a bundled order'],
      sampleProduct: products.find((p) => p.storeName === 'Ajio') || products[3],
    },
    {
      storeName: 'Mamaearth',
      networkName: 'Impact Radius',
      logo: 'https://images.unsplash.com/photo-1522335789203-aabd1fc54bc9?w=120&auto=format&fit=crop&q=80',
      cashbackRate: 'Flat 8.0% Cashback',
      trackingSpeed: '24 Hours',
      confirmationSpeed: '45 Days',
      userShare: '40% of Affiliate Payout',
      terms: 'Highest cashback on personal care, baby care, haircare and toxin-free cosmetics. Stackable with website promo codes.',
      dos: ['Combine with Mamaearth wallet cash', 'Enjoy fast 45-day payout confirmation'],
      donts: ['Do not apply non-affiliate influencer codes', 'Do not clear browser cache during checkout'],
      sampleProduct: products.find((p) => p.storeName === 'Mamaearth') || products[4],
    },
    {
      storeName: 'MakeMyTrip',
      networkName: 'Travel Affiliate Network',
      logo: 'https://images.unsplash.com/photo-1436491865332-7a61a109cc05?w=120&auto=format&fit=crop&q=80',
      cashbackRate: 'Flat ₹250 Cashback',
      trackingSpeed: '72 Hours',
      confirmationSpeed: '30 Days after travel date',
      userShare: '40% of Affiliate Payout',
      terms: 'Valid on domestic flight bookings across Indigo, Air India, Akasa & SpiceJet. Confirmed after successful travel completion.',
      dos: ['Book tickets directly after redirect', 'Save booking PNR in order claims if needed'],
      donts: ['Cancelled or rescheduled tickets do not qualify', 'Zero-commission flights are excluded'],
      sampleProduct: products.find((p) => p.storeName === 'MakeMyTrip') || products[5],
    },
  ];

  return (
    <div className="space-y-6 pb-20">
      <div className="space-y-1">
        <h1 className="text-xl sm:text-2xl font-extrabold text-slate-900 tracking-tight">
          Store Cashback Rates & Terms
        </h1>
        <p className="text-xs text-slate-500">
          Official commission splits, tracking timelines, and rules for 100+ partner stores
        </p>
      </div>

      <div className="space-y-4">
        {storeCatalog.map((st) => (
          <div
            key={st.storeName}
            className="bg-white rounded-2xl border border-slate-200/90 shadow-xs overflow-hidden"
          >
            {/* Store Header Strip */}
            <div className="p-5 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 border-b border-slate-100">
              <div className="flex items-center gap-4">
                <div className="w-14 h-14 rounded-2xl bg-slate-50 p-2.5 border border-slate-100 flex items-center justify-center">
                  <img
                    src={st.logo}
                    alt={st.storeName}
                    className="w-full h-full object-contain"
                  />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <h3 className="text-base font-bold text-slate-900">{st.storeName}</h3>
                    <span className="text-[10px] text-slate-400 font-medium">via {st.networkName}</span>
                  </div>
                  <div className="flex items-center gap-3 mt-1 text-xs">
                    <span className="font-extrabold text-emerald-600 bg-emerald-50 px-2.5 py-0.5 rounded-full">
                      {st.cashbackRate}
                    </span>
                    <span className="text-slate-500 text-[11px]">
                      Share: <strong>{st.userShare}</strong>
                    </span>
                  </div>
                </div>
              </div>

              {st.sampleProduct && (
                <button
                  onClick={() => onSelectProduct(st.sampleProduct)}
                  className="w-full sm:w-auto px-5 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold shadow-md shadow-emerald-500/20 flex items-center justify-center gap-2 transition-colors"
                >
                  <span>Activate Cashback</span>
                  <ExternalLink className="w-3.5 h-3.5" />
                </button>
              )}
            </div>

            {/* Tracking Timing Cards */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 p-4 bg-slate-50 text-xs">
              <div className="flex items-center gap-2.5">
                <Clock className="w-4 h-4 text-emerald-600 shrink-0" />
                <div>
                  <span className="text-slate-400 block text-[10px] font-bold uppercase">Tracking Speed</span>
                  <span className="text-slate-800 font-bold">{st.trackingSpeed}</span>
                </div>
              </div>
              <div className="flex items-center gap-2.5">
                <Calendar className="w-4 h-4 text-teal-600 shrink-0" />
                <div>
                  <span className="text-slate-400 block text-[10px] font-bold uppercase">Confirmation Period</span>
                  <span className="text-slate-800 font-bold">{st.confirmationSpeed}</span>
                </div>
              </div>
            </div>

            {/* Terms and Dos/Donts */}
            <div className="p-5 space-y-3 text-xs">
              <p className="text-slate-600 leading-relaxed">
                <strong>Applicability & Rules:</strong> {st.terms}
              </p>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
                <div className="bg-emerald-50/60 p-3 rounded-xl border border-emerald-100 space-y-1.5">
                  <div className="flex items-center gap-1.5 font-bold text-emerald-900 text-[11px]">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                    <span>Things to Do:</span>
                  </div>
                  <ul className="space-y-1 text-[11px] text-emerald-800">
                    {st.dos.map((d, i) => (
                      <li key={i}>• {d}</li>
                    ))}
                  </ul>
                </div>

                <div className="bg-rose-50/60 p-3 rounded-xl border border-rose-100 space-y-1.5">
                  <div className="flex items-center gap-1.5 font-bold text-rose-900 text-[11px]">
                    <XCircle className="w-3.5 h-3.5 text-rose-600" />
                    <span>Things to Avoid:</span>
                  </div>
                  <ul className="space-y-1 text-[11px] text-rose-800">
                    {st.donts.map((d, i) => (
                      <li key={i}>• {d}</li>
                    ))}
                  </ul>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
