import React, { useState } from 'react';
import { Category, Product } from '../types';
import { Tag, Filter, ArrowUpDown, ExternalLink, Star } from 'lucide-react';

interface CategoriesScreenProps {
  categories: Category[];
  products: Product[];
  selectedCategoryId: string;
  onSelectCategory: (categoryId: string) => void;
  onSelectProduct: (product: Product) => void;
}

export const CategoriesScreen: React.FC<CategoriesScreenProps> = ({
  categories,
  products,
  selectedCategoryId,
  onSelectCategory,
  onSelectProduct,
}) => {
  const [selectedStore, setSelectedStore] = useState<string>('all');
  const [sortBy, setSortBy] = useState<'cashback' | 'price-low' | 'price-high' | 'rating'>('cashback');

  const currentCategory = categories.find((c) => c.id === selectedCategoryId) || categories[0];

  // Filter products by selected category
  const filteredProducts = products.filter((p) => {
    const matchCat = p.categoryId === currentCategory?.id || p.categorySlug === currentCategory?.slug;
    const matchStore = selectedStore === 'all' || p.storeName === selectedStore;
    return matchCat && matchStore;
  });

  // Unique stores in this category
  const categoryStores = Array.from(
    new Set(
      products
        .filter((p) => p.categoryId === currentCategory?.id || p.categorySlug === currentCategory?.slug)
        .map((p) => p.storeName)
    )
  );

  // Sorting
  const sortedProducts = [...filteredProducts].sort((a, b) => {
    if (sortBy === 'cashback') return b.cashbackRate - a.cashbackRate;
    if (sortBy === 'price-low') return a.dealPrice - b.dealPrice;
    if (sortBy === 'price-high') return b.dealPrice - a.dealPrice;
    if (sortBy === 'rating') return (b.rating || 0) - (a.rating || 0);
    return 0;
  });

  return (
    <div className="space-y-6 pb-20">
      {/* Category header */}
      <div className="space-y-1">
        <h1 className="text-xl sm:text-2xl font-extrabold text-slate-900 tracking-tight">
          Shopping Categories
        </h1>
        <p className="text-xs text-slate-500">
          Browse verified deals and compare cashback percentages across top Indian retailers
        </p>
      </div>

      {/* Category Pills horizontal scroll */}
      <div className="flex gap-2 overflow-x-auto pb-2 scrollbar-none">
        {categories.map((cat) => {
          const isSelected = cat.id === currentCategory?.id;
          return (
            <button
              key={cat.id}
              onClick={() => {
                onSelectCategory(cat.id);
                setSelectedStore('all');
              }}
              className={`px-4 py-2.5 rounded-xl text-xs font-bold whitespace-nowrap shrink-0 flex items-center gap-2 transition-all ${
                isSelected
                  ? 'bg-emerald-600 text-white shadow-md shadow-emerald-600/20'
                  : 'bg-white text-slate-700 border border-slate-200 hover:border-slate-300'
              }`}
            >
              <Tag className="w-3.5 h-3.5" />
              <span>{cat.name}</span>
            </button>
          );
        })}
      </div>

      {/* Store Filter & Sort Toolbar */}
      <div className="bg-white p-3.5 rounded-2xl border border-slate-200/80 shadow-xs flex flex-wrap items-center justify-between gap-3">
        {/* Stores filter */}
        <div className="flex items-center gap-2 overflow-x-auto text-xs">
          <span className="text-slate-400 font-semibold shrink-0">Store:</span>
          <button
            onClick={() => setSelectedStore('all')}
            className={`px-2.5 py-1 rounded-lg font-medium shrink-0 ${
              selectedStore === 'all'
                ? 'bg-slate-900 text-white'
                : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
            }`}
          >
            All Stores
          </button>
          {categoryStores.map((st) => (
            <button
              key={st}
              onClick={() => setSelectedStore(st)}
              className={`px-2.5 py-1 rounded-lg font-medium shrink-0 ${
                selectedStore === st
                  ? 'bg-slate-900 text-white'
                  : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
              }`}
            >
              {st}
            </button>
          ))}
        </div>

        {/* Sort selector */}
        <div className="flex items-center gap-2 text-xs">
          <ArrowUpDown className="w-3.5 h-3.5 text-slate-400" />
          <span className="text-slate-500 font-medium">Sort:</span>
          <select
            value={sortBy}
            onChange={(e) => setSortBy(e.target.value as any)}
            className="bg-slate-100 text-slate-700 border border-slate-200 text-xs font-semibold rounded-lg px-2 py-1 outline-none focus:ring-1 focus:ring-emerald-500"
          >
            <option value="cashback">Highest Cashback</option>
            <option value="price-low">Price: Low to High</option>
            <option value="price-high">Price: High to Low</option>
            <option value="rating">Customer Rating</option>
          </select>
        </div>
      </div>

      {/* Product List */}
      {sortedProducts.length === 0 ? (
        <div className="bg-white rounded-2xl p-12 text-center border border-slate-200/80 space-y-3">
          <div className="w-14 h-14 bg-slate-100 rounded-full flex items-center justify-center mx-auto text-slate-400">
            <Tag className="w-6 h-6" />
          </div>
          <h3 className="text-base font-bold text-slate-800">No deals found</h3>
          <p className="text-xs text-slate-500 max-w-sm mx-auto">
            We currently don't have active deals under {currentCategory?.name} for the selected filter. Try switching stores or category!
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {sortedProducts.map((prod) => {
            const savings = prod.originalPrice - prod.dealPrice;
            const discountPct = Math.round((savings / prod.originalPrice) * 100);

            return (
              <div
                key={prod.id}
                className="bg-white rounded-2xl border border-slate-200/80 overflow-hidden hover:shadow-lg transition-all flex flex-col justify-between"
              >
                <div className="p-4 space-y-3">
                  <div className="flex gap-4">
                    <div className="relative w-24 h-24 shrink-0 rounded-xl overflow-hidden bg-slate-50 border border-slate-100">
                      <img
                        src={prod.imageUrl}
                        alt={prod.title}
                        className="w-full h-full object-cover"
                      />
                      {discountPct > 0 && (
                        <span className="absolute top-1 left-1 bg-rose-600 text-white font-extrabold text-[9px] px-1.5 py-0.5 rounded shadow">
                          {discountPct}% OFF
                        </span>
                      )}
                    </div>

                    <div className="flex-1 min-w-0 space-y-1">
                      <div className="flex items-center justify-between">
                        <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400">
                          {prod.storeName}
                        </span>
                        {prod.rating && (
                          <div className="flex items-center gap-1 text-[11px] font-bold text-amber-600 bg-amber-50 px-1.5 py-0.2 rounded">
                            <Star className="w-3 h-3 fill-amber-500 text-amber-500" />
                            <span>{prod.rating}</span>
                          </div>
                        )}
                      </div>

                      <h3 className="text-xs font-bold text-slate-900 line-clamp-2 leading-snug">
                        {prod.title}
                      </h3>

                      <div className="flex items-baseline gap-2 pt-0.5">
                        <span className="text-base font-extrabold text-slate-900">
                          ₹{prod.dealPrice.toLocaleString('en-IN')}
                        </span>
                        {prod.originalPrice > prod.dealPrice && (
                          <span className="text-xs text-slate-400 line-through">
                            ₹{prod.originalPrice.toLocaleString('en-IN')}
                          </span>
                        )}
                      </div>
                    </div>
                  </div>

                  {/* Cashback Callout */}
                  <div className="bg-emerald-50 border border-emerald-200/80 rounded-xl p-2.5 flex items-center justify-between">
                    <div>
                      <span className="block text-[9px] uppercase font-bold text-emerald-700 tracking-wider">
                        Cashback Reward
                      </span>
                      <span className="text-xs font-extrabold text-emerald-900">
                        {prod.cashbackLabel}
                      </span>
                    </div>
                    <div className="text-right">
                      <span className="block text-[9px] uppercase font-bold text-slate-400 tracking-wider">
                        Effective Price
                      </span>
                      <span className="text-xs font-black text-slate-800">
                        ₹
                        {prod.cashbackType === 'flat'
                          ? Math.max(0, prod.dealPrice - prod.cashbackRate).toLocaleString('en-IN')
                          : Math.round(prod.dealPrice * (1 - prod.cashbackRate / 100)).toLocaleString('en-IN')}
                      </span>
                    </div>
                  </div>
                </div>

                {/* Footer action */}
                <div className="p-3 bg-slate-50 border-t border-slate-100 flex items-center justify-between">
                  {prod.couponCode ? (
                    <span className="text-[11px] font-mono text-emerald-700 bg-emerald-100/70 px-2 py-0.5 rounded font-bold">
                      Code: {prod.couponCode}
                    </span>
                  ) : (
                    <span className="text-[10px] text-slate-400">Tracked via Affiliate Link</span>
                  )}
                  <button
                    onClick={() => onSelectProduct(prod)}
                    className="py-1.5 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold shadow-sm flex items-center gap-1.5 transition-colors"
                  >
                    <span>Shop Now</span>
                    <ExternalLink className="w-3 h-3" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
