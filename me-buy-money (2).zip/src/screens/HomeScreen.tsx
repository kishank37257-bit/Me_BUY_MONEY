import React, { useState, useEffect } from 'react';
import {
  ArrowRight,
  Zap,
  Wallet as WalletIcon,
  Link2,
  Inbox,
  Copy,
  Check,
  Gift,
  ShoppingBag,
  History,
  Tag,
  ChevronRight,
  Shield,
  ExternalLink,
} from 'lucide-react';
import { Product, Category, AffiliateNetwork, Banner, ScreenTab, PremiumDeal } from '../types';
import { useAuth } from '../context/AuthContext';
import { getPremiumDeals } from '../services/dbService';
import { HomePremiumDealsSection } from '../components/HomePremiumDealsSection';

interface HomeScreenProps {
  banners: Banner[];
  categories: Category[];
  products: Product[];
  networks: AffiliateNetwork[];
  onSelectProduct: (product: Product) => void;
  onSelectCategory: (categoryId: string) => void;
  onNavigate: (tab: ScreenTab) => void;
}

export const HomeScreen: React.FC<HomeScreenProps> = ({
  banners,
  categories,
  products,
  networks,
  onSelectProduct,
  onSelectCategory,
  onNavigate,
}) => {
  const { profile, wallet, currentUser, signInWithGoogle, openAuthModal } = useAuth();
  const [activeBannerIdx, setActiveBannerIdx] = useState(0);
  const [copiedReferral, setCopiedReferral] = useState(false);
  const [premiumDeals, setPremiumDeals] = useState<PremiumDeal[]>([]);

  // Load premium deals for Home display
  useEffect(() => {
    getPremiumDeals().then(setPremiumDeals).catch(console.error);
  }, []);

  // Auto rotate hero banner
  useEffect(() => {
    if (banners.length <= 1) return;
    const interval = setInterval(() => {
      setActiveBannerIdx((prev) => (prev + 1) % banners.length);
    }, 5000);
    return () => clearInterval(interval);
  }, [banners.length]);

  const currentBanner = banners[activeBannerIdx] || banners[0];

  return (
    <div className="space-y-4 pb-24 max-w-md mx-auto px-1 sm:px-0">
      {/* MOBILE LOGIN BANNER FOR GUEST USERS */}
      {!currentUser && (
        <div className="bg-gradient-to-r from-emerald-950 via-teal-950 to-slate-900 border border-emerald-500/30 text-white rounded-3xl p-4 shadow-md space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <span className="text-xl">👋</span>
              <div>
                <h3 className="text-xs font-black text-white">Login for Personal Rewards</h3>
                <p className="text-[10px] text-emerald-300">Sign in with Google ya Gmail & Password</p>
              </div>
            </div>
            <span className="bg-emerald-500/20 text-emerald-300 border border-emerald-400/30 text-[9px] font-black px-2 py-0.5 rounded-full uppercase">
              +₹50 Bonus
            </span>
          </div>

          <div className="grid grid-cols-2 gap-2 text-xs">
            <button
              onClick={signInWithGoogle}
              className="py-2.5 px-3 rounded-2xl bg-white text-slate-900 font-extrabold flex items-center justify-center gap-2 shadow-xs active:scale-95 transition-transform"
            >
              <svg className="w-4 h-4 shrink-0" viewBox="0 0 24 24">
                <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/>
                <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/>
                <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"/>
                <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"/>
              </svg>
              <span className="text-[11px] truncate">Google Login</span>
            </button>
            <button
              onClick={() => openAuthModal('signin')}
              className="py-2.5 px-3 rounded-2xl bg-emerald-600 hover:bg-emerald-500 text-white font-extrabold flex items-center justify-center gap-1.5 shadow-xs active:scale-95 transition-transform"
            >
              <span className="text-[11px] truncate">Gmail & Password</span>
              <span>&rarr;</span>
            </button>
          </div>
        </div>
      )}

      {/* ACCOUNT SUMMARY CARD - Clean, Mobile-First */}
      <div className="bg-gradient-to-r from-emerald-900 via-teal-900 to-slate-900 text-white rounded-3xl p-4 sm:p-5 shadow-lg shadow-emerald-950/20 space-y-3">
        <div className="flex items-center justify-between">
          <div className="space-y-0.5">
            <span className="text-[10px] font-bold text-emerald-300 uppercase tracking-wider">
              Me BUY MONEY Account
            </span>
            <h2 className="text-lg font-black text-white">
              Hello, {profile?.displayName?.split(' ')[0] || 'Shopper'} 👋
            </h2>
          </div>

          <button
            onClick={() => onNavigate('wallet')}
            className="flex items-center gap-2 bg-white/10 hover:bg-white/20 backdrop-blur-md border border-white/15 px-3 py-1.5 rounded-2xl transition-all"
          >
            <WalletIcon className="w-4 h-4 text-emerald-400" />
            <div className="text-right">
              <span className="text-[9px] uppercase font-bold text-slate-300 block">Balance</span>
              <span className="text-sm font-black text-white font-mono">
                ₹{(wallet?.availableBalance ?? 0).toLocaleString('en-IN', { minimumFractionDigits: 2 })}
              </span>
            </div>
          </button>
        </div>

        {/* Quick Launch Action Pills */}
        <div className="grid grid-cols-3 gap-2 pt-1 text-xs font-bold">
          <button
            onClick={() => onNavigate('reward-link')}
            className="flex items-center justify-center gap-1.5 py-2.5 px-2 rounded-2xl bg-emerald-500/25 hover:bg-emerald-500/35 text-emerald-200 border border-emerald-400/30 transition-all active:scale-95"
          >
            <Link2 className="w-3.5 h-3.5 stroke-[2.5]" />
            <span className="text-[11px] truncate">Reward Link</span>
          </button>
          <button
            onClick={() => onNavigate('inbox')}
            className="flex items-center justify-center gap-1.5 py-2.5 px-2 rounded-2xl bg-white/10 hover:bg-white/15 text-slate-200 border border-white/10 transition-all active:scale-95"
          >
            <Inbox className="w-3.5 h-3.5" />
            <span className="text-[11px] truncate">My Inbox</span>
          </button>
          <button
            onClick={() => onNavigate('history')}
            className="flex items-center justify-center gap-1.5 py-2.5 px-2 rounded-2xl bg-white/10 hover:bg-white/15 text-slate-200 border border-white/10 transition-all active:scale-95"
          >
            <History className="w-3.5 h-3.5" />
            <span className="text-[11px] truncate">History</span>
          </button>
        </div>
      </div>

      {/* Hero Banner Card */}
      {currentBanner && (
        <div className="relative rounded-3xl overflow-hidden shadow-lg shadow-slate-900/10 min-h-[170px] sm:min-h-[190px] flex items-center bg-slate-950">
          <img
            src={currentBanner.imageUrl}
            alt={currentBanner.title}
            className="absolute inset-0 w-full h-full object-cover opacity-35 mix-blend-overlay"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-slate-950 via-slate-900/85 to-transparent" />

          <div className="relative z-10 p-5 text-white space-y-2">
            <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-emerald-500/20 border border-emerald-400/40 text-emerald-300 text-[10px] font-bold tracking-wide uppercase">
              <Zap className="w-3 h-3 fill-emerald-400 text-emerald-400" />
              <span>{currentBanner.badge}</span>
            </span>
            <h1 className="text-xl font-black tracking-tight leading-snug">
              {currentBanner.title}
            </h1>
            <p className="text-[11px] text-slate-300 line-clamp-2">
              {currentBanner.subtitle}
            </p>
            <div className="pt-1 flex items-center gap-2">
              <button
                onClick={() => onNavigate('reward-link')}
                className="px-4 py-2 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-600 hover:to-teal-600 text-white text-xs font-extrabold shadow-md shadow-emerald-500/30 flex items-center gap-1.5 transition-all"
              >
                <span>Paste Product Link</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>

          {/* Carousel dots */}
          <div className="absolute bottom-3 right-4 z-10 flex gap-1">
            {banners.map((_, idx) => (
              <button
                key={idx}
                onClick={() => setActiveBannerIdx(idx)}
                className={`h-1.5 rounded-full transition-all ${
                  idx === activeBannerIdx ? 'w-4 bg-emerald-400' : 'w-1.5 bg-white/40'
                }`}
              />
            ))}
          </div>
        </div>
      )}

      {/* PREMIUM DEALS SECTION - Home Embedded with Category Filter & Live Timers */}
      <HomePremiumDealsSection deals={premiumDeals} />



      {/* Shopping Categories */}
      <div className="space-y-2">
        <div className="flex items-center justify-between">
          <h2 className="text-sm font-black text-slate-900 tracking-tight">Shop by Category</h2>
          <button
            onClick={() => onNavigate('categories')}
            className="text-[11px] font-bold text-emerald-700 hover:text-emerald-800 flex items-center gap-0.5"
          >
            <span>View All</span>
            <ChevronRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="grid grid-cols-3 gap-2">
          {categories.slice(0, 6).map((cat) => (
            <div
              key={cat.id}
              onClick={() => {
                onSelectCategory(cat.id);
                onNavigate('categories');
              }}
              className="bg-white p-3 rounded-2xl border border-slate-200/80 hover:border-emerald-500 hover:shadow-xs cursor-pointer transition-all flex flex-col items-center text-center group active:scale-95"
            >
              <div className="w-9 h-9 rounded-xl bg-emerald-50 text-emerald-700 flex items-center justify-center mb-1 group-hover:bg-emerald-600 group-hover:text-white transition-colors">
                <Tag className="w-4 h-4" />
              </div>
              <span className="text-[11px] font-bold text-slate-800 group-hover:text-emerald-700 truncate w-full">
                {cat.name}
              </span>
            </div>
          ))}
        </div>
      </div>

      {/* Interactive 4-Step Process Guide ("how to work wala Rahane Dena") */}
      <div className="bg-gradient-to-br from-emerald-900 via-teal-900 to-slate-900 text-white rounded-3xl p-5 space-y-4 shadow-xl">
        <div className="text-center space-y-1">
          <span className="text-emerald-400 text-[10px] font-bold uppercase tracking-wider">
            Simple 4-Step Process
          </span>
          <h3 className="text-base font-black">How Me BUY MONEY Works</h3>
          <p className="text-[11px] text-slate-300">
            Earn real cash over and above store discounts and card offers!
          </p>
        </div>

        <div className="grid grid-cols-2 gap-2.5">
          <div className="bg-white/10 backdrop-blur-md p-3 rounded-2xl border border-white/10 space-y-1">
            <div className="w-6 h-6 rounded-lg bg-emerald-500 text-white font-extrabold flex items-center justify-center text-xs">
              1
            </div>
            <h4 className="text-[11px] font-bold text-white">Paste Product Link</h4>
            <p className="text-[10px] text-slate-300 leading-relaxed">
              Copy any item link on Amazon, Flipkart, Myntra & submit in Reward Link.
            </p>
          </div>

          <div className="bg-white/10 backdrop-blur-md p-3 rounded-2xl border border-white/10 space-y-1">
            <div className="w-6 h-6 rounded-lg bg-emerald-500 text-white font-extrabold flex items-center justify-center text-xs">
              2
            </div>
            <h4 className="text-[11px] font-bold text-white">Receive in Inbox</h4>
            <p className="text-[10px] text-slate-300 leading-relaxed">
              Tracked affiliate link arrives in your <strong>Inbox</strong> within seconds.
            </p>
          </div>

          <div className="bg-white/10 backdrop-blur-md p-3 rounded-2xl border border-white/10 space-y-1">
            <div className="w-6 h-6 rounded-lg bg-emerald-500 text-white font-extrabold flex items-center justify-center text-xs">
              3
            </div>
            <h4 className="text-[11px] font-bold text-white">Cashback Tracks</h4>
            <p className="text-[10px] text-slate-300 leading-relaxed">
              Order tracks automatically into your <strong>History</strong> in 24-48 hours.
            </p>
          </div>

          <div className="bg-white/10 backdrop-blur-md p-3 rounded-2xl border border-white/10 space-y-1">
            <div className="w-6 h-6 rounded-lg bg-emerald-500 text-white font-extrabold flex items-center justify-center text-xs">
              4
            </div>
            <h4 className="text-[11px] font-bold text-white">Withdraw to Bank/UPI</h4>
            <p className="text-[10px] text-slate-300 leading-relaxed">
              Once confirmed, transfer your money straight to UPI or Bank account.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
