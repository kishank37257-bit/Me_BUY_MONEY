import React, { useState } from 'react';
import { Search as SearchIcon, X, SlidersHorizontal, ExternalLink, Tag } from 'lucide-react';
import { Product } from '../types';

interface SearchScreenProps {
  products: Product[];
  onSelectProduct: (product: Product) => void;
}

export const SearchScreen: React.FC<SearchScreenProps> = ({ products, onSelectProduct }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [storeFilter, setStoreFilter] = useState('all');
  const [minCashback, setMinCashback] = useState(0);

  const stores = Array.from(new Set(products.map((p) => p.storeName)));

  const filtered = products.filter((p) => {
    const matchesSearch =
      searchTerm === '' ||
      p.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      p.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
      p.storeName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      p.categorySlug.toLowerCase().includes(searchTerm.toLowerCase());

    const matchesStore = storeFilter === 'all' || p.storeName === storeFilter;
    const matchesCashback = p.cashbackRate >= minCashback;

    return matchesSearch && matchesStore && matchesCashback;
  });

  return (
    <div className="space-y-6 pb-20">
      {/* Search Bar */}
      <div className="relative">
        <SearchIcon className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
        <input
          type="text"
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          placeholder="Search products, brands (iPhone, Shoes, Headphones, Amazon)..."
          className="w-full pl-12 pr-10 py-3.5 bg-white border border-slate-200 rounded-2xl text-sm font-medium text-slate-800 placeholder-slate-400 shadow-sm outline-none focus:ring-2 focus:ring-emerald-500/30 focus:border-emerald-500"
          autoFocus
        />
        {searchTerm && (
          <button
            onClick={() => setSearchTerm('')}
            className="absolute right-4 top-1/2 -translate-y-1/2 p-1 text-slate-400 hover:text-slate-600 rounded-full"
          >
            <X className="w-4 h-4" />
          </button>
        )}
      </div>

      {/* Quick Filters */}
      <div className="flex flex-wrap items-center gap-2 text-xs">
        <span className="text-slate-400 font-semibold flex items-center gap-1">
          <SlidersHorizontal className="w-3.5 h-3.5" />
          <span>Filters:</span>
        </span>

        <button
          onClick={() => {
            setStoreFilter('all');
            setMinCashback(0);
          }}
          className={`px-3 py-1.5 rounded-xl font-medium ${
            storeFilter === 'all' && minCashback === 0
              ? 'bg-slate-900 text-white'
              : 'bg-white text-slate-600 border border-slate-200'
          }`}
        >
          All
        </button>

        <button
          onClick={() => setMinCashback(minCashback === 5 ? 0 : 5)}
          className={`px-3 py-1.5 rounded-xl font-medium ${
            minCashback === 5
              ? 'bg-emerald-600 text-white'
              : 'bg-white text-slate-600 border border-slate-200'
          }`}
        >
          🔥 5%+ Cashback
        </button>

        {stores.map((st) => (
          <button
            key={st}
            onClick={() => setStoreFilter(storeFilter === st ? 'all' : st)}
            className={`px-3 py-1.5 rounded-xl font-medium ${
              storeFilter === st
                ? 'bg-slate-900 text-white'
                : 'bg-white text-slate-600 border border-slate-200'
            }`}
          >
            {st}
          </button>
        ))}
      </div>

      {/* Results Header */}
      <div className="flex items-center justify-between text-xs text-slate-500">
        <span>
          Showing <strong>{filtered.length}</strong> matching offers
        </span>
        {searchTerm && (
          <span>
            Query: "<span className="text-slate-900 font-medium">{searchTerm}</span>"
          </span>
        )}
      </div>

      {/* Results Grid */}
      {filtered.length === 0 ? (
        <div className="bg-white rounded-2xl p-12 text-center border border-slate-200 space-y-3">
          <div className="w-12 h-12 bg-slate-100 rounded-full flex items-center justify-center mx-auto text-slate-400">
            <SearchIcon className="w-5 h-5" />
          </div>
          <h3 className="text-sm font-bold text-slate-800">No matching products found</h3>
          <p className="text-xs text-slate-500 max-w-sm mx-auto">
            Try checking for spelling mistakes or clear some filters to see all available deals.
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {filtered.map((prod) => (
            <div
              key={prod.id}
              className="bg-white rounded-2xl border border-slate-200/80 overflow-hidden hover:shadow-md transition-all p-4 space-y-3 flex flex-col justify-between"
            >
              <div className="flex gap-4">
                <img
                  src={prod.imageUrl}
                  alt={prod.title}
                  className="w-20 h-20 rounded-xl object-cover bg-slate-50 border border-slate-100 shrink-0"
                />
                <div className="flex-1 min-w-0 space-y-1">
                  <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400">
                    {prod.storeName}
                  </span>
                  <h4 className="text-xs font-bold text-slate-900 line-clamp-2 leading-snug">
                    {prod.title}
                  </h4>
                  <div className="flex items-baseline gap-2 pt-0.5">
                    <span className="text-sm font-extrabold text-slate-900">
                      ₹{prod.dealPrice.toLocaleString('en-IN')}
                    </span>
                    {prod.originalPrice > prod.dealPrice && (
                      <span className="text-xs text-slate-400 line-through">
                        ₹{prod.originalPrice.toLocaleString('en-IN')}
                      </span>
                    )}
                  </div>
                </div>
              </div>

              <div className="bg-emerald-50 rounded-xl p-2.5 flex items-center justify-between">
                <div>
                  <span className="block text-[9px] uppercase font-bold text-emerald-700">Cashback</span>
                  <span className="text-xs font-bold text-emerald-900">{prod.cashbackLabel}</span>
                </div>
                <button
                  onClick={() => onSelectProduct(prod)}
                  className="py-1 px-3 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold shadow-xs flex items-center gap-1 transition-colors"
                >
                  <span>Shop</span>
                  <ExternalLink className="w-3 h-3" />
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
