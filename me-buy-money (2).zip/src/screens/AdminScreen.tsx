import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import {
  Shield,
  Users,
  MousePointer,
  FileSpreadsheet,
  Clock,
  CheckCircle2,
  ArrowUpRight,
  DollarSign,
  TrendingUp,
  RefreshCw,
  Plus,
  Check,
  X,
  Edit,
  Download,
  AlertTriangle,
  Lock,
  Layers,
  Settings,
  Bell,
  Search,
  Link2,
  Send,
  ExternalLink,
  Copy,
  Sparkles,
  Zap,
} from 'lucide-react';
import {
  getAdminDashboardStats,
  getAllTransactions,
  getAllWithdrawals,
  getAllAuditLogs,
  reconcileTransactionStatus,
  processWithdrawalRequest,
  saveProduct,
  saveAffiliateNetwork,
  updatePlatformSettings,
  getPlatformSettings,
  addNotification,
  getAllRewardLinkRequests,
  adminSendRewardLink,
  adminRejectRewardLink,
} from '../services/dbService';
import {
  Transaction,
  WithdrawalRequest,
  AuditLog,
  Product,
  AffiliateNetwork,
  PlatformSettings,
  OrderStatus,
  WithdrawalStatus,
  RewardLinkRequest,
} from '../types';

interface AdminScreenProps {
  products: Product[];
  networks: AffiliateNetwork[];
  onRefreshCatalog: () => void;
}

export const AdminScreen: React.FC<AdminScreenProps> = ({
  products,
  networks,
  onRefreshCatalog,
}) => {
  const { profile, isAdmin, openAuthModal } = useAuth();
  const [activeTab, setActiveTab] = useState<
    'queue' | 'stats' | 'transactions' | 'withdrawals' | 'products' | 'networks' | 'settings' | 'logs'
  >('queue');

  const [stats, setStats] = useState({
    totalUsers: 1,
    totalClicks: 0,
    totalTransactions: 0,
    pendingCashback: 0,
    confirmedCashback: 0,
    totalWithdrawn: 0,
    grossCommission: 0,
    platformRevenue: 0,
  });

  const [rewardRequests, setRewardRequests] = useState<RewardLinkRequest[]>([]);
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [withdrawals, setWithdrawals] = useState<WithdrawalRequest[]>([]);
  const [auditLogs, setAuditLogs] = useState<AuditLog[]>([]);
  const [settings, setSettings] = useState<PlatformSettings | null>(null);
  const [loading, setLoading] = useState(true);
  const [actionMessage, setActionMessage] = useState<string | null>(null);

  // Reward Link Queue state
  const [activeAffiliateInput, setActiveAffiliateInput] = useState<{ [reqId: string]: string }>({});
  const [activeNotesInput, setActiveNotesInput] = useState<{ [reqId: string]: string }>({});
  const [rejectingReqId, setRejectingReqId] = useState<string | null>(null);
  const [rejectionReasonInput, setRejectionReasonInput] = useState('');
  const [copiedUrlReqId, setCopiedUrlReqId] = useState<string | null>(null);

  // Modals / forms
  const [reconcileModalTxn, setReconcileModalTxn] = useState<Transaction | null>(null);
  const [newStatus, setNewStatus] = useState<OrderStatus>('Cashback Confirmed');
  const [reconcileReason, setReconcileReason] = useState('');
  const [reconcileCommission, setReconcileCommission] = useState('');

  // Payout modal
  const [payoutModalWth, setPayoutModalWth] = useState<WithdrawalRequest | null>(null);
  const [payoutStatus, setPayoutStatus] = useState<WithdrawalStatus>('Paid');
  const [payoutUtr, setPayoutUtr] = useState('');
  const [payoutNotes, setPayoutNotes] = useState('');

  // New product form
  const [showProductModal, setShowProductModal] = useState(false);
  const [newProdTitle, setNewProdTitle] = useState('');
  const [newProdStore, setNewProdStore] = useState('Amazon India');
  const [newProdOriginalPrice, setNewProdOriginalPrice] = useState('1999');
  const [newProdDealPrice, setNewProdDealPrice] = useState('999');
  const [newProdCashbackRate, setNewProdCashbackRate] = useState('4.0');
  const [newProdCashbackLabel, setNewProdCashbackLabel] = useState('Earn 4% Cashback');
  const [newProdAffiliateUrl, setNewProdAffiliateUrl] = useState('https://www.amazon.in/dp/example?tag=ansora-21&subid={SUB_ID}');
  const [newProdImageUrl, setNewProdImageUrl] = useState('https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=500&auto=format&fit=crop&q=80');

  useEffect(() => {
    loadAllData();

    // Auto-refresh reward requests queue every 3 seconds
    const interval = setInterval(async () => {
      try {
        const reqs = await getAllRewardLinkRequests();
        setRewardRequests(reqs);
      } catch {
        // Silent background catch
      }
    }, 3000);

    return () => clearInterval(interval);
  }, []);

  const loadAllData = async () => {
    setLoading(true);
    try {
      const [reqs, s, txns, wths, logs, setts] = await Promise.all([
        getAllRewardLinkRequests(),
        getAdminDashboardStats(),
        getAllTransactions(),
        getAllWithdrawals(),
        getAllAuditLogs(),
        getPlatformSettings(),
      ]);
      setRewardRequests(reqs);
      setStats(s);
      setTransactions(txns);
      setWithdrawals(wths);
      setAuditLogs(logs);
      setSettings(setts);
    } catch (e) {
      console.error('Failed loading admin data:', e);
    } finally {
      setLoading(false);
    }
  };

  // Helper to format elapsed time
  const getElapsedTime = (isoString: string) => {
    const elapsedSeconds = Math.max(0, Math.floor((Date.now() - new Date(isoString).getTime()) / 1000));
    if (elapsedSeconds < 60) return `${elapsedSeconds}s ago`;
    const mins = Math.floor(elapsedSeconds / 60);
    if (mins < 60) return `${mins}m ago`;
    const hours = Math.floor(mins / 60);
    if (hours < 24) return `${hours}h ago`;
    return `${Math.floor(hours / 24)}d ago`;
  };

  // Quick helper to auto-generate affiliate tracked link with standard tags
  const generateHelperLink = (req: RewardLinkRequest) => {
    const subid = `MBM_${req.userId.slice(0, 4)}_${Date.now().toString(36)}`;
    const separator = req.productUrl.includes('?') ? '&' : '?';
    let tag = 'mebuymoney-21';
    if (req.storeName.toLowerCase().includes('flipkart')) tag = 'mbmflip';
    if (req.storeName.toLowerCase().includes('myntra')) tag = 'mbmmynt';
    return `${req.productUrl}${separator}tag=${tag}&subid=${subid}`;
  };

  const handleSendLink = async (requestId: string) => {
    const affiliateUrl = activeAffiliateInput[requestId];
    if (!affiliateUrl || !affiliateUrl.trim()) {
      alert('Please enter or generate a valid affiliate tracking link');
      return;
    }
    if (!profile) return;

    try {
      await adminSendRewardLink(
        requestId,
        affiliateUrl.trim(),
        profile.email,
        activeNotesInput[requestId] || 'Approved by admin'
      );
      setActionMessage(`Reward link for ${requestId} sent to user inbox successfully!`);
      await loadAllData();
      setTimeout(() => setActionMessage(null), 3500);
    } catch (err: any) {
      alert('Error sending reward link: ' + err.message);
    }
  };

  const handleRejectLink = async (requestId: string) => {
    if (!rejectionReasonInput.trim()) {
      alert('Please specify a rejection reason (e.g. merchant does not support cashback, out of stock, invalid URL).');
      return;
    }
    if (!profile) return;

    try {
      await adminRejectRewardLink(requestId, rejectionReasonInput.trim(), profile.email);
      setActionMessage(`Request ${requestId} rejected.`);
      setRejectingReqId(null);
      setRejectionReasonInput('');
      await loadAllData();
      setTimeout(() => setActionMessage(null), 3500);
    } catch (err: any) {
      alert('Error rejecting request: ' + err.message);
    }
  };

  const handleCopyOriginalUrl = (url: string, id: string) => {
    navigator.clipboard.writeText(url);
    setCopiedUrlReqId(id);
    setTimeout(() => setCopiedUrlReqId(null), 2000);
  };

  const handleReconcileSubmit = async () => {
    if (!reconcileModalTxn || !profile) return;
    try {
      const commissionNum = reconcileCommission
        ? parseFloat(reconcileCommission)
        : reconcileModalTxn.affiliateCommission;

      await reconcileTransactionStatus(reconcileModalTxn.id, newStatus, profile.email, {
        affiliateCommission: commissionNum,
        rejectionReason: reconcileReason,
      });

      setActionMessage(`Transaction ${reconcileModalTxn.id} updated to ${newStatus}! User wallet adjusted.`);
      setReconcileModalTxn(null);
      await loadAllData();
      setTimeout(() => setActionMessage(null), 3000);
    } catch (err: any) {
      alert('Error updating transaction: ' + err.message);
    }
  };

  const handlePayoutSubmit = async () => {
    if (!payoutModalWth || !profile) return;
    try {
      await processWithdrawalRequest(
        payoutModalWth.id,
        payoutStatus,
        profile.email,
        payoutUtr,
        payoutNotes
      );
      setActionMessage(`Withdrawal ${payoutModalWth.id} marked as ${payoutStatus}!`);
      setPayoutModalWth(null);
      await loadAllData();
      setTimeout(() => setActionMessage(null), 3000);
    } catch (err: any) {
      alert('Error processing withdrawal: ' + err.message);
    }
  };

  const handleCreateProduct = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!profile) return;
    const id = `prod_${Date.now()}`;
    const newProduct: Product = {
      id,
      title: newProdTitle,
      description: 'Admin added affiliate deal with verified cashback rate.',
      networkId: networks[0]?.id || 'net_amazon',
      storeName: newProdStore,
      storeLogo: 'https://images.unsplash.com/photo-1523474255658-4af61825044d?w=100&auto=format&fit=crop&q=80',
      categoryId: 'cat_electronics',
      categorySlug: 'electronics',
      originalPrice: parseFloat(newProdOriginalPrice) || 1999,
      dealPrice: parseFloat(newProdDealPrice) || 999,
      cashbackRate: parseFloat(newProdCashbackRate) || 4.0,
      cashbackType: 'percent',
      cashbackLabel: newProdCashbackLabel,
      affiliateUrl: newProdAffiliateUrl,
      imageUrl: newProdImageUrl,
      isHotDeal: true,
      rating: 4.5,
      totalClicks: 0,
      termsAndConditions: 'Cashback tracked within 48h. Valid for all users.',
      status: 'active',
      createdAt: new Date().toISOString(),
    };

    try {
      await saveProduct(newProduct, profile.email);
      setShowProductModal(false);
      onRefreshCatalog();
      setActionMessage(`Product "${newProdTitle}" added to catalog!`);
      setTimeout(() => setActionMessage(null), 3000);
    } catch (e: any) {
      alert('Error creating product: ' + e.message);
    }
  };

  const handleExportCSV = (type: 'transactions' | 'withdrawals' | 'requests') => {
    let headers: string[] = [];
    let rows: any[] = [];

    if (type === 'requests') {
      headers = ['Request ID', 'User Email', 'Store', 'Original URL', 'Affiliate URL', 'Status', 'Submitted At', 'Clicks'];
      rows = rewardRequests.map((r) => [
        r.id,
        r.userEmail,
        r.storeName,
        `"${r.productUrl.replace(/"/g, '""')}"`,
        `"${(r.affiliateUrl || '').replace(/"/g, '""')}"`,
        r.status,
        r.submittedAt,
        r.clickCount,
      ]);
    } else if (type === 'transactions') {
      headers = ['ID', 'User Email', 'Store', 'Product', 'Order Amount', 'Commission', 'User Cashback (40%)', 'Platform Share (60%)', 'Status', 'Date'];
      rows = transactions.map((t) => [
        t.id,
        t.userEmail,
        t.storeName,
        `"${t.productTitle.replace(/"/g, '""')}"`,
        t.orderAmount,
        t.affiliateCommission,
        t.userCashbackAmount,
        t.platformShareAmount,
        t.status,
        t.createdAt,
      ]);
    } else {
      headers = ['ID', 'User Email', 'Amount', 'Method', 'Status', 'Reference / UTR', 'Date'];
      rows = withdrawals.map((w) => [
        w.id,
        w.userEmail,
        w.amount,
        w.method,
        w.status,
        w.transactionReference || '',
        w.requestedAt,
      ]);
    }

    const csvContent =
      'data:text/csv;charset=utf-8,' +
      [headers.join(','), ...rows.map((r) => r.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `MeBUYMONEY_${type}_${Date.now()}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // If not admin, show secure gate
  if (!isAdmin) {
    return (
      <div className="max-w-md mx-auto my-12 bg-white rounded-3xl p-8 border border-slate-200 shadow-xl text-center space-y-4">
        <div className="w-16 h-16 bg-slate-100 text-slate-700 rounded-2xl flex items-center justify-center mx-auto">
          <Lock className="w-8 h-8 text-slate-700" />
        </div>
        <h2 className="text-xl font-extrabold text-slate-900">Administrator Access Required</h2>
        <p className="text-xs text-slate-500 leading-relaxed">
          The Me BUY MONEY Admin Operations Center is strictly protected with role-based access control. Only authorized platform administrators can access this console.
        </p>
        <button
          onClick={() => openAuthModal('signin')}
          className="w-full py-3.5 px-4 rounded-2xl bg-slate-900 hover:bg-slate-800 text-white font-extrabold text-xs shadow-md transition-all flex items-center justify-center gap-2"
        >
          <Shield className="w-4 h-4" />
          <span>Sign In with Administrator Account</span>
        </button>
      </div>
    );
  }

  const pendingRequestsCount = rewardRequests.filter((r) => r.status === 'Pending').length;

  return (
    <div className="space-y-6 pb-24">
      {/* Header */}
      <div className="bg-gradient-to-r from-slate-900 via-purple-950 to-slate-900 text-white rounded-3xl p-6 sm:p-8 shadow-xl flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="bg-purple-500/30 text-purple-300 font-extrabold text-[10px] uppercase px-2.5 py-0.5 rounded-full border border-purple-500/40">
              Admin Operations Center
            </span>
            <span className="text-xs text-slate-400 font-mono">Logged in as: {profile?.email}</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-black mt-1">Me BUY MONEY Operations</h1>
          <p className="text-xs text-slate-300">
            Fulfill live Reward Link requests, reconcile merchant commissions, and disburse UPI/Bank payouts.
          </p>
        </div>

        <div className="flex gap-2">
          <button
            onClick={loadAllData}
            className="px-3.5 py-2 rounded-xl bg-white/10 hover:bg-white/20 text-white text-xs font-semibold flex items-center gap-1.5 transition-colors"
          >
            <RefreshCw className="w-3.5 h-3.5" />
            <span>Refresh</span>
          </button>
          <button
            onClick={() => handleExportCSV('requests')}
            className="px-3.5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold flex items-center gap-1.5 transition-colors shadow-sm"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Export Requests</span>
          </button>
        </div>
      </div>

      {actionMessage && (
        <div className="bg-emerald-50 border border-emerald-200 text-emerald-900 text-xs font-bold p-3.5 rounded-2xl flex items-center gap-2 animate-in fade-in">
          <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
          <span>{actionMessage}</span>
        </div>
      )}

      {/* Tabs */}
      <div className="flex gap-2 overflow-x-auto pb-1 text-xs scrollbar-none">
        {[
          {
            id: 'queue',
            label: `Reward Link Queue ${pendingRequestsCount > 0 ? `(${pendingRequestsCount} Pending)` : `(${rewardRequests.length})`}`,
            icon: Link2,
            badge: pendingRequestsCount,
          },
          { id: 'stats', label: 'Financial KPIs', icon: TrendingUp },
          { id: 'transactions', label: `Transactions (${transactions.length})`, icon: FileSpreadsheet },
          { id: 'withdrawals', label: `Withdrawals (${withdrawals.length})`, icon: ArrowUpRight },
          { id: 'products', label: `Deals Catalog (${products.length})`, icon: Layers },
          { id: 'networks', label: `Networks (${networks.length})`, icon: DollarSign },
          { id: 'settings', label: 'Platform Settings', icon: Settings },
          { id: 'logs', label: `Audit Trail (${auditLogs.length})`, icon: Shield },
        ].map((t) => {
          const Icon = t.icon;
          const isActive = activeTab === t.id;
          return (
            <button
              key={t.id}
              onClick={() => setActiveTab(t.id as any)}
              className={`px-4 py-2.5 rounded-2xl font-bold whitespace-nowrap shrink-0 flex items-center gap-2 transition-all ${
                isActive
                  ? 'bg-purple-700 text-white shadow-md shadow-purple-700/20'
                  : 'bg-white text-slate-700 border border-slate-200 hover:bg-slate-50'
              }`}
            >
              <Icon className="w-3.5 h-3.5" />
              <span>{t.label}</span>
              {t.badge && t.badge > 0 ? (
                <span className="w-2 h-2 rounded-full bg-amber-400 animate-pulse" />
              ) : null}
            </button>
          );
        })}
      </div>

      {/* TAB 1: REWARD LINK QUEUE (CORE ADMIN FEATURE) */}
      {activeTab === 'queue' && (
        <div className="space-y-4">
          <div className="bg-white rounded-3xl border border-slate-200/90 shadow-sm p-5 space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div>
                <div className="flex items-center gap-2">
                  <h3 className="text-base font-black text-slate-900">
                    Incoming Reward Link Requests
                  </h3>
                  {pendingRequestsCount > 0 && (
                    <span className="bg-amber-100 text-amber-800 text-[10px] font-black px-2 py-0.5 rounded-full uppercase animate-pulse">
                      {pendingRequestsCount} Awaiting Fulfillment
                    </span>
                  )}
                </div>
                <p className="text-xs text-slate-500">
                  Inspect submitted shopping URLs, generate eligible affiliate links with user sub-IDs, and send directly to user inboxes.
                </p>
              </div>

              <div className="flex items-center gap-2">
                <span className="text-xs text-slate-400 font-semibold">
                  Queue updates in real-time
                </span>
              </div>
            </div>

            {rewardRequests.length === 0 ? (
              <div className="p-12 text-center text-xs text-slate-400 border border-dashed border-slate-200 rounded-2xl">
                No reward link requests in the queue. When users paste links on the Reward Link tab, they will appear here!
              </div>
            ) : (
              <div className="space-y-4">
                {rewardRequests.map((req) => {
                  const isPending = req.status === 'Pending';
                  const isCompleted = req.status === 'Completed';
                  const isRejected = req.status === 'Rejected';

                  return (
                    <div
                      key={req.id}
                      className={`p-4 sm:p-5 rounded-2xl border transition-all space-y-3.5 ${
                        isPending
                          ? 'bg-amber-50/40 border-amber-300 ring-2 ring-amber-500/10 shadow-sm'
                          : isCompleted
                          ? 'bg-white border-slate-200'
                          : 'bg-rose-50/20 border-rose-200 opacity-80'
                      }`}
                    >
                      {/* Top Header Row */}
                      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-100 pb-2.5">
                        <div className="flex items-center gap-2.5">
                          <span className="font-mono font-black text-xs text-slate-900 bg-slate-100 px-2.5 py-0.5 rounded-lg border border-slate-200">
                            {req.id}
                          </span>
                          <span className="text-xs font-black text-emerald-800 bg-emerald-50 px-2 py-0.5 rounded-full border border-emerald-200">
                            {req.storeName}
                          </span>
                          <span
                            className={`text-[10px] font-bold px-2.5 py-0.5 rounded-full uppercase tracking-wider ${
                              isPending
                                ? 'bg-amber-500 text-white animate-pulse'
                                : isCompleted
                                ? 'bg-emerald-600 text-white'
                                : 'bg-rose-600 text-white'
                            }`}
                          >
                            {req.status}
                          </span>
                        </div>

                        <div className="flex items-center gap-2 text-[11px] text-slate-500 font-medium">
                          <Clock className="w-3.5 h-3.5 text-slate-400" />
                          <span>Submitted {getElapsedTime(req.submittedAt)}</span>
                          <span className="text-slate-300">•</span>
                          <span className="font-mono text-slate-600">{req.userEmail}</span>
                        </div>
                      </div>

                      {/* Original URL Display & Quick Actions */}
                      <div className="space-y-1.5 text-xs">
                        <span className="text-[10px] uppercase font-bold text-slate-400 block">
                          Original Product URL Submitted by User:
                        </span>
                        <div className="flex items-center gap-2 bg-slate-50 p-2.5 rounded-xl border border-slate-200/80 font-mono text-[11px] text-slate-800">
                          <span className="truncate flex-1">{req.productUrl}</span>
                          <button
                            onClick={() => handleCopyOriginalUrl(req.productUrl, req.id)}
                            className="px-2.5 py-1 rounded-lg bg-white border border-slate-200 hover:bg-slate-100 text-slate-700 font-bold text-[10px] flex items-center gap-1 shrink-0 transition-colors"
                          >
                            {copiedUrlReqId === req.id ? (
                              <>
                                <Check className="w-3 h-3 text-emerald-600" />
                                <span>Copied</span>
                              </>
                            ) : (
                              <>
                                <Copy className="w-3 h-3" />
                                <span>Copy URL</span>
                              </>
                            )}
                          </button>
                          <a
                            href={req.productUrl}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="px-2.5 py-1 rounded-lg bg-white border border-slate-200 hover:bg-slate-100 text-slate-700 font-bold text-[10px] flex items-center gap-1 shrink-0 transition-colors"
                          >
                            <ExternalLink className="w-3 h-3" />
                            <span>Open URL</span>
                          </a>
                        </div>
                      </div>

                      {/* Completed Details */}
                      {isCompleted && (
                        <div className="bg-emerald-50/70 p-3 rounded-xl border border-emerald-200 text-xs space-y-1">
                          <span className="text-[10px] uppercase font-bold text-emerald-800 block">
                            Delivered Affiliate Link (In User Inbox):
                          </span>
                          <p className="font-mono text-[11px] text-emerald-950 truncate">
                            {req.affiliateUrl}
                          </p>
                          <span className="text-[10px] text-emerald-700 font-semibold block pt-0.5">
                            User clicks recorded: {req.clickCount} • Completed {req.completedAt ? getElapsedTime(req.completedAt) : ''}
                          </span>
                        </div>
                      )}

                      {/* Rejected Details */}
                      {isRejected && (
                        <div className="bg-rose-50 p-3 rounded-xl border border-rose-200 text-xs space-y-0.5">
                          <span className="text-[10px] uppercase font-bold text-rose-800 block">
                            Rejection Reason:
                          </span>
                          <p className="text-rose-900 font-medium">{req.rejectionReason}</p>
                        </div>
                      )}

                      {/* Action Fulfillment Row for Pending Requests */}
                      {isPending && (
                        <div className="pt-2 border-t border-amber-200/60 space-y-3">
                          <div className="flex flex-col sm:flex-row gap-2">
                            {/* Affiliate Link Input */}
                            <div className="flex-1 relative">
                              <input
                                type="url"
                                value={activeAffiliateInput[req.id] || ''}
                                onChange={(e) =>
                                  setActiveAffiliateInput({
                                    ...activeAffiliateInput,
                                    [req.id]: e.target.value,
                                  })
                                }
                                placeholder="Paste tracked affiliate link here (e.g. https://www.amazon.in/dp/...tag=ansora-21&subid=...)"
                                className="w-full p-3 bg-white border border-slate-300 rounded-xl text-xs font-mono font-medium text-slate-900 placeholder-slate-400 outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500"
                              />
                            </div>

                            {/* Auto Helper Generator Button */}
                            <button
                              type="button"
                              onClick={() =>
                                setActiveAffiliateInput({
                                  ...activeAffiliateInput,
                                  [req.id]: generateHelperLink(req),
                                })
                              }
                              className="px-3.5 py-2.5 rounded-xl bg-purple-50 hover:bg-purple-100 text-purple-700 font-bold text-xs border border-purple-200 flex items-center justify-center gap-1.5 shrink-0 transition-colors"
                              title="Auto appends affiliate tags & user sub-ID"
                            >
                              <Sparkles className="w-3.5 h-3.5 text-purple-600" />
                              <span>Auto-Generate Link</span>
                            </button>
                          </div>

                          {/* Action Buttons */}
                          <div className="flex flex-col sm:flex-row items-center justify-between gap-2">
                            <div className="flex items-center gap-2 w-full sm:w-auto">
                              <button
                                onClick={() => handleSendLink(req.id)}
                                className="flex-1 sm:flex-none px-5 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold text-xs shadow-md shadow-emerald-600/20 flex items-center justify-center gap-2 transition-all hover:scale-[1.02]"
                              >
                                <Send className="w-3.5 h-3.5" />
                                <span>Send Reward Link to User Inbox</span>
                              </button>

                              <button
                                onClick={() => setRejectingReqId(req.id)}
                                className="px-3.5 py-2.5 rounded-xl border border-rose-200 hover:bg-rose-50 text-rose-700 font-bold text-xs transition-colors"
                              >
                                Reject
                              </button>
                            </div>
                            <span className="text-[10px] text-slate-400">
                              Sends instant notification & creates Order status: Link Sent
                            </span>
                          </div>

                          {/* Rejection reason inline prompt */}
                          {rejectingReqId === req.id && (
                            <div className="bg-rose-50 border border-rose-200 p-3.5 rounded-xl space-y-2 animate-in fade-in">
                              <label className="text-[11px] font-bold text-rose-900 block">
                                Reason for Rejection *
                              </label>
                              <input
                                type="text"
                                required
                                value={rejectionReasonInput}
                                onChange={(e) => setRejectionReasonInput(e.target.value)}
                                placeholder="e.g. Non-commissionable category, merchant coupon restriction, or broken URL"
                                className="w-full p-2.5 bg-white border border-rose-200 rounded-xl text-xs text-slate-800"
                              />
                              <div className="flex justify-end gap-2 pt-1">
                                <button
                                  type="button"
                                  onClick={() => setRejectingReqId(null)}
                                  className="px-3 py-1.5 rounded-lg border border-slate-200 text-slate-600 font-semibold text-xs"
                                >
                                  Cancel
                                </button>
                                <button
                                  type="button"
                                  onClick={() => handleRejectLink(req.id)}
                                  className="px-4 py-1.5 rounded-lg bg-rose-600 hover:bg-rose-700 text-white font-bold text-xs"
                                >
                                  Confirm Rejection
                                </button>
                              </div>
                            </div>
                          )}
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </div>
      )}

      {/* TAB 2: FINANCIAL KPIS */}
      {activeTab === 'stats' && (
        <div className="space-y-6">
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3.5">
            <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs space-y-1">
              <span className="text-[10px] font-bold uppercase text-slate-400">Total Users</span>
              <div className="text-xl font-black text-slate-900">{stats.totalUsers}</div>
              <p className="text-[10px] text-slate-400">Registered shoppers</p>
            </div>

            <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs space-y-1">
              <span className="text-[10px] font-bold uppercase text-slate-400">Affiliate Clicks</span>
              <div className="text-xl font-black text-indigo-600">{stats.totalClicks}</div>
              <p className="text-[10px] text-slate-400">Outbound tracking events</p>
            </div>

            <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs space-y-1">
              <span className="text-[10px] font-bold uppercase text-slate-400">Tracked Transactions</span>
              <div className="text-xl font-black text-slate-900">{stats.totalTransactions}</div>
              <p className="text-[10px] text-slate-400">Orders detected & claims</p>
            </div>

            <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs space-y-1">
              <span className="text-[10px] font-bold uppercase text-slate-400">Pending Cashback</span>
              <div className="text-xl font-black text-amber-600">₹{stats.pendingCashback.toLocaleString('en-IN')}</div>
              <p className="text-[10px] text-slate-400">Awaiting return window</p>
            </div>

            <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs space-y-1">
              <span className="text-[10px] font-bold uppercase text-slate-400">Confirmed Cashback</span>
              <div className="text-xl font-black text-emerald-600">₹{stats.confirmedCashback.toLocaleString('en-IN')}</div>
              <p className="text-[10px] text-slate-400">User 40% confirmed share</p>
            </div>

            <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs space-y-1">
              <span className="text-[10px] font-bold uppercase text-slate-400">Total Withdrawals</span>
              <div className="text-xl font-black text-purple-600">₹{stats.totalWithdrawn.toLocaleString('en-IN')}</div>
              <p className="text-[10px] text-slate-400">Paid out to Bank/UPI</p>
            </div>

            <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs space-y-1">
              <span className="text-[10px] font-bold uppercase text-slate-400">Gross Commission</span>
              <div className="text-xl font-black text-blue-600">₹{stats.grossCommission.toLocaleString('en-IN')}</div>
              <p className="text-[10px] text-slate-400">Total received from stores</p>
            </div>

            <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs space-y-1">
              <span className="text-[10px] font-bold uppercase text-slate-400">Platform Revenue (60%)</span>
              <div className="text-xl font-black text-teal-600">₹{stats.platformRevenue.toLocaleString('en-IN')}</div>
              <p className="text-[10px] text-slate-400">Net platform earnings</p>
            </div>
          </div>

          {/* Quick reconciliation callout */}
          <div className="bg-gradient-to-r from-purple-900 to-indigo-900 text-white rounded-3xl p-6 shadow-md flex items-center justify-between gap-4">
            <div className="space-y-1">
              <h3 className="text-base font-bold">Automated 40% User / 60% Platform Split Rule</h3>
              <p className="text-xs text-purple-200 max-w-xl">
                When you mark an affiliate order as "Cashback Confirmed", the system automatically computes 40% of the commission and credits it to the user's available balance in an atomic transaction.
              </p>
            </div>
            <button
              onClick={() => setActiveTab('transactions')}
              className="px-4 py-2.5 rounded-xl bg-white text-purple-950 font-bold text-xs shrink-0 hover:bg-purple-50 transition-colors"
            >
              Reconcile Transactions
            </button>
          </div>
        </div>
      )}

      {/* TAB 3: TRANSACTIONS & RECONCILIATION */}
      {activeTab === 'transactions' && (
        <div className="bg-white rounded-3xl border border-slate-200 shadow-sm overflow-hidden space-y-4 p-5">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div>
              <h3 className="text-sm font-bold text-slate-900">Affiliate Transactions & Missing Claims</h3>
              <p className="text-xs text-slate-500">
                Update status to Confirmed or Rejected to credit user wallets
              </p>
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="bg-slate-50 border-b border-slate-200 text-slate-500 font-bold uppercase text-[10px]">
                  <th className="p-3">Store & Title</th>
                  <th className="p-3">Tracking Sub-ID</th>
                  <th className="p-3">Order Amount</th>
                  <th className="p-3">Commission</th>
                  <th className="p-3">User (40%)</th>
                  <th className="p-3">Status</th>
                  <th className="p-3 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 font-medium text-slate-700">
                {transactions.map((t) => (
                  <tr key={t.id} className="hover:bg-slate-50/50">
                    <td className="p-3">
                      <div className="font-bold text-slate-900">{t.storeName}</div>
                      <div className="text-[10px] text-slate-400 truncate max-w-xs">{t.productTitle}</div>
                    </td>
                    <td className="p-3 font-mono text-[11px] text-emerald-800">{t.trackingSubId}</td>
                    <td className="p-3 font-bold">₹{t.orderAmount?.toLocaleString('en-IN') || '--'}</td>
                    <td className="p-3 text-blue-600 font-bold">₹{t.affiliateCommission?.toFixed(2) || '0.00'}</td>
                    <td className="p-3 text-emerald-600 font-black">₹{t.userCashbackAmount?.toFixed(2) || '0.00'}</td>
                    <td className="p-3">
                      <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-slate-100 text-slate-800">
                        {t.status}
                      </span>
                    </td>
                    <td className="p-3 text-right">
                      <button
                        onClick={() => {
                          setReconcileModalTxn(t);
                          setNewStatus(t.status);
                          setReconcileCommission(t.affiliateCommission ? t.affiliateCommission.toString() : '80');
                        }}
                        className="px-2.5 py-1 bg-purple-50 text-purple-700 hover:bg-purple-100 rounded-lg font-bold text-[11px]"
                      >
                        Reconcile
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* TAB 4: WITHDRAWALS & PAYOUTS */}
      {activeTab === 'withdrawals' && (
        <div className="bg-white rounded-3xl border border-slate-200 shadow-sm overflow-hidden space-y-4 p-5">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div>
              <h3 className="text-sm font-bold text-slate-900">Withdrawal Payout Requests</h3>
              <p className="text-xs text-slate-500">
                Review user requests, disburse via UPI/Bank, and record payment references (UTR)
              </p>
            </div>
            <button
              onClick={() => handleExportCSV('withdrawals')}
              className="px-3 py-1.5 rounded-xl border border-slate-200 text-xs font-semibold hover:bg-slate-50"
            >
              Export Payouts CSV
            </button>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="bg-slate-50 border-b border-slate-200 text-slate-500 font-bold uppercase text-[10px]">
                  <th className="p-3">User Email</th>
                  <th className="p-3">Amount</th>
                  <th className="p-3">Method</th>
                  <th className="p-3">Payout Details</th>
                  <th className="p-3">Status</th>
                  <th className="p-3">Ref / UTR</th>
                  <th className="p-3 text-right">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 font-medium text-slate-700">
                {withdrawals.map((w) => (
                  <tr key={w.id} className="hover:bg-slate-50/50">
                    <td className="p-3 font-semibold text-slate-900">{w.userEmail}</td>
                    <td className="p-3 font-black text-emerald-600 text-sm">₹{w.amount}</td>
                    <td className="p-3 uppercase font-bold text-[10px] text-slate-500">{w.method}</td>
                    <td className="p-3 text-[11px]">
                      {w.method === 'UPI' ? (
                        <span className="font-mono bg-slate-100 px-1.5 py-0.5 rounded">{w.payoutDetails?.upiId}</span>
                      ) : (
                        <span>
                          {w.payoutDetails?.accountHolder} • {w.payoutDetails?.accountNumber} ({w.payoutDetails?.ifscCode})
                        </span>
                      )}
                    </td>
                    <td className="p-3">
                      <span
                        className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                          w.status === 'Paid'
                            ? 'bg-emerald-50 text-emerald-700'
                            : w.status === 'Rejected'
                            ? 'bg-rose-50 text-rose-700'
                            : 'bg-amber-50 text-amber-700'
                        }`}
                      >
                        {w.status}
                      </span>
                    </td>
                    <td className="p-3 font-mono text-[10px] text-slate-500">{w.transactionReference || '--'}</td>
                    <td className="p-3 text-right">
                      <button
                        onClick={() => {
                          setPayoutModalWth(w);
                          setPayoutStatus(w.status === 'Pending' ? 'Paid' : w.status);
                          setPayoutUtr(w.transactionReference || `UTR_${Date.now().toString().slice(-8)}`);
                        }}
                        className="px-2.5 py-1 bg-emerald-50 text-emerald-800 hover:bg-emerald-100 rounded-lg font-bold text-[11px]"
                      >
                        Process Payout
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* TAB 5: PRODUCTS */}
      {activeTab === 'products' && (
        <div className="bg-white rounded-3xl border border-slate-200 shadow-sm p-5 space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-sm font-bold text-slate-900">Manage Catalog & Affiliate Links</h3>
              <p className="text-xs text-slate-500">Add or edit products, stores and tracking URLs</p>
            </div>
            <button
              onClick={() => setShowProductModal(true)}
              className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold flex items-center gap-1.5"
            >
              <Plus className="w-4 h-4" />
              <span>Add New Product Deal</span>
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
            {products.map((p) => (
              <div key={p.id} className="p-3.5 border border-slate-200 rounded-2xl flex gap-3 text-xs">
                <img src={p.imageUrl} alt={p.title} className="w-16 h-16 rounded-xl object-cover" />
                <div className="flex-1 min-w-0">
                  <span className="text-[10px] font-bold uppercase text-slate-400">{p.storeName}</span>
                  <h4 className="font-bold text-slate-900 line-clamp-1">{p.title}</h4>
                  <div className="flex items-baseline gap-2 mt-0.5">
                    <span className="font-extrabold text-slate-900">₹{p.dealPrice}</span>
                    <span className="text-emerald-600 font-bold text-[11px]">{p.cashbackLabel}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* TAB 6: NETWORKS */}
      {activeTab === 'networks' && (
        <div className="bg-white rounded-3xl border border-slate-200 shadow-sm p-5 space-y-4">
          <div>
            <h3 className="text-sm font-bold text-slate-900">Configured Affiliate Networks</h3>
            <p className="text-xs text-slate-500">
              Manage commission percentages and sub-ID tracking parameter names
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {networks.map((net) => (
              <div key={net.id} className="p-4 border border-slate-200 rounded-2xl space-y-3 text-xs">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-sm text-slate-900">{net.name}</span>
                  <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-50 text-emerald-800">
                    Active
                  </span>
                </div>

                <div className="grid grid-cols-3 gap-2 bg-slate-50 p-3 rounded-xl text-center">
                  <div>
                    <span className="text-[10px] text-slate-400 uppercase font-bold block">Base Rate</span>
                    <span className="font-black text-slate-800">{net.defaultCommissionRate}%</span>
                  </div>
                  <div>
                    <span className="text-[10px] text-emerald-700 uppercase font-bold block">User Share</span>
                    <span className="font-black text-emerald-600">{net.userCashbackPercentage}%</span>
                  </div>
                  <div>
                    <span className="text-[10px] text-slate-600 uppercase font-bold block">Platform</span>
                    <span className="font-black text-slate-800">{net.platformSharePercentage}%</span>
                  </div>
                </div>

                <div className="text-[11px] text-slate-500">
                  Tracking Parameter: <code className="font-mono text-purple-700 font-bold">{net.trackingParamName}</code>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* TAB 7: SETTINGS */}
      {activeTab === 'settings' && (
        <div className="bg-white rounded-3xl border border-slate-200 shadow-sm p-6 space-y-4 max-w-xl text-xs">
          <h3 className="text-sm font-bold text-slate-900">Global Platform Settings</h3>
          <div className="space-y-3">
            <div className="space-y-1">
              <label className="font-bold text-slate-700">Minimum Withdrawal Amount (₹)</label>
              <input
                type="number"
                value={settings?.minWithdrawalAmount || 250}
                onChange={(e) =>
                  setSettings(
                    settings ? { ...settings, minWithdrawalAmount: parseFloat(e.target.value) || 250 } : null
                  )
                }
                className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl font-bold text-slate-900"
              />
            </div>

            <div className="space-y-1">
              <label className="font-bold text-slate-700">Welcome Sign-Up Bonus (₹)</label>
              <input
                type="number"
                value={settings?.referralRewardAmount || 50}
                onChange={(e) =>
                  setSettings(
                    settings ? { ...settings, referralRewardAmount: parseFloat(e.target.value) || 50 } : null
                  )
                }
                className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl font-bold text-slate-900"
              />
            </div>

            <button
              onClick={async () => {
                if (settings && profile) {
                  await updatePlatformSettings(settings, profile.email);
                  setActionMessage('Platform settings updated successfully!');
                  setTimeout(() => setActionMessage(null), 3000);
                }
              }}
              className="py-2.5 px-5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl"
            >
              Save Platform Settings
            </button>
          </div>
        </div>
      )}

      {/* TAB 8: AUDIT LOGS */}
      {activeTab === 'logs' && (
        <div className="bg-white rounded-3xl border border-slate-200 shadow-sm p-5 space-y-3">
          <h3 className="text-sm font-bold text-slate-900">Auditable Activity Trail</h3>
          <div className="space-y-2 text-xs">
            {auditLogs.map((log) => (
              <div key={log.id} className="p-3 bg-slate-50 rounded-xl border border-slate-100 flex items-start justify-between">
                <div>
                  <div className="font-bold text-slate-900">{log.action}</div>
                  <p className="text-slate-600">{log.details}</p>
                  <span className="text-[10px] text-slate-400">By: {log.actorEmail}</span>
                </div>
                <span className="text-[10px] text-slate-400 font-mono">
                  {new Date(log.timestamp).toLocaleTimeString('en-IN')}
                </span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Reconcile Modal */}
      {reconcileModalTxn && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm">
          <div className="bg-white w-full max-w-md rounded-2xl p-5 shadow-2xl border border-slate-100 space-y-4 text-xs">
            <div className="flex items-center justify-between border-b pb-2">
              <h3 className="font-bold text-sm text-slate-900">Reconcile Transaction</h3>
              <button onClick={() => setReconcileModalTxn(null)}>
                <X className="w-4 h-4 text-slate-400" />
              </button>
            </div>

            <div className="space-y-1">
              <span className="text-slate-400 block text-[10px] uppercase font-bold">Store & Tracking</span>
              <div className="font-bold text-slate-900">{reconcileModalTxn.storeName}</div>
              <div className="font-mono text-emerald-800">{reconcileModalTxn.trackingSubId}</div>
            </div>

            <div className="space-y-1">
              <label className="font-bold text-slate-700">Gross Affiliate Commission (₹)</label>
              <input
                type="number"
                value={reconcileCommission}
                onChange={(e) => setReconcileCommission(e.target.value)}
                className="w-full p-2 bg-slate-50 border border-slate-200 rounded-xl"
              />
              <span className="text-[10px] text-emerald-600 block">
                User will receive 40% (₹{((parseFloat(reconcileCommission) || 0) * 0.4).toFixed(2)}) on Confirmation.
              </span>
            </div>

            <div className="space-y-1">
              <label className="font-bold text-slate-700">New Status</label>
              <select
                value={newStatus}
                onChange={(e) => setNewStatus(e.target.value as any)}
                className="w-full p-2 bg-slate-50 border border-slate-200 rounded-xl font-bold"
              >
                <option value="Cashback Confirmed">Cashback Confirmed (Credits Wallet)</option>
                <option value="Cashback Pending">Cashback Pending</option>
                <option value="Cashback Rejected">Cashback Rejected</option>
                <option value="Cashback Paid">Cashback Paid</option>
              </select>
            </div>

            {newStatus === 'Cashback Rejected' && (
              <div className="space-y-1">
                <label className="font-bold text-slate-700">Rejection Reason</label>
                <input
                  type="text"
                  value={reconcileReason}
                  onChange={(e) => setReconcileReason(e.target.value)}
                  placeholder="Order cancelled by user or returned"
                  className="w-full p-2 bg-slate-50 border border-slate-200 rounded-xl"
                />
              </div>
            )}

            <div className="pt-2 flex gap-2">
              <button
                onClick={() => setReconcileModalTxn(null)}
                className="flex-1 py-2 rounded-xl border border-slate-200 font-bold"
              >
                Cancel
              </button>
              <button
                onClick={handleReconcileSubmit}
                className="flex-1 py-2 rounded-xl bg-purple-700 text-white font-bold"
              >
                Save & Update Wallet
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Payout Processing Modal */}
      {payoutModalWth && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm">
          <div className="bg-white w-full max-w-md rounded-2xl p-5 shadow-2xl border border-slate-100 space-y-4 text-xs">
            <div className="flex items-center justify-between border-b pb-2">
              <h3 className="font-bold text-sm text-slate-900">Process Payout</h3>
              <button onClick={() => setPayoutModalWth(null)}>
                <X className="w-4 h-4 text-slate-400" />
              </button>
            </div>

            <div>
              <span className="text-slate-400 block text-[10px] uppercase font-bold">Recipient</span>
              <div className="font-bold text-slate-900">{payoutModalWth.userEmail}</div>
              <div className="text-base font-black text-emerald-600 mt-1">₹{payoutModalWth.amount} via {payoutModalWth.method}</div>
            </div>

            <div className="space-y-1">
              <label className="font-bold text-slate-700">Status</label>
              <select
                value={payoutStatus}
                onChange={(e) => setPayoutStatus(e.target.value as any)}
                className="w-full p-2 bg-slate-50 border border-slate-200 rounded-xl font-bold"
              >
                <option value="Paid">Paid (Disbursed)</option>
                <option value="Processing">Processing</option>
                <option value="Rejected">Rejected (Refunds to user balance)</option>
              </select>
            </div>

            <div className="space-y-1">
              <label className="font-bold text-slate-700">Bank UTR / Transaction Reference</label>
              <input
                type="text"
                value={payoutUtr}
                onChange={(e) => setPayoutUtr(e.target.value)}
                placeholder="e.g. UTR492817482"
                className="w-full p-2 bg-slate-50 border border-slate-200 rounded-xl font-mono"
              />
            </div>

            <div className="pt-2 flex gap-2">
              <button
                onClick={() => setPayoutModalWth(null)}
                className="flex-1 py-2 rounded-xl border border-slate-200 font-bold"
              >
                Cancel
              </button>
              <button
                onClick={handlePayoutSubmit}
                className="flex-1 py-2 rounded-xl bg-emerald-600 text-white font-bold"
              >
                Confirm Payout
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Add Product Modal */}
      {showProductModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm">
          <div className="bg-white w-full max-w-lg rounded-2xl p-5 shadow-2xl border border-slate-100 space-y-4 text-xs">
            <div className="flex items-center justify-between border-b pb-2">
              <h3 className="font-bold text-sm text-slate-900">Add New Affiliate Deal</h3>
              <button onClick={() => setShowProductModal(false)}>
                <X className="w-4 h-4 text-slate-400" />
              </button>
            </div>

            <form onSubmit={handleCreateProduct} className="space-y-3">
              <div className="space-y-1">
                <label className="font-bold text-slate-700">Product Title *</label>
                <input
                  type="text"
                  required
                  value={newProdTitle}
                  onChange={(e) => setNewProdTitle(e.target.value)}
                  placeholder="e.g. Apple iPhone 15 (128 GB, Black)"
                  className="w-full p-2 bg-slate-50 border border-slate-200 rounded-xl"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="font-bold text-slate-700">Store Name</label>
                  <input
                    type="text"
                    value={newProdStore}
                    onChange={(e) => setNewProdStore(e.target.value)}
                    className="w-full p-2 bg-slate-50 border border-slate-200 rounded-xl"
                  />
                </div>
                <div className="space-y-1">
                  <label className="font-bold text-slate-700">Cashback Rate (%)</label>
                  <input
                    type="number"
                    step="0.1"
                    value={newProdCashbackRate}
                    onChange={(e) => {
                      setNewProdCashbackRate(e.target.value);
                      setNewProdCashbackLabel(`Earn ${e.target.value}% Cashback`);
                    }}
                    className="w-full p-2 bg-slate-50 border border-slate-200 rounded-xl"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="font-bold text-slate-700">Original MRP (₹)</label>
                  <input
                    type="number"
                    value={newProdOriginalPrice}
                    onChange={(e) => setNewProdOriginalPrice(e.target.value)}
                    className="w-full p-2 bg-slate-50 border border-slate-200 rounded-xl"
                  />
                </div>
                <div className="space-y-1">
                  <label className="font-bold text-slate-700">Deal Price (₹)</label>
                  <input
                    type="number"
                    value={newProdDealPrice}
                    onChange={(e) => setNewProdDealPrice(e.target.value)}
                    className="w-full p-2 bg-slate-50 border border-slate-200 rounded-xl"
                  />
                </div>
              </div>

              <div className="space-y-1">
                <label className="font-bold text-slate-700">Affiliate URL (Include {"{SUB_ID}"})</label>
                <input
                  type="text"
                  value={newProdAffiliateUrl}
                  onChange={(e) => setNewProdAffiliateUrl(e.target.value)}
                  className="w-full p-2 bg-slate-50 border border-slate-200 rounded-xl font-mono text-[11px]"
                />
              </div>

              <div className="pt-2 flex gap-2">
                <button
                  type="button"
                  onClick={() => setShowProductModal(false)}
                  className="flex-1 py-2 rounded-xl border border-slate-200 font-bold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2 rounded-xl bg-emerald-600 text-white font-bold"
                >
                  Save Product
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
