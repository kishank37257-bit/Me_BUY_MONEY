export type Role = 'user' | 'admin';

export interface UserProfile {
  id: string;
  email: string;
  displayName: string;
  role: Role;
  referralCode: string;
  referredBy?: string;
  phone?: string;
  upiId?: string;
  isSubscribed?: boolean;
  subscriptionExpiry?: string;
  subscriptionTier?: 'vip' | 'premium';
  createdAt: string;
  updatedAt?: string;
}

export interface Wallet {
  userId: string;
  pendingCashback: number;
  confirmedCashback: number;
  availableBalance: number;
  totalEarned: number;
  totalWithdrawn: number;
  rejectedCashback: number;
  updatedAt?: string;
}

export type RewardLinkStatus = 'Pending' | 'Completed' | 'Rejected';

export interface RewardLinkRequest {
  id: string;
  userId: string;
  userEmail: string;
  productUrl: string;
  storeName: string;
  productTitle?: string;
  affiliateUrl?: string;
  status: RewardLinkStatus;
  rejectionReason?: string;
  submittedAt: string;
  completedAt?: string;
  clickCount: number;
  lastClickedAt?: string;
  notes?: string;
}

export interface UserInboxItem {
  id: string;
  userId: string;
  requestId: string;
  productUrl: string;
  affiliateUrl: string;
  storeName: string;
  productTitle?: string;
  status: RewardLinkStatus;
  receivedAt: string;
  isRead: boolean;
  clickCount: number;
  lastClickedAt?: string;
  rejectionReason?: string;
}

export interface AffiliateNetwork {
  id: string;
  name: string;
  slug: string;
  logoUrl: string;
  status: 'active' | 'inactive';
  defaultCommissionRate: number; // e.g. 10.0 for 10%
  userCashbackPercentage: number; // e.g. 40% of commission
  platformSharePercentage: number; // e.g. 60% of commission
  trackingParamName: string; // e.g. "subid", "tag", "affid"
  baseUrl: string;
  cookieWindowDays: number;
  terms: string;
  createdAt: string;
}

export interface Category {
  id: string;
  name: string;
  slug: string;
  icon: string;
  bannerUrl?: string;
  featured: boolean;
  sortOrder: number;
}

export interface Product {
  id: string;
  title: string;
  description: string;
  networkId: string;
  storeName: string;
  storeLogo: string;
  categoryId: string;
  categorySlug: string;
  originalPrice: number;
  dealPrice: number;
  cashbackRate: number; // e.g. 4.0 for 4%
  cashbackType: 'percent' | 'flat';
  cashbackLabel: string; // e.g. "Earn 4% Cashback"
  affiliateUrl: string;
  imageUrl: string;
  isHotDeal: boolean;
  rating: number;
  totalClicks: number;
  termsAndConditions: string;
  status: 'active' | 'paused';
  couponCode?: string;
  expiresAt?: string;
  createdAt: string;
}

export interface PremiumDeal {
  id: string;
  title: string;
  description: string;
  storeName: string;
  storeLogo: string;
  category: string;
  originalPrice: number;
  dealPrice: number;
  cashbackRate: number;
  cashbackLabel: string;
  affiliateUrl: string;
  imageUrl: string;
  expiryDate: string;
  isExclusive: boolean;
  status: 'published' | 'draft' | 'scheduled';
  couponCode?: string;
  vipOnly?: boolean;
  rating: number;
  totalClicks: number;
  createdAt: string;
}

export interface ClickRecord {
  id: string;
  userId: string;
  productId?: string;
  requestId?: string;
  productTitle: string;
  storeName: string;
  networkId?: string;
  trackingSubId: string;
  destinationUrl: string;
  userAgent: string;
  timestamp: string;
  status: 'tracked' | 'converted' | 'expired';
}

export type OrderStatus =
  | 'Link Requested'
  | 'Link Sent'
  | 'Link Clicked'
  | 'Purchase Tracking Pending'
  | 'Cashback Pending'
  | 'Cashback Confirmed'
  | 'Cashback Rejected'
  | 'Cashback Paid';

export interface Transaction {
  id: string;
  userId: string;
  userEmail: string;
  requestId?: string;
  clickId: string;
  trackingSubId: string;
  networkId: string;
  storeName: string;
  productId: string;
  productTitle: string;
  orderAmount: number;
  affiliateCommission: number; // Total commission paid by store
  userCashbackAmount: number; // 40% of affiliate commission
  platformShareAmount: number; // 60% platform revenue
  currency: string;
  status: OrderStatus;
  networkOrderId?: string;
  orderDate: string;
  confirmationDate?: string;
  rejectionReason?: string;
  notes?: string;
  reconciledBy?: string;
  clickedAt?: string;
  verificationDays?: number;
  verificationDeadline?: string;
  affiliateUrl?: string;
  productUrl?: string;
  createdAt: string;
  updatedAt?: string;
}

export type WithdrawalStatus = 'Pending' | 'Processing' | 'Paid' | 'Rejected';
export type PayoutMethod = 'UPI' | 'BANK';

export interface WithdrawalRequest {
  id: string;
  userId: string;
  userEmail: string;
  amount: number;
  method: PayoutMethod;
  payoutDetails: {
    upiId?: string;
    accountHolder?: string;
    accountNumber?: string;
    ifscCode?: string;
    bankName?: string;
  };
  status: WithdrawalStatus;
  transactionReference?: string; // Bank UTR or payout transaction ID
  adminNotes?: string;
  requestedAt: string;
  processedAt?: string;
}

export interface Referral {
  id: string;
  referrerId: string;
  referredUserId: string;
  referredEmail: string;
  status: 'registered' | 'qualifying_order_completed' | 'rewarded';
  rewardAmount: number;
  isPaid: boolean;
  createdAt: string;
}

export interface AppNotification {
  id: string;
  userId: string;
  title: string;
  message: string;
  type: 'reward_link' | 'click' | 'order' | 'cashback' | 'withdrawal' | 'referral' | 'system';
  isRead: boolean;
  link?: string;
  createdAt: string;
}

export interface Banner {
  id: string;
  title: string;
  subtitle: string;
  badge: string;
  imageUrl: string;
  targetUrl: string;
  productId?: string;
  categoryId?: string;
  bgColor: string;
  active: boolean;
  sortOrder: number;
}

export interface AuditLog {
  id: string;
  actorId: string;
  actorEmail: string;
  action: string;
  targetResource: string;
  details: string;
  timestamp: string;
}

export interface PlatformSettings {
  minWithdrawalAmount: number; // e.g. 250
  defaultUserCashbackShare: number; // 40
  defaultPlatformShare: number; // 60
  referralRewardAmount: number; // 50
  referralMinOrderAmount: number; // 500
  contactEmail: string;
  payoutProcessingDays: number; // 3
}

export type ScreenTab =
  | 'home'
  | 'reward-link'
  | 'premium-deals'
  | 'inbox'
  | 'orders'
  | 'history'
  | 'wallet'
  | 'withdraw'
  | 'referral'
  | 'notifications'
  | 'transactions'
  | 'profile'
  | 'help'
  | 'admin'
  | 'categories'
  | 'search'
  | 'deals'
  | 'store-offers';

